"""
骨骼帧级分类训练（PyTorch）：读取 skeleton_corpus/frames.jsonl 中的 feature144，
按 gloss_id 做多类分类。与「模板距离匹配」并行，适合帧数较多的 extract 子集。

与「整条序列再训 GRU」相比：样本量 = 各 gloss 图片帧数之和，通常更易收敛；
序列信息可通过摄像头侧多数投票或滑动窗口平滑利用。

用法示例：
  python train_skeleton_sequence.py --corpus_dir extract_dataset/skeleton_corpus
  python train_skeleton_sequence.py --frames_jsonl path/to/frames.jsonl --output_dir outputs/skeleton_mlp
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from pathlib import Path

if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from skeleton_corpus import FEATURE_DIM


def _load_jsonl_frames(
    frames_jsonl: Path,
    *,
    restrict_ids: set[str] | None,
) -> tuple[np.ndarray, np.ndarray, list[str], dict[str, str]]:
    """Returns X (N,144), y (N,) int, classes sorted gloss ids, gid -> zh_hint."""
    xs: list[np.ndarray] = []
    ys: list[int] = []
    gid_list: list[str] = []
    zh_map: dict[str, str] = {}

    with open(frames_jsonl, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            gid = str(rec["gloss_id"]).zfill(4)
            if restrict_ids is not None and gid not in restrict_ids:
                continue
            feat = np.asarray(rec["feature144"], dtype=np.float32)
            if feat.shape[0] != FEATURE_DIM:
                raise ValueError(f"bad feature dim for {gid}: {feat.shape}")
            gid_list.append(gid)
            zh_map.setdefault(gid, str(rec.get("zh_hint") or ""))

    if not gid_list:
        raise RuntimeError("没有可用的帧（检查 frames_jsonl 与 --restrict_gloss_ids）")

    classes = sorted(set(gid_list))
    class_to_idx = {g: i for i, g in enumerate(classes)}

    # Second pass: build X, y
    xs.clear()
    ys.clear()
    with open(frames_jsonl, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            gid = str(rec["gloss_id"]).zfill(4)
            if restrict_ids is not None and gid not in restrict_ids:
                continue
            feat = np.asarray(rec["feature144"], dtype=np.float32)
            xs.append(feat)
            ys.append(class_to_idx[gid])

    X = np.stack(xs, axis=0).astype(np.float32)
    y = np.asarray(ys, dtype=np.int64)
    return X, y, classes, zh_map


def _train_val_split_stratified(
    y: np.ndarray,
    val_ratio: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    train_idx: list[int] = []
    val_idx: list[int] = []
    for c in np.unique(y):
        ind = np.where(y == c)[0]
        rng.shuffle(ind)
        n_val = max(1, int(round(len(ind) * val_ratio))) if len(ind) > 1 else 0
        if n_val >= len(ind):
            n_val = max(0, len(ind) - 1)
        val_idx.extend(ind[:n_val].tolist())
        train_idx.extend(ind[n_val:].tolist())
    if not train_idx:
        raise RuntimeError("训练集为空：各类样本过少，请减小 val_ratio 或增加数据")
    return np.asarray(train_idx, dtype=np.int64), np.asarray(val_idx, dtype=np.int64)


class SkeletonMLP(nn.Module):
    def __init__(
        self,
        in_dim: int,
        num_classes: int,
        hidden: tuple[int, ...] = (256, 128),
        dropout: float = 0.25,
    ) -> None:
        super().__init__()
        dims = (in_dim,) + hidden
        blocks: list[nn.Module] = []
        for i in range(len(dims) - 1):
            blocks.append(nn.Linear(dims[i], dims[i + 1]))
            blocks.append(nn.LayerNorm(dims[i + 1]))
            blocks.append(nn.GELU())
            blocks.append(nn.Dropout(dropout))
        self.backbone = nn.Sequential(*blocks)
        self.head = nn.Linear(dims[-1], num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.backbone(x))


def main() -> None:
    ap = argparse.ArgumentParser(description="Train frame-level skeleton MLP from frames.jsonl")
    ap.add_argument(
        "--corpus_dir",
        type=str,
        default="",
        help="含 frames.jsonl 的目录（例如 extract_dataset/skeleton_corpus）",
    )
    ap.add_argument("--frames_jsonl", type=str, default="", help="直接指定 frames.jsonl（优先于 corpus_dir）")
    ap.add_argument("--output_dir", type=str, default="outputs/skeleton_mlp", help="输出 run 目录父路径")
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--weight_decay", type=float, default=1e-3)
    ap.add_argument("--val_ratio", type=float, default=0.15)
    ap.add_argument("--dropout", type=float, default=0.25)
    ap.add_argument("--hidden", type=str, default="256,128", help="MLP 隐藏层尺寸，逗号分隔")
    ap.add_argument("--noise_std", type=float, default=0.02, help="训练时对特征加高斯噪声std（0 关闭）")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument(
        "--restrict_gloss_ids",
        type=str,
        default="",
        help="逗号分隔四位 gloss id；空表示使用 jsonl 内全部",
    )
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    if str(args.frames_jsonl).strip():
        fj = Path(args.frames_jsonl.strip())
        fj = fj.resolve() if fj.is_absolute() else (base / fj).resolve()
    elif str(args.corpus_dir).strip():
        cd = Path(args.corpus_dir.strip())
        cd = cd.resolve() if cd.is_absolute() else (base / cd).resolve()
        fj = cd / "frames.jsonl"
    else:
        fj = (base / "extract_dataset" / "skeleton_corpus" / "frames.jsonl").resolve()

    if not fj.is_file():
        raise FileNotFoundError(f"未找到 frames.jsonl: {fj}")

    restrict: set[str] | None = None
    if str(args.restrict_gloss_ids).strip():
        restrict = {x.strip().zfill(4) for x in args.restrict_gloss_ids.split(",") if x.strip()}

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    X, y, classes, zh_map = _load_jsonl_frames(fj, restrict_ids=restrict)
    n_cls = len(classes)
    print(f"[train_skeleton_sequence] frames={len(y)} | classes={n_cls} | dim={FEATURE_DIM} | file={fj}")

    train_idx, val_idx = _train_val_split_stratified(y, float(args.val_ratio), int(args.seed))
    X_train, y_train = X[train_idx], y[train_idx]
    X_val, y_val = X[val_idx], y[val_idx]

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    hidden = tuple(int(x.strip()) for x in str(args.hidden).split(",") if x.strip())
    model = SkeletonMLP(FEATURE_DIM, n_cls, hidden=hidden, dropout=float(args.dropout)).to(device)

    ds_tr = TensorDataset(torch.from_numpy(X_train), torch.from_numpy(y_train))
    ds_va = TensorDataset(torch.from_numpy(X_val), torch.from_numpy(y_val))
    dl_tr = DataLoader(ds_tr, batch_size=int(args.batch_size), shuffle=True, drop_last=False)
    dl_va = DataLoader(ds_va, batch_size=int(args.batch_size), shuffle=False)

    opt = AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    ce = nn.CrossEntropyLoss()
    noise_std = float(args.noise_std)

    out_root = Path(args.output_dir)
    out_root = out_root.resolve() if out_root.is_absolute() else (base / out_root).resolve()
    run_dir = out_root / f"run_{args.seed}"
    run_dir.mkdir(parents=True, exist_ok=True)

    best_va = 0.0
    best_path = run_dir / "best_skeleton_frame_mlp.pt"

    class_to_idx = {g: i for i, g in enumerate(classes)}
    meta = {
        "frames_jsonl": str(fj),
        "feature_dim": FEATURE_DIM,
        "arch": "skeleton_mlp_frame",
        "hidden": list(hidden),
        "num_classes": n_cls,
        "class_to_idx": class_to_idx,
        "idx_to_gloss": classes,
        "zh_by_gloss": {g: zh_map.get(g, "") for g in classes},
        "train_frames": int(len(train_idx)),
        "val_frames": int(len(val_idx)),
    }
    (run_dir / "skeleton_train_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    for epoch in range(int(args.epochs)):
        model.train()
        tot_loss = 0.0
        n_b = 0
        for xb, yb in tqdm(dl_tr, desc=f"epoch {epoch+1}/{args.epochs}", leave=False):
            xb = xb.to(device)
            if noise_std > 0:
                xb = xb + noise_std * torch.randn_like(xb)
            yb = yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = ce(logits, yb)
            loss.backward()
            opt.step()
            tot_loss += float(loss.item())
            n_b += 1

        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for xb, yb in dl_va:
                xb = xb.to(device)
                yb = yb.to(device)
                pred = model(xb).argmax(dim=-1)
                correct += int((pred == yb).sum().item())
                total += int(yb.numel())
        acc = correct / max(1, total)
        print(f"epoch {epoch+1} | train_loss={tot_loss/max(1,n_b):.4f} | val_acc={acc*100:.2f}%")
        if acc >= best_va:
            best_va = acc
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "meta": meta,
                },
                best_path,
            )
            print(f"  saved best -> {best_path}")

    print(f"Done. best val_acc={best_va*100:.2f}% | checkpoint: {best_path}")


if __name__ == "__main__":
    main()
