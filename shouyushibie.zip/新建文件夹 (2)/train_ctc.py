from __future__ import annotations

import argparse
import csv
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import CSLRSequenceDataset, cslr_collate_fn, load_cslr_samples
from metrics_utils import ctc_greedy_decode, wer
from models import CSLRCTCRecognizer
from training_io import (
    CHECKPOINT_LAST,
    append_training_run_index,
    finalize_train_log,
    init_train_log,
    maybe_save_epoch_weights,
    resolve_resume_path,
    resolve_run_dir,
    resolve_training_device,
    resume_from_checkpoint,
    save_training_checkpoint,
    should_append_run_index,
    try_run_reports,
    write_history_atomic,
)


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def random_split_indices(n: int, test_ratio: float, seed: int):
    rng = np.random.default_rng(seed)
    idx = np.arange(n, dtype=np.int64)
    rng.shuffle(idx)
    n_test = max(1, int(n * test_ratio))
    return idx[n_test:], idx[:n_test]


def run_ctc_epoch(model, loader, criterion, optimizer, device, blank_id: int, grad_clip_norm: float = 0.0):
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    refs = []
    hyps = []
    for x, targets, input_lengths, target_lengths, ys in tqdm(loader, leave=False):
        x = x.to(device)
        targets = targets.to(device)
        input_lengths = input_lengths.to(device)
        target_lengths = target_lengths.to(device)

        with torch.set_grad_enabled(is_train):
            log_probs = model(x)  # [B, T, V]
            loss = criterion(
                log_probs.transpose(0, 1),  # [T, B, V]
                targets,
                input_lengths,
                target_lengths,
            )
            if is_train:
                optimizer.zero_grad()
                loss.backward()
                if grad_clip_norm and grad_clip_norm > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(grad_clip_norm))
                optimizer.step()

        total_loss += loss.item() * x.size(0)

        pred_ids = log_probs.argmax(dim=-1).detach().cpu().tolist()
        for i, seq in enumerate(pred_ids):
            hyp = ctc_greedy_decode(seq[: int(input_lengths[i].item())], blank_id=blank_id)
            ref = ys[i].tolist()
            hyps.append(hyp)
            refs.append(ref)

    return {"loss": total_loss / len(loader.dataset), "wer": float(wer(refs, hyps))}


def collect_predictions(model, loader, device, blank_id: int):
    model.eval()
    refs = []
    hyps = []
    with torch.no_grad():
        for x, targets, input_lengths, target_lengths, ys in tqdm(loader, leave=False):
            x = x.to(device)
            input_lengths = input_lengths.to(device)
            log_probs = model(x)
            pred_ids = log_probs.argmax(dim=-1).detach().cpu().tolist()
            for i, seq in enumerate(pred_ids):
                hyp = ctc_greedy_decode(seq[: int(input_lengths[i].item())], blank_id=blank_id)
                ref = ys[i].tolist()
                hyps.append(hyp)
                refs.append(ref)
    return refs, hyps


def dump_eval_csv(path: Path, refs, hyps):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ref_ids", "pred_ids"])
        for ref, hyp in zip(refs, hyps):
            writer.writerow([" ".join(str(x) for x in ref), " ".join(str(x) for x in hyp)])


def main():
    parser = argparse.ArgumentParser(description="CSLR training with CTC")
    parser.add_argument("--sequence_json", type=str, default="outputs/pose_features.json")
    parser.add_argument("--manifest_csv", type=str, default="outputs/cslr_manifest.csv")
    parser.add_argument("--vocab_size", type=int, default=7008)
    parser.add_argument("--blank_id", type=int, default=0)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--hidden_dim", type=int, default=256)
    parser.add_argument("--num_layers", type=int, default=2, help="LSTM layers in CSLRCTCRecognizer")
    parser.add_argument("--dropout", type=float, default=0.2, help="Model dropout (default matches models.py)")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument(
        "--scheduler",
        type=str,
        default="plateau",
        choices=["none", "plateau", "cosine"],
        help="LR scheduler: plateau uses ReduceLROnPlateau on test loss; cosine uses CosineAnnealingLR",
    )
    parser.add_argument("--min_lr", type=float, default=1e-6, help="plateau: min lr; cosine: eta_min")
    parser.add_argument("--plateau_factor", type=float, default=0.5, help="ReduceLROnPlateau factor")
    parser.add_argument("--plateau_patience", type=int, default=3, help="ReduceLROnPlateau patience (epochs)")
    parser.add_argument("--grad_clip_norm", type=float, default=0.0, help="Clip grad norm (0=off)")
    parser.add_argument("--early_stop_patience", type=int, default=10, help="Stop if no test WER improve for N epochs (0=off)")
    parser.add_argument("--early_stop_min_delta", type=float, default=0.0, help="Min test WER delta to count as improvement")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", type=str, default="outputs/ctc")
    parser.add_argument("--dump_eval_csv", action="store_true", help="Dump test predictions to WER csv")
    parser.add_argument("--eval_csv_path", type=str, default="outputs/wer_eval.csv")
    parser.add_argument("--run_name", type=str, default=None, help="子目录名；默认 run_YYYY-mm-dd_HHMMSS")
    parser.add_argument("--flat_output", action="store_true", help="直接写入 output_dir，不建时间戳子目录")
    parser.add_argument("--resume", type=str, default=None, help="从 checkpoint_last.pt 续训")
    parser.add_argument("--epoch_ckpt_every", type=int, default=0, help="每 N epoch 保存 epoch_weights_epoch_NNN.pt")
    parser.add_argument("--auto_report", action="store_true", help="训练结束后自动生成 reports/ 图+表")
    parser.add_argument("--reports_dir", type=str, default="reports", help="auto_report 输出目录（相对当前脚本目录）")
    parser.add_argument("--report_limit", type=int, default=20, help="auto_report 仅汇总最近 N 个 runs（0=全部）")
    parser.add_argument(
        "--write_runs_index",
        action="store_true",
        help="在 output 根目录追加 training_runs_index.jsonl（默认关闭）",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="强制使用 CPU（默认无 GPU 时会报错退出，不进行 CPU 训练）",
    )
    args = parser.parse_args()

    set_seed(args.seed)
    base_dir = Path(__file__).resolve().parent
    sequence_json = (base_dir / args.sequence_json).resolve()
    manifest_csv = (base_dir / args.manifest_csv).resolve()
    output_base = (base_dir / args.output_dir).resolve()
    resume_p = resolve_resume_path(base_dir, args.resume) if args.resume else None
    run_dir, run_label = resolve_run_dir(output_base, args.run_name, args.flat_output, resume_p)
    init_train_log(run_dir, args, "train_ctc.py", run_label)
    append_training_run_index(
        output_base,
        run_label,
        run_dir,
        append=should_append_run_index(resume_p, args.run_name, run_dir),
        enabled=bool(args.write_runs_index),
    )
    eval_csv_path = (base_dir / args.eval_csv_path).resolve()

    samples = load_cslr_samples(sequence_json, manifest_csv)
    train_idx, test_idx = random_split_indices(len(samples), test_ratio=0.2, seed=args.seed)
    train_ds = CSLRSequenceDataset(samples, train_idx)
    test_ds = CSLRSequenceDataset(samples, test_idx)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0, collate_fn=cslr_collate_fn)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, num_workers=0, collate_fn=cslr_collate_fn)

    feat_dim = int(samples[0].sequence.shape[1])
    device = resolve_training_device(force_cpu=bool(args.cpu))
    model = CSLRCTCRecognizer(
        input_dim=feat_dim,
        hidden_dim=args.hidden_dim,
        vocab_size=args.vocab_size,
        num_layers=int(args.num_layers),
        dropout=float(args.dropout),
    ).to(device)
    criterion = nn.CTCLoss(blank=args.blank_id, zero_infinity=True)
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = None
    if args.scheduler == "cosine":
        scheduler = CosineAnnealingLR(optimizer, T_max=int(args.epochs), eta_min=float(args.min_lr))
    elif args.scheduler == "plateau":
        scheduler = ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(args.plateau_factor),
            patience=int(args.plateau_patience),
            min_lr=float(args.min_lr),
            verbose=False,
        )

    history = {"train_loss": [], "train_wer": [], "test_loss": [], "test_wer": []}
    best_wer = 1e9
    best_epoch = 0
    no_improve = 0
    start_epoch = 1
    if args.resume:
        if not resume_p.is_file():
            raise FileNotFoundError(f"Resume checkpoint not found: {resume_p}")
        rs = resume_from_checkpoint(resume_p, model, optimizer, scheduler, device, default_history=history)
        start_epoch = rs.start_epoch
        history = rs.history
        best_wer = rs.best_metric
        best_epoch = int(np.argmin(np.asarray(history.get("test_wer", [best_wer]), dtype=np.float64))) + 1 if history.get("test_wer") else 0
        print(f"Resumed from epoch {start_epoch - 1}, best_test_wer={best_wer:.6f}, run_dir={run_dir}")

    for epoch in range(start_epoch, args.epochs + 1):
        train_m = run_ctc_epoch(model, train_loader, criterion, optimizer, device, args.blank_id, grad_clip_norm=float(args.grad_clip_norm))
        test_m = run_ctc_epoch(model, test_loader, criterion, None, device, args.blank_id, grad_clip_norm=0.0)
        history["train_loss"].append(train_m["loss"])
        history["train_wer"].append(train_m["wer"])
        history["test_loss"].append(test_m["loss"])
        history["test_wer"].append(test_m["wer"])
        improved = (best_wer - test_m["wer"]) > float(args.early_stop_min_delta)
        if improved:
            best_wer = test_m["wer"]
            best_epoch = epoch
            no_improve = 0
            torch.save(model.state_dict(), run_dir / "best_ctc_model.pt")
        else:
            no_improve += 1

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(float(test_m["loss"]))
            else:
                scheduler.step()
        cur_lr = float(optimizer.param_groups[0]["lr"])

        write_history_atomic(run_dir, history)
        save_training_checkpoint(
            run_dir / CHECKPOINT_LAST,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            epoch=epoch,
            history=history,
            best_metric=best_wer,
            metric_name="test_wer",
            extra={"epochs_target": args.epochs, "best_epoch": best_epoch, "scheduler": args.scheduler, "lr": cur_lr},
        )
        maybe_save_epoch_weights(run_dir, model, epoch, args.epoch_ckpt_every, prefix="epoch_weights")
        print(
            f"Epoch [{epoch}/{args.epochs}] "
            f"train_wer={train_m['wer']:.4f} test_wer={test_m['wer']:.4f} lr={cur_lr:.2e}"
        )

        if args.early_stop_patience > 0 and no_improve >= int(args.early_stop_patience):
            print(
                f"Early stopping: no test_wer improvement for {no_improve} epochs "
                f"(best={best_wer:.4f} at epoch {best_epoch})."
            )
            break

    metrics = {
        "best_test_wer": best_wer,
        "best_epoch": best_epoch,
        "epochs_ran": len(history.get("test_wer", [])),
        "vocab_size": args.vocab_size,
        "run_dir": str(run_dir),
        "run_label": run_label,
        "resume_from": str(resolve_resume_path(base_dir, args.resume)) if args.resume else None,
        "scheduler": args.scheduler,
        "dropout": float(args.dropout),
        "num_layers": int(args.num_layers),
        "early_stop_patience": int(args.early_stop_patience),
        "early_stop_min_delta": float(args.early_stop_min_delta),
    }
    finalize_train_log(
        run_dir,
        script="train_ctc.py",
        run_label=run_label,
        args=args,
        history=history,
        metrics=metrics,
    )
    print(f"Best test WER: {best_wer:.4f}")
    print(f"Run directory: {run_dir}")
    if args.auto_report:
        try_run_reports(base_dir, outputs_dir=output_base, reports_dir=(base_dir / args.reports_dir).resolve(), limit=int(args.report_limit))

    if args.dump_eval_csv:
        best_model_path = run_dir / "best_ctc_model.pt"
        if best_model_path.exists():
            model.load_state_dict(torch.load(best_model_path, map_location=device))
        refs, hyps = collect_predictions(model, test_loader, device, args.blank_id)
        dump_eval_csv(eval_csv_path, refs, hyps)
        print(f"Dumped WER evaluation csv: {eval_csv_path}")


if __name__ == "__main__":
    main()
