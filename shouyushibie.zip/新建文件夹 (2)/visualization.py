"""
Unified reporting plots for classification / fusion / CTC runs.

Outputs (under --out_dir):
  - training_curves.png   — loss + accuracy or loss + WER over epochs
  - metric_scatter.png    — train vs test metric per epoch (diagonal = gap analysis)
  - confusion_matrix.png  — optional, from --confusion_csv (y_true,y_pred)
  - feature_pca.png       — optional, 2D PCA of vectors from --rgb_npz

Examples:
  python visualization.py --history outputs/ctc/history.json
  python visualization.py --history outputs/history.json --out_dir outputs/viz
  python visualization.py --rgb_npz outputs/video_3dcnn_features.npz --max_pca_samples 3000
  python visualization.py --confusion_csv eval_labels.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None


def _ensure_out_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_history(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def is_ctc_history(h: dict) -> bool:
    return "train_wer" in h and "test_wer" in h


def plot_training_curves(h: dict, save_path: Path, title: str = "") -> None:
    if plt is None:
        return
    if is_ctc_history(h):
        epochs = np.arange(1, len(h["train_wer"]) + 1)
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        axes[0].plot(epochs, h["train_loss"], "o-", label="Train loss")
        axes[0].plot(epochs, h["test_loss"], "s-", label="Test loss")
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Loss")
        axes[0].set_title("CTC loss")
        axes[0].grid(alpha=0.3)
        axes[0].legend()

        axes[1].plot(epochs, h["train_wer"], "o-", label="Train WER")
        axes[1].plot(epochs, h["test_wer"], "s-", label="Test WER")
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("WER (lower is better)")
        axes[1].set_title("Word error rate")
        axes[1].set_ylim(0, max(1.0, float(np.max(h["test_wer"])) * 1.05))
        axes[1].grid(alpha=0.3)
        axes[1].legend()
    else:
        epochs = np.arange(1, len(h["train_acc"]) + 1)
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        axes[0].plot(epochs, h["train_acc"], "o-", label="Train acc")
        axes[0].plot(epochs, h["test_acc"], "s-", label="Test acc")
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Accuracy")
        axes[0].set_ylim(0, 1.02)
        axes[0].set_title("Accuracy")
        axes[0].grid(alpha=0.3)
        axes[0].legend()

        axes[1].plot(epochs, h["train_loss"], "o-", label="Train loss")
        axes[1].plot(epochs, h["test_loss"], "s-", label="Test loss")
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("Loss")
        axes[1].set_title("Loss")
        axes[1].grid(alpha=0.3)
        axes[1].legend()

    fig.suptitle(title or save_path.stem)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def plot_metric_scatter(h: dict, save_path: Path, title: str = "") -> None:
    """Train vs test metric per epoch (same scale — points near diagonal = small generalization gap)."""
    if plt is None:
        return
    if is_ctc_history(h):
        x = np.asarray(h["train_wer"], dtype=np.float64)
        y = np.asarray(h["test_wer"], dtype=np.float64)
        xlab, ylab = "Train WER", "Test WER"
    else:
        x = np.asarray(h["train_acc"], dtype=np.float64)
        y = np.asarray(h["test_acc"], dtype=np.float64)
        xlab, ylab = "Train accuracy", "Test accuracy"

    fig, ax = plt.subplots(figsize=(6, 6))
    lim_hi = max(float(np.max(x)), float(np.max(y)), 1e-6)
    ax.plot([0, lim_hi], [0, lim_hi], "k--", alpha=0.4, label="y = x")
    sc = ax.scatter(x, y, c=np.arange(len(x)), cmap="viridis", s=60, edgecolors="k", linewidths=0.5)
    for i in range(len(x)):
        ax.annotate(str(i + 1), (x[i], y[i]), textcoords="offset points", xytext=(4, 4), fontsize=8)
    plt.colorbar(sc, ax=ax, label="Epoch")
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title or "Train vs test (per epoch)")
    ax.grid(alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def parse_label_from_key(name: str) -> int:
    stem = Path(name).stem
    m = re.match(r"(\d{1,4})", stem)
    if m:
        return int(m.group(1))
    m = re.search(r"[_-](\d{1,4})(?:[_-]|$)", stem)
    if m:
        return int(m.group(1))
    return 0


def confusion_matrix_numpy(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int) -> np.ndarray:
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        ti, pi = int(t), int(p)
        if 0 <= ti < num_classes and 0 <= pi < num_classes:
            cm[ti, pi] += 1
    return cm


def plot_confusion_heatmap(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    save_path: Path,
    class_names: list[str] | None = None,
    max_classes: int = 48,
) -> None:
    if plt is None:
        return
    num_classes = int(max(y_true.max(), y_pred.max())) + 1
    if num_classes > max_classes:
        idx = np.random.RandomState(42).choice(num_classes, size=max_classes, replace=False)
        mask = np.isin(y_true, idx) & np.isin(y_pred, idx)
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        remap = {int(o): i for i, o in enumerate(sorted(idx))}
        y_true = np.array([remap[int(t)] for t in y_true], dtype=np.int64)
        y_pred = np.array([remap[int(p)] for p in y_pred], dtype=np.int64)
        num_classes = max_classes
        class_names = None

    cm = confusion_matrix_numpy(y_true, y_pred, num_classes)
    row_sum = cm.sum(axis=1, keepdims=True)
    row_sum[row_sum == 0] = 1
    cm_norm = cm.astype(np.float64) / row_sum

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    im0 = axes[0].imshow(cm, cmap="Blues", aspect="auto")
    axes[0].set_title("Confusion counts")
    plt.colorbar(im0, ax=axes[0], fraction=0.046)
    im1 = axes[1].imshow(cm_norm, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    axes[1].set_title("Row-normalized (recall per true class)")
    plt.colorbar(im1, ax=axes[1], fraction=0.046)

    tick_labels = class_names if class_names and len(class_names) == num_classes else [str(i) for i in range(num_classes)]
    step = max(1, num_classes // 24)
    ticks = np.arange(0, num_classes, step)
    for ax in axes:
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_xticks(ticks)
        ax.set_yticks(ticks)
        ax.set_xticklabels([tick_labels[i] for i in ticks], rotation=45, ha="right", fontsize=7)
        ax.set_yticklabels([tick_labels[i] for i in ticks], fontsize=7)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def load_confusion_csv(path: Path) -> tuple[np.ndarray, np.ndarray]:
    y_true, y_pred = [], []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames and "y_true" in reader.fieldnames and "y_pred" in reader.fieldnames:
            for row in reader:
                y_true.append(int(row["y_true"]))
                y_pred.append(int(row["y_pred"]))
        else:
            f.seek(0)
            reader = csv.reader(f)
            header = next(reader, None)
            for row in reader:
                if len(row) >= 2:
                    y_true.append(int(row[0]))
                    y_pred.append(int(row[1]))
    return np.asarray(y_true, dtype=np.int64), np.asarray(y_pred, dtype=np.int64)


def pca_2d(X: np.ndarray) -> np.ndarray:
    """PCA via SVD, no sklearn."""
    X = X.astype(np.float64)
    X = X - X.mean(axis=0, keepdims=True)
    _, _, vt = np.linalg.svd(X, full_matrices=False)
    return X @ vt[:2].T


def plot_feature_pca_scatter(
    npz_path: Path,
    save_path: Path,
    max_samples: int,
    seed: int,
) -> None:
    if plt is None:
        return
    z = np.load(npz_path, allow_pickle=True)
    keys = z["keys"]
    feat = z["rgb"] if "rgb" in z.files else z["pose"] if "pose" in z.files else None
    if feat is None:
        raise ValueError(f"No rgb/pose array in {npz_path}")

    n = len(keys)
    rng = np.random.default_rng(seed)
    if n > max_samples:
        sel = rng.choice(n, size=max_samples, replace=False)
    else:
        sel = np.arange(n)

    X = feat[sel].reshape(len(sel), -1).astype(np.float64)
    labels = np.array([parse_label_from_key(str(keys[i])) for i in sel], dtype=np.int64)

    z2 = pca_2d(X)
    fig, ax = plt.subplots(figsize=(8, 7))
    sc = ax.scatter(z2[:, 0], z2[:, 1], c=labels, cmap="tab20", alpha=0.65, s=12, edgecolors="none")
    plt.colorbar(sc, ax=ax, label="Class id (from filename)")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_title(f"PCA of features ({npz_path.name}, n={len(sel)})")
    ax.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Heatmaps, scatter, PCA — model metric reporting")
    parser.add_argument("--out_dir", type=str, default="outputs/visualization")
    parser.add_argument("--history", type=str, default="", help="Path to history.json (train / fusion / ctc)")
    parser.add_argument(
        "--confusion_csv",
        type=str,
        default="",
        help="CSV with y_true,y_pred columns (or two integer columns) for confusion heatmap",
    )
    parser.add_argument(
        "--rgb_npz",
        type=str,
        default="",
        help="Optional NPZ (keys+rgb or keys+pose) for 2D PCA scatter of features",
    )
    parser.add_argument("--max_pca_samples", type=int, default=4000)
    parser.add_argument("--pca_seed", type=int, default=42)
    parser.add_argument("--max_confusion_classes", type=int, default=48)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    out_dir = (base / args.out_dir).resolve()
    _ensure_out_dir(out_dir)

    if plt is None:
        print("matplotlib is not available; install matplotlib to generate figures.")
        return

    if args.history:
        hp = (base / args.history).resolve()
        h = load_history(hp)
        plot_training_curves(h, out_dir / "training_curves.png", title=hp.stem)
        plot_metric_scatter(h, out_dir / "metric_scatter.png", title=hp.stem)
        print(f"Saved: {out_dir / 'training_curves.png'}")
        print(f"Saved: {out_dir / 'metric_scatter.png'}")

    if args.confusion_csv:
        cp = (base / args.confusion_csv).resolve()
        yt, yp = load_confusion_csv(cp)
        plot_confusion_heatmap(yt, yp, out_dir / "confusion_matrix.png", max_classes=args.max_confusion_classes)
        print(f"Saved: {out_dir / 'confusion_matrix.png'}")

    if args.rgb_npz:
        zp = (base / args.rgb_npz).resolve()
        plot_feature_pca_scatter(zp, out_dir / "feature_pca.png", max_samples=args.max_pca_samples, seed=args.pca_seed)
        print(f"Saved: {out_dir / 'feature_pca.png'}")

    if not args.history and not args.confusion_csv and not args.rgb_npz:
        default_hist = base / "outputs" / "ctc" / "history.json"
        if default_hist.exists():
            h = load_history(default_hist)
            plot_training_curves(h, out_dir / "training_curves.png", title="ctc")
            plot_metric_scatter(h, out_dir / "metric_scatter.png", title="ctc")
            print(f"Using default history: {default_hist}")
            print(f"Saved: {out_dir / 'training_curves.png'}")
            print(f"Saved: {out_dir / 'metric_scatter.png'}")
        else:
            print(
                "Pass at least one of: --history, --confusion_csv, --rgb_npz\n"
                "Example: python visualization.py --history outputs/ctc/history.json"
            )


if __name__ == "__main__":
    main()
