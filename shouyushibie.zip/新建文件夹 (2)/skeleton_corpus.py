"""
离线抽取「双手 MediaPipe + 上臂/肘/腕 pose」144 维特征，构成 gloss 级序列模板，
用于摄像头侧与实时骨架缓冲做重采样距离匹配（连续动作近似对齐）。
"""
from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


def _suppress_mp_tf_info_logs() -> None:
    """Hide TensorFlow Lite 'XNNPACK delegate' and other chatty TF_CPP logs (not errors)."""
    # 2=warnings, 3=errors only (XNNPACK INFO still appears on some builds at first inference)
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
    os.environ.setdefault("GLOG_minloglevel", "2")
    # absl (used by some MediaPipe / TF builds)
    logging.getLogger("absl").setLevel(logging.ERROR)


def _import_mediapipe_holistic():
    """Import mediapipe with actionable errors for broken env (e.g. NumPy 2 vs old matplotlib)."""
    try:
        import mediapipe as mp

        return mp
    except ImportError as e:
        msg = str(e).lower()
        hint = ""
        if "numpy" in msg or "multiarray" in msg:
            hint = (
                "\n常见修复（任选其一）：\n"
                "  conda activate SignLanguage\n"
                "  pip install \"numpy<2\"\n"
                "或升级 matplotlib： pip install -U matplotlib\n"
            )
        raise RuntimeError(
            "无法导入 mediapipe（MediaPipe 依赖 TensorFlow Lite / NumPy / matplotlib 等）。"
            + hint
            + f"\n原始错误: {e}"
        ) from e

HANDS_DIM = 126
POSE_ARM_DIM = 18
FEATURE_DIM = HANDS_DIM + POSE_ARM_DIM
# shoulders / elbows / wrists (Holistic pose indices)
POSE_ARM_INDICES = (11, 12, 13, 14, 15, 16)


def hands126_from_holistic_result(result: object) -> np.ndarray:
    keypoints: list[float] = []
    for hand in (getattr(result, "left_hand_landmarks", None), getattr(result, "right_hand_landmarks", None)):
        if hand is None:
            keypoints.extend([0.0] * (21 * 3))
        else:
            for lm in hand.landmark:
                keypoints.extend([float(lm.x), float(lm.y), float(lm.z)])
    return np.asarray(keypoints, dtype=np.float32)


def pose_arm18_from_holistic_result(result: object) -> np.ndarray:
    plm = getattr(result, "pose_landmarks", None)
    if plm is None:
        return np.zeros(POSE_ARM_DIM, dtype=np.float32)
    lms = plm.landmark
    out: list[float] = []
    for i in POSE_ARM_INDICES:
        p = lms[i]
        out.extend([float(p.x), float(p.y), float(p.z)])
    return np.asarray(out, dtype=np.float32)


def feature144_from_holistic_result(result: object) -> np.ndarray:
    h = hands126_from_holistic_result(result)
    p = pose_arm18_from_holistic_result(result)
    return np.concatenate([h, p], axis=0).astype(np.float32)


def resample_sequence(seq: np.ndarray, target_len: int) -> np.ndarray:
    """Uniform time resampling along rows (T,D) -> (target_len, D)."""
    seq = np.asarray(seq, dtype=np.float32)
    if seq.ndim != 2:
        raise ValueError("seq must be 2D")
    T, D = seq.shape
    tl = max(2, int(target_len))
    if T == tl:
        return seq
    if T == 1:
        return np.tile(seq, (tl, 1))
    old_idx = np.linspace(0.0, float(T - 1), T)
    new_idx = np.linspace(0.0, float(T - 1), tl)
    out = np.zeros((tl, D), dtype=np.float32)
    for d in range(D):
        out[:, d] = np.interp(new_idx, old_idx, seq[:, d]).astype(np.float32)
    return out


def mean_resampled_l2(a: np.ndarray, b: np.ndarray, target_len: int = 16) -> float:
    """Mean per-frame L2 after both sequences are resampled to the same length."""
    ra = resample_sequence(a, target_len)
    rb = resample_sequence(b, target_len)
    return float(np.mean(np.linalg.norm(ra - rb, axis=1)))


def cosine_distance_flat_hands(a: np.ndarray, b: np.ndarray, target_len: int) -> float:
    """
    Resample both to target_len, take hands-only columns, flatten, L2-normalize, return 1 - cosine.
    Scale roughly in [0, 2]; lower is closer. More robust to overall translation than raw L2 on 144-d.
    """
    ah = np.asarray(a[:, :HANDS_DIM], dtype=np.float32)
    bh = np.asarray(b[:, :HANDS_DIM], dtype=np.float32)
    ra = resample_sequence(ah, target_len)
    rb = resample_sequence(bh, target_len)
    va = ra.astype(np.float64).flatten()
    vb = rb.astype(np.float64).flatten()
    na = float(np.linalg.norm(va))
    nb = float(np.linalg.norm(vb))
    if na < 1e-12 or nb < 1e-12:
        return 2.0
    va /= na
    vb /= nb
    cos = float(np.clip(np.dot(va, vb), -1.0, 1.0))
    return float(1.0 - cos)


class SkeletonSequenceMatcher:
    """Load NPZ built by build_skeleton_match_index and match live (T,144) buffers."""

    def __init__(
        self,
        index_path: Path,
        *,
        match_len: int = 16,
        low_threshold: float = 2.4,
        metric: str = "hands_l2",
    ):
        self.index_path = Path(index_path).resolve()
        self.match_len = int(match_len)
        self.low_threshold = float(low_threshold)
        self.metric = str(metric).strip().lower() or "hands_l2"
        data = np.load(str(self.index_path), allow_pickle=True)
        self.gloss_ids = [str(x) for x in data["gloss_ids"].tolist()]
        self.zh_labels = [str(x) for x in data["zh_labels"].tolist()]
        seq_obj = data["sequences"]
        self.sequences: list[np.ndarray] = []
        for i in range(len(self.gloss_ids)):
            self.sequences.append(np.asarray(seq_obj[i], dtype=np.float32))

    def _distance(self, live: np.ndarray, tpl: np.ndarray) -> float:
        if self.metric == "full_l2":
            return mean_resampled_l2(live, tpl, self.match_len)
        if self.metric == "cosine_flat":
            return cosine_distance_flat_hands(live, tpl, self.match_len)
        # default hands_l2: only MediaPipe hands 126-d（手指+手掌），降低肩肘躯干与镜头位移干扰
        return mean_resampled_l2(live[:, :HANDS_DIM], tpl[:, :HANDS_DIM], self.match_len)

    def match(self, live: np.ndarray) -> tuple[str | None, str | None, float, bool]:
        """
        Returns (gloss_id, zh, distance, weak_match).
        Always returns the best template among all glosses when data exists; weak_match True when dist > low_threshold.
        """
        live = np.asarray(live, dtype=np.float32)
        if live.ndim != 2 or live.shape[1] != FEATURE_DIM:
            raise ValueError(f"live must be (T,{FEATURE_DIM}), got {live.shape}")
        if live.shape[0] < 2:
            return None, None, float("inf"), True

        best_i = -1
        best_d = float("inf")
        for i, tpl in enumerate(self.sequences):
            if tpl.size == 0:
                continue
            d = self._distance(live, tpl)
            if d < best_d:
                best_d = d
                best_i = i
        if best_i < 0:
            return None, None, best_d, True
        gid = self.gloss_ids[best_i]
        zh = self.zh_labels[best_i]
        weak = best_d > self.low_threshold
        return gid, zh, best_d, weak


def _sorted_image_paths(gloss_dir: Path) -> list[Path]:
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    fs = [p for p in gloss_dir.iterdir() if p.is_file() and p.suffix.lower() in exts]
    fs.sort(key=lambda p: str(p.name).lower())
    return fs


def export_skeleton_corpus_from_front(
    extract_root: Path,
    gloss_csv: Path,
    *,
    restrict_gloss_ids: Sequence[str] | None = None,
    max_frames_per_gloss: int = 0,
    out_subdir: str = "skeleton_corpus",
) -> Path:
    """
    Walk extract_root/front/<gid>/ images (sorted), run MediaPipe Holistic static mode,
    append per-frame JSONL + build skeleton_match_index.npz under extract_root/out_subdir/.
    """
    _suppress_mp_tf_info_logs()
    import cv2

    mp = _import_mediapipe_holistic()

    from glossary import load_gloss_by_int

    extract_root = extract_root.resolve()
    front = extract_root / "front"
    if not front.is_dir():
        raise FileNotFoundError(f"front directory not found: {front}")

    gloss_map = load_gloss_by_int(Path(gloss_csv).resolve())
    out_dir = extract_root / out_subdir
    out_dir.mkdir(parents=True, exist_ok=True)
    frames_jsonl = out_dir / "frames.jsonl"
    meta_path = out_dir / "corpus_meta.json"
    if frames_jsonl.is_file():
        frames_jsonl.unlink()

    allow: set[str] | None = None
    if restrict_gloss_ids is not None:
        allow = {str(x).zfill(4) for x in restrict_gloss_ids}

    print("[skeleton_corpus] Loading MediaPipe Holistic (first run may take several seconds)...", flush=True)
    holistic = mp.solutions.holistic.Holistic(
        static_image_mode=True,
        model_complexity=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    print(
        "[skeleton_corpus] Model ready. Processing images... "
        "（首帧可能打印 TensorFlow Lite / XNNPACK 一行 INFO，可忽略，不是报错）",
        flush=True,
    )
    seq_by_gid: dict[str, list[np.ndarray]] = {}
    zh_by_gid: dict[str, str] = {}
    n_lines = 0

    try:
        gdirs = sorted([p for p in front.iterdir() if p.is_dir()], key=lambda p: p.name)
        for gd in gdirs:
            gid = gd.name
            if allow is not None and gid not in allow:
                continue
            imgs = _sorted_image_paths(gd)
            if max_frames_per_gloss and max_frames_per_gloss > 0:
                imgs = imgs[: int(max_frames_per_gloss)]
            if not imgs:
                print(f"[skeleton_corpus] skip empty gloss folder: {gid}", flush=True)
                continue
            print(f"[skeleton_corpus] gloss {gid}: {len(imgs)} images", flush=True)
            gi = int(gid) if gid.isdigit() else -1
            if gi >= 0 and gi in gloss_map:
                zh_by_gid[gid] = str(gloss_map[gi].zh)
            else:
                zh_by_gid[gid] = ""

            for fi, imp in enumerate(imgs):
                bgr = cv2.imread(str(imp), cv2.IMREAD_COLOR)
                if bgr is None:
                    print(f"[skeleton_corpus] WARN: unreadable image: {imp}", flush=True)
                    continue
                rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
                result = holistic.process(rgb)
                h126 = hands126_from_holistic_result(result)
                p18 = pose_arm18_from_holistic_result(result)
                f144 = np.concatenate([h126, p18], axis=0).astype(np.float32)
                if gid not in seq_by_gid:
                    seq_by_gid[gid] = []
                seq_by_gid[gid].append(f144)

                rel = str(imp.relative_to(extract_root)).replace("\\", "/")
                rec = {
                    "gloss_id": gid,
                    "zh_hint": zh_by_gid.get(gid, ""),
                    "rel_path": rel,
                    "frame_index": fi,
                    "hands126": h126.tolist(),
                    "pose_arm18": p18.tolist(),
                    "feature144": f144.tolist(),
                }
                with open(frames_jsonl, "a", encoding="utf-8") as jf:
                    jf.write(json.dumps(rec, ensure_ascii=False) + "\n")
                n_lines += 1
    finally:
        holistic.close()

    gids_sorted = sorted(seq_by_gid.keys(), key=lambda x: x)
    sequences: list[np.ndarray] = []
    zh_list: list[str] = []
    for gid in gids_sorted:
        frames = seq_by_gid[gid]
        if not frames:
            continue
        sequences.append(np.stack(frames, axis=0).astype(np.float32))
        zh_list.append(zh_by_gid.get(gid, ""))

    index_npz = out_dir / "skeleton_match_index.npz"
    np.savez(
        str(index_npz),
        gloss_ids=np.array(gids_sorted, dtype=object),
        zh_labels=np.array(zh_list, dtype=object),
        sequences=np.array(sequences, dtype=object),
        feature_dim=np.int32(FEATURE_DIM),
    )

    meta_path.write_text(
        json.dumps(
            {
                "extract_root": str(extract_root),
                "gloss_csv": str(Path(gloss_csv).resolve()),
                "frames_jsonl": str(frames_jsonl),
                "index_npz": str(index_npz),
                "num_gloss": len(gids_sorted),
                "num_frame_records": n_lines,
                "feature_dim": FEATURE_DIM,
                "pose_arm_indices": list(POSE_ARM_INDICES),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(
        f"[skeleton_corpus] wrote {n_lines} frame records | {len(gids_sorted)} gloss sequences -> {out_dir}"
    )
    return out_dir


def build_index_only_from_jsonl(extract_root: Path, gloss_csv: Path, *, out_subdir: str = "skeleton_corpus") -> Path:
    """Rebuild NPZ from existing frames.jsonl (e.g. after manual edit)."""
    from glossary import load_gloss_by_int

    extract_root = extract_root.resolve()
    out_dir = extract_root / out_subdir
    frames_jsonl = out_dir / "frames.jsonl"
    if not frames_jsonl.is_file():
        raise FileNotFoundError(frames_jsonl)

    gloss_map = load_gloss_by_int(Path(gloss_csv).resolve())
    by_gid: dict[str, list[tuple[int, np.ndarray]]] = {}
    with open(frames_jsonl, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            gid = str(rec["gloss_id"]).zfill(4)
            fi = int(rec.get("frame_index", 0))
            f144 = np.asarray(rec["feature144"], dtype=np.float32)
            by_gid.setdefault(gid, []).append((fi, f144))

    gids_sorted = sorted(by_gid.keys())
    sequences: list[np.ndarray] = []
    zh_list: list[str] = []
    for gid in gids_sorted:
        pairs = sorted(by_gid[gid], key=lambda t: t[0])
        arr = np.stack([p[1] for p in pairs], axis=0).astype(np.float32)
        sequences.append(arr)
        gi = int(gid) if gid.isdigit() else -1
        zh_list.append(str(gloss_map[gi].zh) if gi >= 0 and gi in gloss_map else "")

    index_npz = out_dir / "skeleton_match_index.npz"
    np.savez(
        str(index_npz),
        gloss_ids=np.array(gids_sorted, dtype=object),
        zh_labels=np.array(zh_list, dtype=object),
        sequences=np.array(sequences, dtype=object),
        feature_dim=np.int32(FEATURE_DIM),
    )
    print(f"[skeleton_corpus] rebuilt index -> {index_npz}")
    return index_npz


def parse_cli_export() -> None:
    import argparse

    _suppress_mp_tf_info_logs()
    base = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser(
        description="Export skeleton corpus from extract_root/front",
        epilog=(
            "示例（在 sign_language_system 目录下）:  python skeleton_corpus.py\n"
            "须先有 extract.py 生成的 extract_dataset/front/<四位id>/ 图片。"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--extract_root",
        type=str,
        default="extract_dataset",
        help="extract 产出根目录（默认相对本脚本目录的 extract_dataset，与 extract.py --out_root 一致）",
    )
    ap.add_argument(
        "--gloss_csv",
        type=str,
        default="",
        help="gloss 表；留空则使用上级目录下的 gloss.csv",
    )
    ap.add_argument("--restrict_file", type=str, default="", help="Optional ids.txt (one id per line)")
    ap.add_argument("--max_frames_per_gloss", type=int, default=0)
    ap.add_argument("--out_subdir", type=str, default="skeleton_corpus")
    ap.add_argument("--rebuild_index_only", action="store_true")
    args = ap.parse_args()
    root = Path(str(args.extract_root).strip() or "extract_dataset")
    root = root.resolve() if root.is_absolute() else (base / root).resolve()
    if str(args.gloss_csv).strip():
        gc = Path(str(args.gloss_csv).strip())
        gc = gc.resolve() if gc.is_absolute() else (base / gc).resolve()
    else:
        gc = (base.parent / "gloss.csv").resolve()
    if args.rebuild_index_only:
        build_index_only_from_jsonl(root, gc, out_subdir=args.out_subdir)
        return
    restrict: Iterable[str] | None = None
    if str(args.restrict_file).strip():
        p = Path(args.restrict_file).resolve()
        restrict = [ln.strip().zfill(4) for ln in p.read_text(encoding="utf-8").splitlines() if ln.strip()]
    export_skeleton_corpus_from_front(
        root,
        gc,
        restrict_gloss_ids=restrict,
        max_frames_per_gloss=int(args.max_frames_per_gloss),
        out_subdir=str(args.out_subdir),
    )


if __name__ == "__main__":
    _suppress_mp_tf_info_logs()
    print(f"[skeleton_corpus] Python: {sys.executable}", flush=True)
    try:
        parse_cli_export()
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        print(
            "提示: 请先在 sign_language_system 下运行 extract.py 生成 extract_dataset/front/<四位id>/ 图片。",
            file=sys.stderr,
        )
        raise SystemExit(1) from e
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        raise SystemExit(1) from e
