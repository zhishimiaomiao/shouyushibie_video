from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None


def save_svg_curve(history, save_path: Path):
    width, height = 960, 420
    padding = 50
    epochs = len(history["train_acc"])
    x_step = (width - 2 * padding) / max(1, epochs - 1)

    all_values = (
        history["train_acc"]
        + history["test_acc"]
        + history["train_loss"]
        + history["test_loss"]
    )
    y_min, y_max = min(all_values), max(all_values)
    y_range = max(1e-6, y_max - y_min)

    def pt(i, v):
        x = padding + i * x_step
        y = height - padding - ((v - y_min) / y_range) * (height - 2 * padding)
        return x, y

    def polyline(values, color):
        points = " ".join([f"{pt(i, v)[0]:.2f},{pt(i, v)[1]:.2f}" for i, v in enumerate(values)])
        return f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2"/>'

    svg = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<line x1="{padding}" y1="{height-padding}" x2="{width-padding}" y2="{height-padding}" stroke="black"/>',
        f'<line x1="{padding}" y1="{padding}" x2="{padding}" y2="{height-padding}" stroke="black"/>',
        polyline(history["train_acc"], "#1f77b4"),
        polyline(history["test_acc"], "#ff7f0e"),
        polyline(history["train_loss"], "#2ca02c"),
        polyline(history["test_loss"], "#d62728"),
        f'<text x="{padding}" y="24" font-size="16">Train/Test Accuracy + Loss Curves</text>',
        f'<text x="{padding}" y="{height-10}" font-size="12">Epoch</text>',
        f'<text x="{width-310}" y="40" font-size="12" fill="#1f77b4">Train Accuracy</text>',
        f'<text x="{width-310}" y="58" font-size="12" fill="#ff7f0e">Test Accuracy</text>',
        f'<text x="{width-310}" y="76" font-size="12" fill="#2ca02c">Train Loss</text>',
        f'<text x="{width-310}" y="94" font-size="12" fill="#d62728">Test Loss</text>',
        "</svg>",
    ]
    save_path.write_text("\n".join(svg), encoding="utf-8")


def load_history_object(path: Path) -> dict:
    """Accept ``history.json`` or ``训练记录.json`` (uses 训练结果.history)."""
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, dict) and "训练结果" in raw:
        h = (raw.get("训练结果") or {}).get("history")
        if isinstance(h, dict):
            return h
    return raw


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot training accuracy/loss curves")
    parser.add_argument(
        "--history",
        type=str,
        default="outputs/history.json",
        help="history.json 或某次 run 下的 训练记录.json",
    )
    parser.add_argument("--save_path", type=str, default="outputs/accuracy_loss_curve.png")
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    history_path = (base_dir / args.history).resolve()
    save_path = (base_dir / args.save_path).resolve()
    save_path.parent.mkdir(parents=True, exist_ok=True)

    history = load_history_object(history_path)

    if plt is not None:
        epochs = list(range(1, len(history["train_acc"]) + 1))
        plt.figure(figsize=(12, 5))

        plt.subplot(1, 2, 1)
        plt.plot(epochs, history["train_acc"], marker="o", label="Train Accuracy")
        plt.plot(epochs, history["test_acc"], marker="o", label="Test Accuracy")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.title("Accuracy Curve")
        plt.grid(alpha=0.3)
        plt.legend()

        plt.subplot(1, 2, 2)
        plt.plot(epochs, history["train_loss"], marker="o", label="Train Loss")
        plt.plot(epochs, history["test_loss"], marker="o", label="Test Loss")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Loss Curve")
        plt.grid(alpha=0.3)
        plt.legend()

        plt.tight_layout()
        plt.savefig(save_path, dpi=150)
        print(f"Saved plot: {save_path}")
    else:
        svg_path = save_path.with_suffix(".svg")
        save_svg_curve(history, svg_path)
        print(f"matplotlib unavailable, saved SVG plot instead: {svg_path}")


if __name__ == "__main__":
    main()
