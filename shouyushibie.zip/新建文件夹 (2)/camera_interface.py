﻿"""
实时摄像头手语识别界面：左侧画面，右侧中文/英文释义，底部显示预测置信度。

支持两种识别模式（自动根据 checkpoint 类型选择）：

1) image 模型（`train_image.py` 产物）
   - 输入：摄像头帧图像（Resize + ImageNet Normalize，与 `train_image.py` 一致）
   - 输出：类别索引 -> 类别标签（优先读取 `outputs/image/run_*/训练记录.json` 的 `class_to_idx`）

2) fusion/pose 模型（`train_fusion.py` 产物，支持 pose-only：rgb 全零）
   - 输入：MediaPipe Holistic 提取双手关键点序列（126维/帧）
   - 输出：GlossID（从 checkpoint 输出类别索引得到），再用 `gloss.csv` 翻译中文/英文
"""

from __future__ import annotations

import argparse
import os
import json
from collections import deque
from pathlib import Path
import time
import sys

# Workaround for Windows conda OpenMP duplication crash:
# "OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll already initialized."
# Prefer fixing the environment (single OpenMP runtime), but this keeps scripts runnable.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torchvision import transforms

from glossary import load_gloss_tuples as load_gloss_map, parse_gloss_id_from_filename as parse_label_from_name
from interpretive_scheme import (
    Seq2SeqTransformer,
    canonicalize_gloss_id_tokens,
    canonicalize_src_key,
    compose_natural_sentence,
    dedupe_consecutive_id_tokens,
    greedy_translate,
    load_exact_library_map,
    load_id_to_zh_from_gloss,
    load_id_to_zh_from_manifest,
    load_vocab,
    normalize_zh_gloss,
    tokenize_src,
    to_colloquial_sentence,
)
from train_image import build_model
from models import DualStreamFusionRecognizer


def _torch_load_safely(path: Path, *, map_location):
    """
    Prefer torch.load(weights_only=True) to avoid pickle execution + FutureWarning.
    Falls back for older torch versions that don't support weights_only.
    """
    try:
        return torch.load(path, map_location=map_location, weights_only=True)
    except TypeError:
        return torch.load(path, map_location=map_location)


def _load_skeleton_mlp_checkpoint(path: Path, device: torch.device) -> tuple[torch.nn.Module, dict]:
    from train_skeleton_sequence import SkeletonMLP

    payload = _torch_load_safely(path.resolve(), map_location="cpu")
    if not isinstance(payload, dict) or "model_state_dict" not in payload or "meta" not in payload:
        raise RuntimeError("not a train_skeleton_sequence.py checkpoint (missing model_state_dict/meta)")
    meta = payload["meta"]
    hidden = tuple(meta["hidden"])
    fd = int(meta["feature_dim"])
    nc = int(meta["num_classes"])
    model = SkeletonMLP(fd, nc, hidden=hidden, dropout=0.25)
    model.load_state_dict(payload["model_state_dict"])
    model.eval()
    model.to(device)
    return model, meta


def _infer_skeleton_mlp_one_frame(
    model: torch.nn.Module,
    meta: dict,
    feat144: np.ndarray,
    device: torch.device,
) -> tuple[str, str, float]:
    """Returns (zh_hint_or_gloss, gloss_id_4d, confidence)."""
    import torch.nn.functional as F

    x = torch.from_numpy(feat144.astype(np.float32)).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model(x)
        probs = F.softmax(logits, dim=-1)
        conf = float(probs.max().item())
        idx = int(logits.argmax(dim=-1).item())
    idx_to_gloss = meta.get("idx_to_gloss")
    if not isinstance(idx_to_gloss, list) or idx < 0 or idx >= len(idx_to_gloss):
        return "?", "????", conf
    gid = str(idx_to_gloss[idx]).zfill(4)
    zh_map = meta.get("zh_by_gloss") or {}
    zh = ""
    if isinstance(zh_map, dict):
        zh = str(zh_map.get(gid, "") or "")
    return (zh if zh else gid), gid, conf


def _gloss_zh(gloss: dict[str, tuple[str, str]], gid: int) -> str:
    """Return Chinese gloss for an integer id, or '' if missing."""
    sid = f"{int(gid):04d}"
    try:
        zh = (gloss.get(sid) or ("", ""))[0]
    except Exception:
        zh = ""
    return normalize_zh_gloss(zh) if zh else ""


def _class_labels_look_like_gloss_ids(class_to_idx: dict[str, int] | None) -> bool:
    """
    Heuristic: if image model classes are numeric (e.g. "0002", "2"), treat them as Gloss IDs
    and map through gloss.csv. Otherwise treat them as plain human labels (e.g. "差点儿2-2", "你好").

    This prevents accidental mapping like "Participant_02" -> gloss id 0002.
    """
    if not isinstance(class_to_idx, dict) or not class_to_idx:
        return False
    keys = [str(k).strip() for k in class_to_idx.keys() if str(k).strip()]
    if not keys:
        return False
    numish = 0
    for k in keys:
        if k.isdigit():
            numish += 1
    return (numish / float(len(keys))) >= 0.95


def _normalize_state_dict(state: dict) -> dict:
    if not state:
        return state
    if any(k.startswith("module.") for k in state.keys()):
        return {k.replace("module.", "", 1): v for k, v in state.items()}
    return state


def _infer_num_classes_from_state(state: dict) -> int | None:
    for k in ("fc.weight", "classifier.1.weight", "classifier.0.weight", "classifier.2.weight"):
        w = state.get(k)
        if w is not None and hasattr(w, "shape") and len(w.shape) == 2:
            return int(w.shape[0])
    return None


def _looks_like_fusion_state(state: dict) -> bool:
    # DualStreamFusionRecognizer key hints
    keys = set(state.keys())
    return ("rgb_proj.0.weight" in keys) and ("pose_encoder.pose_proj.0.weight" in keys) and ("fusion.3.weight" in keys)


def infer_fusion_dims(state: dict) -> tuple[int, int, int, int]:
    rgb_w = state["rgb_proj.0.weight"]
    pose_w = state["pose_encoder.pose_proj.0.weight"]
    cls_w = state["fusion.3.weight"]
    rgb_dim = int(rgb_w.shape[1])
    pose_dim = int(pose_w.shape[1])
    hidden_dim = int(rgb_w.shape[0])
    num_classes = int(cls_w.shape[0])
    return rgb_dim, pose_dim, hidden_dim, num_classes


def load_fusion_model(ckpt: Path, device: torch.device) -> tuple[DualStreamFusionRecognizer, int, int]:
    payload = _torch_load_safely(ckpt, map_location="cpu")
    if isinstance(payload, dict) and "model_state_dict" in payload:
        state = payload["model_state_dict"]
    elif isinstance(payload, dict) and "state_dict" in payload:
        state = payload["state_dict"]
    else:
        state = payload
    if not isinstance(state, dict):
        raise RuntimeError(f"Unsupported checkpoint format: {ckpt}")
    state = _normalize_state_dict(state)
    if not _looks_like_fusion_state(state):
        raise RuntimeError("Checkpoint does not look like a DualStreamFusionRecognizer state_dict.")
    rgb_dim, pose_dim, hidden_dim, num_classes = infer_fusion_dims(state)
    model = DualStreamFusionRecognizer(
        rgb_dim=rgb_dim,
        pose_dim=pose_dim,
        hidden_dim=hidden_dim,
        num_classes=num_classes,
    ).to(device)
    model.load_state_dict(state, strict=True)
    model.eval()
    return model, rgb_dim, pose_dim


def load_fusion_label_map(ckpt: Path) -> dict[int, int] | None:
    """
    Load outputs/fusion/label_map.json written by train_fusion.py.
    Returns idx->gloss_id mapping.
    """
    cand = ckpt.parent / "label_map.json"
    if not cand.is_file():
        return None
    try:
        doc = json.loads(cand.read_text(encoding="utf-8"))
        arr = doc.get("idx_to_gloss_id")
        if not isinstance(arr, list) or not arr:
            return None
        return {int(i): int(g) for i, g in enumerate(arr)}
    except Exception:
        return None


def load_image_training_log(log_path: Path) -> tuple[str | None, int | None, dict[str, int] | None]:
    if not log_path or not log_path.is_file():
        return None, None, None
    try:
        doc = json.loads(log_path.read_text(encoding="utf-8"))
        cfg = doc.get("命令与配置") or {}
        res = doc.get("训练结果") or {}
        arch = cfg.get("arch")
        image_size = cfg.get("image_size")
        c2i = res.get("class_to_idx")
        if isinstance(c2i, dict):
            class_to_idx = {str(k): int(v) for k, v in c2i.items()}
        else:
            class_to_idx = None
        return (str(arch) if arch is not None else None, int(image_size) if image_size is not None else None, class_to_idx)
    except Exception:
        return None, None, None


def pick_latest_image_run(outputs_image_dir: Path) -> tuple[Path | None, Path | None]:
    if not outputs_image_dir.is_dir():
        return None, None
    runs = sorted(outputs_image_dir.glob("run_*"), key=lambda p: p.name, reverse=True)
    for r in runs:
        if not r.is_dir():
            continue
        log_p = r / "训练记录.json"
        if not log_p.is_file():
            continue
        for ckpt_name in ("best_image_model.pt", "checkpoint_last.pt"):
            ckpt_p = r / ckpt_name
            if ckpt_p.is_file():
                return ckpt_p, log_p
    return None, None


def load_image_model(
    ckpt: Path,
    device: torch.device,
    *,
    arch: str | None,
    num_classes: int | None,
) -> torch.nn.Module:
    payload = _torch_load_safely(ckpt, map_location="cpu")
    if isinstance(payload, dict) and "model_state_dict" in payload:
        state = payload["model_state_dict"]
    else:
        state = payload
    if not isinstance(state, dict):
        raise RuntimeError(f"Unsupported checkpoint format: {ckpt}")
    state = _normalize_state_dict(state)

    if num_classes is None:
        num_classes = _infer_num_classes_from_state(state)
    if num_classes is None or int(num_classes) <= 0:
        raise RuntimeError("无法从 checkpoint 推断 num_classes；请提供包含 class_to_idx 的 训练记录.json。")

    arch = (arch or "resnet18").strip().lower()
    model = build_model(num_classes=int(num_classes), pretrained=False, arch=arch).to(device)
    model.load_state_dict(state, strict=True)
    model.eval()
    return model


def _aabb_norm_hand_landmarks(landmarks, w: int, h: int, pad_ratio: float = 0.12) -> tuple[int, int, int, int] | None:
    """MediaPipe 手部归一化关键点 -> 像素轴对齐框（含边距）。"""
    if landmarks is None:
        return None
    xs = [float(lm.x) * float(w) for lm in landmarks.landmark]
    ys = [float(lm.y) * float(h) for lm in landmarks.landmark]
    if not xs:
        return None
    x1, x2 = min(xs), max(xs)
    y1, y2 = min(ys), max(ys)
    bw = max(1.0, x2 - x1)
    bh = max(1.0, y2 - y1)
    px, py = bw * float(pad_ratio), bh * float(pad_ratio)
    xi1 = int(max(0, x1 - px))
    yi1 = int(max(0, y1 - py))
    xi2 = int(min(w - 1, x2 + px))
    yi2 = int(min(h - 1, y2 + py))
    if xi2 <= xi1 or yi2 <= yi1:
        return None
    return xi1, yi1, xi2, yi2


def _aabb_pixel_hand_xy(lm_xy: np.ndarray, w: int, h: int, pad_ratio: float = 0.12) -> tuple[int, int, int, int] | None:
    """Hands 模式下的像素坐标关键点 -> 轴对齐框。"""
    if lm_xy is None or getattr(lm_xy, "size", 0) < 4:
        return None
    xs = lm_xy[:, 0].astype(np.float64)
    ys = lm_xy[:, 1].astype(np.float64)
    x1, x2 = float(np.min(xs)), float(np.max(xs))
    y1, y2 = float(np.min(ys)), float(np.max(ys))
    bw = max(1.0, x2 - x1)
    bh = max(1.0, y2 - y1)
    px, py = bw * float(pad_ratio), bh * float(pad_ratio)
    xi1 = int(max(0, x1 - px))
    yi1 = int(max(0, y1 - py))
    xi2 = int(min(w - 1, x2 + px))
    yi2 = int(min(h - 1, y2 + py))
    if xi2 <= xi1 or yi2 <= yi1:
        return None
    return xi1, yi1, xi2, yi2


# MediaPipe Pose：肩、肘、腕（上肢轨迹 / 红色 ROI 用）
_LEFT_ARM_POSE_IDX = (11, 13, 15)
_RIGHT_ARM_POSE_IDX = (12, 14, 16)


def _aabb_from_pose_indices(
    pose_landmarks,
    w: int,
    h: int,
    indices: tuple[int, ...],
    *,
    pad_ratio: float = 0.18,
    vis_thresh: float = 0.15,
) -> tuple[int, int, int, int] | None:
    """用 Pose 若干 landmark 索引生成像素包围框（用于肘、小臂区域提示）。"""
    if pose_landmarks is None:
        return None
    lms = pose_landmarks.landmark
    xs: list[float] = []
    ys: list[float] = []
    for i in indices:
        if i >= len(lms):
            continue
        lm = lms[i]
        vis = float(getattr(lm, "visibility", 1.0) or 1.0)
        if vis < vis_thresh:
            continue
        xs.append(float(lm.x) * float(w))
        ys.append(float(lm.y) * float(h))
    if not xs:
        return None
    x1, x2 = min(xs), max(xs)
    y1, y2 = min(ys), max(ys)
    bw = max(24.0, x2 - x1)
    bh = max(24.0, y2 - y1)
    px, py = bw * float(pad_ratio), bh * float(pad_ratio)
    xi1 = int(max(0, x1 - px))
    yi1 = int(max(0, y1 - py))
    xi2 = int(min(w - 1, x2 + px))
    yi2 = int(min(h - 1, y2 + py))
    if xi2 <= xi1 or yi2 <= yi1:
        return None
    return xi1, yi1, xi2, yi2


def _mp_draw_holistic(
    frame_bgr: np.ndarray,
    result,
    *,
    draw_face_box: bool,
    draw_hand_roi: bool,
    draw_arm_roi: bool,
    draw_pose: bool,
    draw_hands: bool,
) -> np.ndarray:
    """
    可视化：在画面上叠加 MediaPipe Holistic 关键点/骨架。
    - 默认画双手；黄色 ROI 框标注手部；红色 ROI 框标注肩-肘-腕上肢区域（便于观察肘臂姿态）
    - 可选：pose 骨架连线；面部 bbox（默认关闭）
    """
    if result is None:
        return frame_bgr

    try:
        import mediapipe as mp

        mp_drawing = mp.solutions.drawing_utils
        mp_styles = mp.solutions.drawing_styles
        mp_holistic = mp.solutions.holistic

        out = frame_bgr.copy()
        # Hands
        if draw_hands:
            if result.left_hand_landmarks is not None:
                mp_drawing.draw_landmarks(
                    out,
                    result.left_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )
            if result.right_hand_landmarks is not None:
                mp_drawing.draw_landmarks(
                    out,
                    result.right_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )

        # Pose
        if draw_pose and result.pose_landmarks is not None:
            mp_drawing.draw_landmarks(
                out,
                result.pose_landmarks,
                mp_holistic.POSE_CONNECTIONS,
                mp_styles.get_default_pose_landmarks_style(),
            )

        h, w = out.shape[:2]
        # 肩-肘-腕 上肢 ROI（红色框：突出肘与小臂区域；仅可视化，分类仍以整帧为准）
        if draw_arm_roi and result.pose_landmarks is not None:
            bb_la = _aabb_from_pose_indices(result.pose_landmarks, w, h, _LEFT_ARM_POSE_IDX)
            if bb_la is not None:
                x1, y1, x2, y2 = bb_la
                cv2.rectangle(out, (x1, y1), (x2, y2), (0, 0, 255), 2)
                cv2.putText(out, "arm(L)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            bb_ra = _aabb_from_pose_indices(result.pose_landmarks, w, h, _RIGHT_ARM_POSE_IDX)
            if bb_ra is not None:
                x1, y1, x2, y2 = bb_ra
                cv2.rectangle(out, (x1, y1), (x2, y2), (0, 0, 255), 2)
                cv2.putText(out, "arm(R)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        # Hand ROI（黄色框随手动，手语识别主体）
        if draw_hand_roi:
            bb_l = _aabb_norm_hand_landmarks(result.left_hand_landmarks, w, h) if result.left_hand_landmarks else None
            if bb_l is not None:
                x1, y1, x2, y2 = bb_l
                cv2.rectangle(out, (x1, y1), (x2, y2), (0, 255, 255), 2)
                cv2.putText(out, "hand(L)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)
            bb_r = _aabb_norm_hand_landmarks(result.right_hand_landmarks, w, h) if result.right_hand_landmarks else None
            if bb_r is not None:
                x1, y1, x2, y2 = bb_r
                cv2.rectangle(out, (x1, y1), (x2, y2), (0, 255, 255), 2)
                cv2.putText(out, "hand(R)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)

        # Face bbox（默认关闭；面部框容易抢走视觉焦点且与手语主体无关）
        if draw_face_box and result.face_landmarks is not None:
            xs = [lm.x for lm in result.face_landmarks.landmark]
            ys = [lm.y for lm in result.face_landmarks.landmark]
            if xs and ys:
                x1 = int(max(0.0, min(xs)) * w)
                y1 = int(max(0.0, min(ys)) * h)
                x2 = int(min(1.0, max(xs)) * w)
                y2 = int(min(1.0, max(ys)) * h)
                cv2.rectangle(out, (x1, y1), (x2, y2), (0, 255, 255), 2)
                cv2.putText(out, "face", (x1, max(18, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

        return out
    except Exception:
        # drawing should never break inference
        return frame_bgr


def _overlay_hand_status(frame_bgr: np.ndarray, left_ok: bool, right_ok: bool) -> np.ndarray:
    out = frame_bgr
    h, w = out.shape[:2]
    x0, y0 = 12, 40
    box_w, box_h = 210, 54
    cv2.rectangle(out, (x0, y0), (x0 + box_w, y0 + box_h), (0, 0, 0), thickness=-1)
    cv2.rectangle(out, (x0, y0), (x0 + box_w, y0 + box_h), (200, 200, 200), thickness=1)
    t1 = f"hand(L): {'1' if left_ok else '0'}"
    t2 = f"hand(R): {'1' if right_ok else '0'}"
    cv2.putText(out, t1, (x0 + 10, y0 + 22), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(out, t2, (x0 + 10, y0 + 46), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
    # small hint arrow like sample screenshots (optional decorative line)
    cv2.line(out, (x0 + box_w, y0 + box_h // 2), (min(w - 1, x0 + box_w + 40), y0 + box_h // 2), (0, 255, 255), 2)
    return out


def _angle_deg(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> float:
    """Angle ABC in degrees for 2D/3D points."""
    ba = a - b
    bc = c - b
    nba = float(np.linalg.norm(ba))
    nbc = float(np.linalg.norm(bc))
    if nba < 1e-6 or nbc < 1e-6:
        return 0.0
    cosv = float(np.dot(ba, bc) / (nba * nbc))
    cosv = max(-1.0, min(1.0, cosv))
    return float(np.degrees(np.arccos(cosv)))


def _finger_bend_angles(lm_xy: np.ndarray) -> dict[str, float]:
    """
    Compute simple bend angles from MediaPipe Hands landmarks (21 points).
    Uses PIP joint angles for 4 fingers and IP for thumb.
    """
    if lm_xy is None or lm_xy.shape[0] != 21:
        return {}
    p = lm_xy.astype(np.float32)
    # indices from MediaPipe Hands:
    # 0 wrist
    # thumb: 1,2,3,4
    # index: 5,6,7,8
    # middle: 9,10,11,12
    # ring: 13,14,15,16
    # pinky: 17,18,19,20
    out = {}
    out["thumb"] = _angle_deg(p[2], p[3], p[4])
    out["index"] = _angle_deg(p[5], p[6], p[7])
    out["middle"] = _angle_deg(p[9], p[10], p[11])
    out["ring"] = _angle_deg(p[13], p[14], p[15])
    out["pinky"] = _angle_deg(p[17], p[18], p[19])
    return out


def _draw_hand_colored(frame_bgr: np.ndarray, lm_xy: np.ndarray, *, is_left: bool) -> np.ndarray:
    """
    Draw a hand with per-finger colored bones using pixel coords (21,2).
    """
    if lm_xy is None or lm_xy.shape[0] != 21:
        return frame_bgr
    out = frame_bgr
    pts = lm_xy.astype(np.int32)
    # Per-finger connection chains
    chains = {
        "thumb": [0, 1, 2, 3, 4],
        "index": [0, 5, 6, 7, 8],
        "middle": [0, 9, 10, 11, 12],
        "ring": [0, 13, 14, 15, 16],
        "pinky": [0, 17, 18, 19, 20],
    }
    # Distinct colors (BGR); swap slightly by handedness for visual separation
    if is_left:
        colors = {"thumb": (0, 200, 255), "index": (0, 255, 0), "middle": (255, 200, 0), "ring": (255, 0, 255), "pinky": (0, 128, 255)}
    else:
        colors = {"thumb": (0, 180, 255), "index": (0, 220, 0), "middle": (255, 180, 0), "ring": (220, 0, 255), "pinky": (0, 110, 255)}

    # bones
    for name, idxs in chains.items():
        col = colors.get(name, (200, 200, 200))
        for a, b in zip(idxs[:-1], idxs[1:]):
            cv2.line(out, tuple(pts[a]), tuple(pts[b]), col, 2, cv2.LINE_AA)
    # joints
    for i in range(21):
        cv2.circle(out, tuple(pts[i]), 3, (255, 255, 255), -1, cv2.LINE_AA)
        cv2.circle(out, tuple(pts[i]), 3, (30, 30, 30), 1, cv2.LINE_AA)
    return out


def _extract_lr_hands_from_mp_hands(result, *, img_w: int, img_h: int) -> tuple[np.ndarray | None, np.ndarray | None]:
    """
    From mp.solutions.hands result -> (left_xy, right_xy) in pixel coords, each (21,2).
    Uses handedness when available; otherwise falls back to x-position heuristic.
    """
    if result is None or (not getattr(result, "multi_hand_landmarks", None)):
        return None, None

    hands = list(result.multi_hand_landmarks)
    handed = list(getattr(result, "multi_handedness", []) or [])

    pairs: list[tuple[str, np.ndarray]] = []
    for i, hnd in enumerate(hands):
        lm = np.array([[lm.x, lm.y] for lm in hnd.landmark], dtype=np.float32)
        lm[:, 0] *= float(img_w)
        lm[:, 1] *= float(img_h)
        label = ""
        try:
            if i < len(handed) and handed[i].classification:
                label = str(handed[i].classification[0].label).lower()
        except Exception:
            label = ""
        pairs.append((label, lm))

    left_xy = None
    right_xy = None
    for label, lm in pairs:
        if "left" in label and left_xy is None:
            left_xy = lm
        elif "right" in label and right_xy is None:
            right_xy = lm

    # Fallback: sort by x center (camera view) if handedness missing
    if left_xy is None and right_xy is None and pairs:
        pairs2 = sorted(pairs, key=lambda t: float(np.mean(t[1][:, 0])))
        if len(pairs2) == 1:
            # unknown, treat as right for UI
            right_xy = pairs2[0][1]
        else:
            left_xy = pairs2[0][1]
            right_xy = pairs2[-1][1]
    return left_xy, right_xy


def frame_to_hands126(frame_bgr, holistic) -> tuple[np.ndarray, object]:
    """单帧 -> (126维双手关键点, holistic_result)"""
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    result = holistic.process(rgb)
    keypoints = []
    for hand in (result.left_hand_landmarks, result.right_hand_landmarks):
        if hand is None:
            keypoints.extend([0.0] * (21 * 3))
        else:
            for lm in hand.landmark:
                keypoints.extend([lm.x, lm.y, lm.z])
    return np.asarray(keypoints, dtype=np.float32), result


def hand_presence_score(kp: np.ndarray) -> float:
    """Rough visibility score in [0,1], based on non-zero keypoints."""
    if kp.size == 0:
        return 0.0
    nz = float(np.count_nonzero(np.abs(kp) > 1e-6))
    return nz / float(kp.size)


def try_load_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path(r"C:\Windows\Fonts\msyh.ttc"),
        Path(r"C:\Windows\Fonts\msyhbd.ttc"),
        Path(r"C:\Windows\Fonts\simhei.ttf"),
    ]
    for p in candidates:
        if p.is_file():
            try:
                return ImageFont.truetype(str(p), size=size)
            except OSError:
                continue
    return ImageFont.load_default()


def wrap_text(draw, text: str, font, max_width: int) -> list[str]:
    if not text:
        return [""]
    lines: list[str] = []
    for para in text.split("\n"):
        cur = ""
        for ch in para:
            test = cur + ch
            try:
                w = draw.textlength(test, font=font)
            except Exception:
                w = len(test) * 10
            if w <= max_width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = ch
        if cur:
            lines.append(cur)
    return lines or [""]


def build_side_panel(
    width: int,
    height: int,
    zh_word: str,
    en_word: str,
    gloss_id: str,
    sentence_zh: str,
    draft_zh: str,
    hand_status: str,
    translation_status: str,
    fusion_pred_text: str,
    template_pred_text: str,
    font_title,
    font_body,
    skeleton_match_text: str = "",
    skeleton_mlp_text: str = "",
) -> np.ndarray:
    img = Image.new("RGB", (width, height), (245, 245, 245))
    draw = ImageDraw.Draw(img)
    pad = 12
    draw.rectangle([0, 0, width - 1, height - 1], outline=(180, 180, 180), width=2)
    draw.text((pad, pad), "实时翻译 / Live Translation", fill=(40, 40, 40), font=font_title)
    draw.text((pad, pad + 28), translation_status, fill=(80, 80, 80), font=font_body)
    draw.text((pad, pad + 52), hand_status, fill=(100, 100, 110), font=font_body)
    draw.text((pad, pad + 76), f"image预测: {fusion_pred_text}", fill=(90, 90, 120), font=font_body)
    draw.text((pad, pad + 100), f"motion状态: {template_pred_text}", fill=(90, 120, 90), font=font_body)
    y_line = pad + 124
    if skeleton_match_text:
        draw.text((pad, y_line), f"骨骼序列匹配: {skeleton_match_text}", fill=(130, 40, 40), font=font_body)
        y_line += 26
    if skeleton_mlp_text:
        draw.text((pad, y_line), f"骨骼MLP: {skeleton_mlp_text}", fill=(40, 70, 130), font=font_body)
        y_line += 26
    y_meta = y_line + 2

    y = y_meta
    draw.text((pad, y), "手语表达含义", fill=(80, 80, 80), font=font_body)
    y += 26
    for line in wrap_text(draw, sentence_zh, font_body, width - 2 * pad):
        draw.text((pad, y), line, fill=(20, 20, 20), font=font_body)
        y += int(font_body.size * 1.25) if hasattr(font_body, "size") else 22
        if y > height - 170:
            break

    y = max(y + 10, height // 2 - 30)
    draw.text((pad, y), "实时候选含义", fill=(80, 80, 80), font=font_body)
    y += 26
    for line in wrap_text(draw, draft_zh, font_body, width - 2 * pad):
        draw.text((pad, y), line, fill=(10, 80, 40), font=font_body)
        y += int(font_body.size * 1.25) if hasattr(font_body, "size") else 22
        if y > height - 90:
            break

    y = max(y + 6, height // 2 + 60)
    draw.text((pad, y), "当前识别", fill=(80, 80, 80), font=font_body)
    y += 26
    cur = f"{zh_word}  ({en_word})" if zh_word and en_word else (zh_word or en_word)
    for line in wrap_text(draw, cur, font_body, width - 2 * pad):
        draw.text((pad, y), line, fill=(40, 40, 90), font=font_body)
        y += int(font_body.size * 1.25) if hasattr(font_body, "size") else 22
        if y > height - 48:
            break

    draw.text((pad, height - 28), f"词目 ID: {gloss_id}", fill=(120, 120, 120), font=font_body)
    return np.array(img)[:, :, ::-1]  # RGB -> BGR for OpenCV stack


def build_bottom_bar(
    width: int,
    height: int,
    conf_pct: float,
    smooth_label: str,
    motion_score: float,
    hand_score: float,
    font,
) -> np.ndarray:
    """
    Bottom status bar (BGR).

    Use OpenCV drawing to avoid per-frame PIL->NumPy conversion overhead.
    """
    w = int(width)
    h = int(height)
    bar = np.full((h, w, 3), (240, 235, 230), dtype=np.uint8)
    cv2.rectangle(bar, (0, 0), (w - 1, h - 1), (170, 160, 160), 1)
    t1 = f"conf: {conf_pct:.1f}% | smooth: {smooth_label}"
    t2 = f"motion: {motion_score:.4f} | hand: {hand_score:.2f}"
    cv2.putText(bar, t1, (12, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (35, 25, 25), 2, cv2.LINE_AA)
    cv2.putText(bar, t1, (12, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (15, 15, 15), 1, cv2.LINE_AA)
    cv2.putText(bar, t2, (12, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (110, 100, 90), 2, cv2.LINE_AA)
    cv2.putText(bar, t2, (12, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (60, 60, 60), 1, cv2.LINE_AA)
    return bar


def draw_warmup_overlay(frame_bgr: np.ndarray, warmup_left_s: float) -> np.ndarray:
    if warmup_left_s <= 0:
        return frame_bgr
    h, w = frame_bgr.shape[:2]
    overlay = frame_bgr.copy()
    cv2.rectangle(overlay, (0, 0), (w, h), (0, 0, 0), thickness=-1)
    alpha = 0.28
    out = cv2.addWeighted(overlay, alpha, frame_bgr, 1 - alpha, 0.0)

    t1 = f"采集中... {warmup_left_s:.1f}s"
    t2 = "请先保持手势在镜头内"
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale1, scale2 = 1.35, 0.85
    thick1, thick2 = 3, 2
    (tw1, th1), _ = cv2.getTextSize(t1, font, scale1, thick1)
    (tw2, th2), _ = cv2.getTextSize(t2, font, scale2, thick2)
    x1 = max(12, (w - tw1) // 2)
    y1 = max(40, h // 2 - 10)
    x2 = max(12, (w - tw2) // 2)
    y2 = y1 + th1 + 28
    cv2.putText(out, t1, (x1, y1), font, scale1, (0, 0, 0), thick1 + 3, cv2.LINE_AA)
    cv2.putText(out, t1, (x1, y1), font, scale1, (255, 255, 255), thick1, cv2.LINE_AA)
    cv2.putText(out, t2, (x2, y2), font, scale2, (0, 0, 0), thick2 + 2, cv2.LINE_AA)
    cv2.putText(out, t2, (x2, y2), font, scale2, (240, 240, 240), thick2, cv2.LINE_AA)
    return out


class LiveSentenceTranslator:
    def __init__(self, base_dir: Path, model_dir: Path, device: torch.device):
        self.base_dir = base_dir
        self.model_dir = model_dir
        self.device = device
        self.model = None
        self.src_vocab = None
        self.tgt_vocab = None
        self.ready = False
        self.manifest_map = load_id_to_zh_from_manifest(base_dir / "outputs" / "cslr_manifest.csv")
        self.gloss_map = load_id_to_zh_from_gloss(base_dir.parent / "gloss.csv")
        self.exact_library = load_exact_library_map(base_dir / "outputs" / "translation_library.csv")
        self._try_load_model()

    def _try_load_model(self) -> None:
        cfg_path = self.model_dir / "config.json"
        src_vocab_path = self.model_dir / "src_vocab.json"
        tgt_vocab_path = self.model_dir / "tgt_vocab.json"
        ckpt_path = self.model_dir / "best_interpretive_scheme.pt"
        if not (cfg_path.exists() and src_vocab_path.exists() and tgt_vocab_path.exists() and ckpt_path.exists()):
            return
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            self.src_vocab = load_vocab(src_vocab_path)
            self.tgt_vocab = load_vocab(tgt_vocab_path)
            self.model = Seq2SeqTransformer(
                src_vocab_size=self.src_vocab.size,
                tgt_vocab_size=self.tgt_vocab.size,
                d_model=cfg["d_model"],
                nhead=cfg["nhead"],
                num_layers=cfg["num_layers"],
                dim_ff=cfg["dim_ff"],
                dropout=0.0,
            ).to(self.device)
            try:
                state = torch.load(ckpt_path, map_location=self.device, weights_only=True)
            except TypeError:
                state = torch.load(ckpt_path, map_location=self.device)
            self.model.load_state_dict(state)
            self.model.eval()
            self.ready = True
        except Exception:
            self.ready = False

    def _dict_fallback(self, id_tokens: list[str]) -> str:
        words = []
        for t in id_tokens:
            key = str(int(t)) if t.isdigit() else t
            w = self.manifest_map.get(key) or self.gloss_map.get(key) or f"[{t}]"
            words.append(w)
        return compose_natural_sentence(words)

    def translate_ids(self, id_tokens: list[str], max_len: int = 32) -> str:
        if not id_tokens:
            return ""
        lib_key = canonicalize_src_key(" ".join(id_tokens))
        if lib_key in self.exact_library:
            return normalize_zh_gloss(self.exact_library[lib_key])
        if not self.ready:
            return self._dict_fallback(id_tokens)
        try:
            src_tokens = canonicalize_gloss_id_tokens(tokenize_src(" ".join(id_tokens)))
            src_ids = self.src_vocab.encode(src_tokens, add_bos_eos=True)
            zh = greedy_translate(
                self.model,
                src_ids,
                self.src_vocab,
                self.tgt_vocab,
                device=self.device,
                max_len=max_len,
            )
            zh = normalize_zh_gloss(zh)
            return zh if zh.strip() else self._dict_fallback(id_tokens)
        except Exception:
            return self._dict_fallback(id_tokens)


def main() -> None:
    parser = argparse.ArgumentParser(description="摄像头实时手语识别 + 翻译侧栏")
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help=(
            "模型权重路径。\n"
            "- 若为 train_fusion.py 产物（DualStreamFusionRecognizer state_dict），自动进入 fusion/pose 模式；\n"
            "- 若为 train_image.py 产物（ResNet/EfficientNet），自动进入 image 模式。\n"
            "不传则默认选择 outputs/image 最新 run（推荐：与图片数据集类别对齐），否则选择 outputs/fusion/best_fusion_model.pt。"
        ),
    )
    parser.add_argument(
        "--prefer",
        type=str,
        default="image",
        choices=["image", "fusion"],
        help="不指定 --checkpoint 时的默认优先级：image=优先用 train_image.py 的最新 run；fusion=优先用 train_fusion.py 的 best 模型",
    )
    parser.add_argument(
        "--train_log",
        type=str,
        default=None,
        help="训练记录.json 路径（用于读取 arch/image_size/class_to_idx）。默认自动选择与 checkpoint 同 run 的 训练记录.json。",
    )
    parser.add_argument("--gloss", type=str, default=r"..\gloss.csv")
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument(
        "--video",
        type=str,
        default="",
        help="可选：用视频文件/目录作为输入源（用于离线验证）。传入后将忽略 --camera。目录下默认读取 *.mp4。",
    )
    parser.add_argument("--max_videos", type=int, default=0, help="--video 为目录时最多跑前 N 个视频（0=全部）")
    parser.add_argument(
        "--playback_speed",
        type=float,
        default=1.0,
        help="仅视频模式：播放速度倍率（0.5=半速验证，1.0=正常，2.0=两倍）。",
    )
    parser.add_argument("--infer_every", type=int, default=2, help="每隔多少帧推理一次（默认更实时）")
    parser.add_argument("--smooth_k", type=int, default=7, help="多数投票窗口大小")
    parser.add_argument("--commit_conf", type=float, default=0.35, help="把当前词提交进中文输出的最低置信度(0-1)")
    parser.add_argument("--commit_hold", type=int, default=1, help="同一词连续稳定多少次才提交（默认更实时）")
    parser.add_argument("--repeat_gap_frames", type=int, default=30, help="同一词再次提交前至少间隔多少帧")
    parser.add_argument("--motion_threshold", type=float, default=0.010, help="画面变化阈值（平均像素差），超过视为手势有变化")
    parser.add_argument("--warmup_seconds", type=float, default=5.0, help="启动后先持续采集 N 秒画面再开始推理（默认 5 秒）")
    parser.add_argument("--idle_reset_frames", type=int, default=45, help="连续静止多少帧后自动清空历史，避免卡死旧结果")
    parser.add_argument("--idle_ui_frames", type=int, default=12, help="连续无关键点位移的推理次数超过该值时，右侧不再把静止画面当成手语翻译")
    parser.add_argument("--skip_motion_arm", action="store_true", help="关闭「先检测到动作变化再提交词」保护（旧行为，静止时更容易误报）")
    parser.add_argument("--max_tokens", type=int, default=12, help="右侧中文输出最多保留多少个词")
    parser.add_argument("--translation_model_dir", type=str, default="outputs/interpretive_scheme")
    # Default: DO NOT load sentence model, to avoid forcing outputs into a tiny fixed-sentence space.
    # Users can opt-in when they really want a sentence-level paraphrase.
    parser.add_argument(
        "--enable_sentence_model",
        action="store_true",
        help="Enable interpretive_scheme sentence model (optional). Default is OFF; UI will output token sequence.",
    )
    # Backward compatible flag (previous versions used disable_sentence_model with default ON).
    parser.add_argument(
        "--disable_sentence_model",
        action="store_true",
        help="(Deprecated) Disable interpretive_scheme sentence model. Sentence model is already OFF by default.",
    )
    parser.add_argument("--side_width", type=int, default=420)
    parser.add_argument("--draw_kp", action="store_true", help="在摄像头画面上叠加 MediaPipe 关键点/骨架（类似示例图）")
    parser.add_argument("--draw_pose", action="store_true", help="--draw_kp 时额外绘制 pose 骨架（默认只画手）")
    parser.add_argument("--draw_face_box", action="store_true", help="--draw_kp 时绘制人脸框（默认关闭，避免干扰手语主体）")
    _hroi = parser.add_mutually_exclusive_group()
    _hroi.add_argument(
        "--draw_hand_roi",
        dest="draw_hand_roi",
        action="store_true",
        help="--draw_kp 时在双手关键点外包黄色 ROI（默认开启，便于对齐「识别主体是手」）",
    )
    _hroi.add_argument("--no-draw_hand_roi", dest="draw_hand_roi", action="store_false", help="不绘制手部 ROI 框")
    parser.set_defaults(draw_hand_roi=True)
    _aroi = parser.add_mutually_exclusive_group()
    _aroi.add_argument(
        "--draw_arm_roi",
        dest="draw_arm_roi",
        action="store_true",
        help="用 Pose 肩/肘/腕画红色上肢 ROI（默认开；需 holistic + pose 检测结果）",
    )
    _aroi.add_argument("--no-draw_arm_roi", dest="draw_arm_roi", action="store_false", help="不绘制红色手臂 ROI")
    parser.set_defaults(draw_arm_roi=True)
    parser.add_argument(
        "--kp_source",
        type=str,
        default="hands",
        choices=["hands", "holistic"],
        help="骨骼关键点来源：hands=更专注手指、更准；holistic=与 fusion hands126 同源",
    )
    parser.add_argument("--hands_model_complexity", type=int, default=1, choices=[0, 1], help="MediaPipe Hands 模型复杂度（1 更准更慢）")
    parser.add_argument("--hands_min_det", type=float, default=0.6, help="Hands min_detection_confidence（建议 >=0.6）")
    parser.add_argument("--hands_min_track", type=float, default=0.6, help="Hands min_tracking_confidence（建议 >=0.6）")
    parser.add_argument("--kp_smooth_alpha", type=float, default=0.7, help="关键点平滑系数(0-1)，越大越平滑")
    parser.add_argument(
        "--skeleton_match_index",
        type=str,
        default="",
        help="extract 导出的 skeleton_corpus/skeleton_match_index.npz：用实时 144 维序列与模板比对（连续手语近似对齐）。",
    )
    parser.add_argument("--skeleton_match_len", type=int, default=16, help="骨骼模板与实况重采样到该长度后算帧均 L2")
    parser.add_argument(
        "--skeleton_match_threshold",
        type=float,
        default=2.4,
        help=(
            "骨骼序列距离上限：低于该值视为「可靠匹配」。默认 2.4 对应 metric=hands_l2（仅双手126维帧均L2）；"
            "若用 cosine_flat 请改约 0.25–0.45；full_l2 全144维可略增大。"
        ),
    )
    parser.add_argument(
        "--skeleton_match_metric",
        type=str,
        default="hands_l2",
        choices=["hands_l2", "full_l2", "cosine_flat"],
        help="hands_l2=仅双手126维（默认，抗躯干/镜头位移）；full_l2=144维；cosine_flat=双手拼接余弦距离",
    )
    parser.add_argument("--skeleton_buffer", type=int, default=48, help="保留最近多少帧的骨骼特征用于序列匹配")
    parser.add_argument("--skeleton_min_frames", type=int, default=8, help="缓冲至少多少帧后才输出骨骼匹配结果")
    parser.add_argument(
        "--skeleton_mlp_checkpoint",
        type=str,
        default="",
        help="train_skeleton_sequence.py 导出的 best_skeleton_frame_mlp.pt：每帧用 144 维骨骼做分类（侧栏「骨骼MLP」）。",
    )
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    outputs_image_dir = (base / "outputs" / "image").resolve()
    outputs_fusion_best = (base / "outputs" / "fusion" / "best_fusion_model.pt").resolve()

    skel_matcher = None
    _ski = str(getattr(args, "skeleton_match_index", "") or "").strip()
    if _ski:
        _sp = Path(_ski)
        _sp = _sp.resolve() if _sp.is_absolute() else (base / _ski).resolve()
        if _sp.is_file():
            try:
                from skeleton_corpus import SkeletonSequenceMatcher

                skel_matcher = SkeletonSequenceMatcher(
                    _sp,
                    match_len=int(getattr(args, "skeleton_match_len", 16)),
                    low_threshold=float(getattr(args, "skeleton_match_threshold", 2.4)),
                    metric=str(getattr(args, "skeleton_match_metric", "hands_l2")),
                )
                print(
                    f"[camera_interface] skeleton_match_index: {_sp} | templates={len(skel_matcher.gloss_ids)} "
                    f"| metric={getattr(args, 'skeleton_match_metric', 'hands_l2')} thr={float(getattr(args, 'skeleton_match_threshold', 2.4))}"
                )
            except Exception as e:
                print(f"WARN: skeleton_match_index 未能加载 {_sp}: {e}")
                skel_matcher = None
        else:
            print(f"WARN: skeleton_match_index 路径不存在: {_sp}")

    if args.checkpoint:
        ckpt = (base / args.checkpoint).resolve()
        if args.train_log is None:
            cand = ckpt.parent / "训练记录.json"
            if cand.is_file():
                args.train_log = str(cand)
    else:
        ckpt = None
        auto_log = None
        if args.prefer == "image":
            ckpt, auto_log = pick_latest_image_run(outputs_image_dir)
            if ckpt is None and outputs_fusion_best.is_file():
                ckpt = outputs_fusion_best
        else:
            if outputs_fusion_best.is_file():
                ckpt = outputs_fusion_best
            else:
                ckpt, auto_log = pick_latest_image_run(outputs_image_dir)
        if ckpt is None:
            raise FileNotFoundError("未找到可用模型权重。请先训练 train_image.py（推荐）或 train_fusion.py，或手动指定 --checkpoint。")
        if args.train_log is None and auto_log is not None:
            args.train_log = str(auto_log)

    ckpt = ckpt.resolve()
    gloss_path = (base / args.gloss).resolve()
    if not ckpt.is_file():
        raise FileNotFoundError(f"未找到权重: {ckpt}")
    if not gloss_path.is_file():
        raise FileNotFoundError(f"未找到 gloss: {gloss_path}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    payload = _torch_load_safely(ckpt, map_location="cpu")
    if isinstance(payload, dict) and "model_state_dict" in payload:
        probe_state = payload["model_state_dict"]
    elif isinstance(payload, dict) and "state_dict" in payload:
        probe_state = payload["state_dict"]
    else:
        probe_state = payload
    if not isinstance(probe_state, dict):
        raise RuntimeError(f"Unsupported checkpoint format: {ckpt}")
    probe_state = _normalize_state_dict(probe_state)
    use_fusion = _looks_like_fusion_state(probe_state)

    log_p = (base / args.train_log).resolve() if args.train_log else None
    arch, image_size, class_to_idx = (None, None, None)
    idx_to_class: dict[int, str] = {}
    rgb_dim = 0
    pose_dim = 0
    fusion_idx_to_gid: dict[int, int] | None = None
    image_labels_are_gloss_ids = False

    if use_fusion:
        model, rgb_dim, pose_dim = load_fusion_model(ckpt, device)
        fusion_idx_to_gid = load_fusion_label_map(ckpt)
        if int(pose_dim) != 126:
            raise RuntimeError("fusion checkpoint pose_dim 与摄像头端 hands126 不匹配。")
    else:
        arch, image_size, class_to_idx = load_image_training_log(log_p) if log_p is not None else (None, None, None)
        num_classes = len(class_to_idx) if isinstance(class_to_idx, dict) else None
        model = load_image_model(ckpt, device, arch=arch, num_classes=num_classes)
        if isinstance(class_to_idx, dict) and class_to_idx:
            idx_to_class = {int(v): str(k) for k, v in class_to_idx.items()}
            image_labels_are_gloss_ids = _class_labels_look_like_gloss_ids(class_to_idx)

    gloss = load_gloss_map(gloss_path)
    # High-signal print: confirm which glossary is used.
    print(f"Glossary loaded: {gloss_path} | entries={len(gloss)}")

    skel_mlp_model: torch.nn.Module | None = None
    skel_mlp_meta: dict | None = None
    _sk_mlp = str(getattr(args, "skeleton_mlp_checkpoint", "") or "").strip()
    if _sk_mlp:
        _skp = Path(_sk_mlp)
        _skp = _skp.resolve() if _skp.is_absolute() else (base / _sk_mlp).resolve()
        if _skp.is_file():
            try:
                skel_mlp_model, skel_mlp_meta = _load_skeleton_mlp_checkpoint(_skp, device)
                nc = int(skel_mlp_meta.get("num_classes", 0))
                print(f"[camera_interface] skeleton MLP loaded: {_skp} | classes={nc}")
            except Exception as e:
                print(f"WARN: skeleton_mlp_checkpoint 未能加载 {_skp}: {e}")
                skel_mlp_model, skel_mlp_meta = None, None
        else:
            print(f"WARN: skeleton_mlp_checkpoint 路径不存在: {_skp}")
    trans_model_dir = (base / args.translation_model_dir).resolve()
    sentence_translator = None
    enable_sentence = bool(getattr(args, "enable_sentence_model", False)) and (not bool(getattr(args, "disable_sentence_model", False)))
    if enable_sentence:
        sentence_translator = LiveSentenceTranslator(base, trans_model_dir, device)

    image_size = int(image_size) if image_size is not None else 224
    infer_tf = transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )

    holistic = None
    holistic_vis = None
    hands_vis = None
    buf: deque[np.ndarray] | None = None
    last_mp_result = None
    last_left_xy: np.ndarray | None = None
    last_right_xy: np.ndarray | None = None
    if use_fusion:
        import mediapipe as mp

        holistic = mp.solutions.holistic.Holistic(
            static_image_mode=False,
            model_complexity=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        buf = deque(maxlen=64)
    elif bool(args.draw_kp) and str(args.kp_source).strip().lower() == "holistic":
        # Image 模式：Holistic 仅用于叠加绘制（与 CNN 输入无关）；骨骼匹配另见下方 skel 专用实例。
        import mediapipe as mp

        holistic_vis = mp.solutions.holistic.Holistic(
            static_image_mode=False,
            model_complexity=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )
    elif bool(args.draw_kp) and str(args.kp_source).strip().lower() == "hands":
        import mediapipe as mp

        hands_vis = mp.solutions.hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            model_complexity=int(args.hands_model_complexity),
            min_detection_confidence=float(args.hands_min_det),
            min_tracking_confidence=float(args.hands_min_track),
        )
    if (skel_matcher is not None or skel_mlp_model is not None) and not use_fusion and holistic_vis is None:
        import mediapipe as mp

        holistic_vis = mp.solutions.holistic.Holistic(
            static_image_mode=False,
            model_complexity=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

    # Input source: camera or video file/dir.
    video_list: list[Path] = []
    cap = None
    video_fps = 0.0
    if str(getattr(args, "video", "")).strip():
        v = Path(str(args.video).strip())
        v = v.resolve() if v.is_absolute() else (base / v).resolve()
        if v.is_dir():
            video_list = sorted([p for p in v.glob("*.mp4") if p.is_file()], key=lambda p: p.name.lower())
            if int(args.max_videos) > 0:
                video_list = video_list[: int(args.max_videos)]
            if not video_list:
                raise FileNotFoundError(f"--video 目录下未找到 mp4: {v}")
        elif v.is_file():
            video_list = [v]
        else:
            raise FileNotFoundError(f"--video 输入不存在: {v}")
        cap = cv2.VideoCapture(str(video_list[0]))
        if not cap.isOpened():
            raise RuntimeError(f"无法打开视频: {video_list[0]}")
        try:
            video_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        except Exception:
            video_fps = 0.0
        print(f"[camera_interface] video input: {video_list[0]} ({1}/{len(video_list)})")
    else:
        cap = cv2.VideoCapture(args.camera)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    pred_hist: deque[int] = deque(maxlen=args.smooth_k)
    stable_hist: deque[int] = deque(maxlen=args.commit_hold)
    tokens_zh: deque[str] = deque(maxlen=args.max_tokens)
    token_ids: deque[str] = deque(maxlen=args.max_tokens)
    draft_ids: deque[str] = deque(maxlen=max(4, args.max_tokens))
    skel_buf: deque[np.ndarray] | None = (
        deque(maxlen=int(getattr(args, "skeleton_buffer", 48))) if skel_matcher is not None else None
    )
    last_skel_line = ""
    last_skel_mlp_line = ""
    frame_i = 0
    last_id = 0
    last_conf = 0.0
    has_infer = False
    last_committed_id: int | None = None
    last_commit_frame = -10**9
    motion_score = 0.0
    idle_frames = 0
    motion_armed = False
    last_frame_gray: np.ndarray | None = None

    font_title = try_load_font(20)
    font_body = try_load_font(18)
    font_bar = try_load_font(16)

    print("按 Q 或 ESC 退出。窗口左侧为摄像头，右侧为翻译，底部为置信度。")
    print(f"设备: {device}  权重: {ckpt}")
    if log_p is not None:
        print(f"训练记录: {log_p}")
    if idx_to_class:
        print(f"类别数: {len(idx_to_class)} | arch={arch or 'resnet18'} | image_size={image_size}")

    warmup_start_t = time.time()
    warmup_s = max(0.0, float(args.warmup_seconds))
    # Offline video validation should not be blocked by a long warmup.
    if str(getattr(args, "video", "")).strip() and warmup_s > 0.0:
        warmup_s = 0.0

    vid_i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            # If in video mode, advance to next video.
            if video_list and (vid_i + 1) < len(video_list):
                vid_i += 1
                cap.release()
                cap = cv2.VideoCapture(str(video_list[vid_i]))
                if not cap.isOpened():
                    raise RuntimeError(f"无法打开视频: {video_list[vid_i]}")
                try:
                    video_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
                except Exception:
                    video_fps = 0.0
                print(f"[camera_interface] video input: {video_list[vid_i]} ({vid_i+1}/{len(video_list)})")
                # reset warmup per video
                warmup_start_t = time.time()
                frame_i = 0
                continue
            break
        frame_i += 1
        hol_for_skel = None  # Holistic 结果（骨骼 MLP / 模板），勿被 Hands 覆盖

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray_small = cv2.resize(gray, (160, 120), interpolation=cv2.INTER_AREA)
        if last_frame_gray is not None:
            motion_score = float(np.mean(np.abs(gray_small.astype(np.float32) - last_frame_gray.astype(np.float32))) / 255.0)
        else:
            motion_score = 0.0
        last_frame_gray = gray_small

        elapsed = time.time() - warmup_start_t
        warmup_left = max(0.0, warmup_s - elapsed)
        allow_infer = warmup_left <= 1e-6
        infer_event = allow_infer and (frame_i % args.infer_every == 0)

        if infer_event:
            if use_fusion:
                assert holistic is not None and buf is not None
                try:
                    kp, last_mp_result = frame_to_hands126(frame, holistic)
                except Exception:
                    kp, last_mp_result = np.zeros(126, dtype=np.float32), None
                buf.append(kp)
                if skel_matcher is not None and skel_buf is not None and last_mp_result is not None:
                    from skeleton_corpus import feature144_from_holistic_result

                    skel_buf.append(feature144_from_holistic_result(last_mp_result))
                if len(buf) >= 8:
                    pose = np.stack(list(buf), axis=0).astype(np.float32)
                    pose_t = torch.from_numpy(pose).unsqueeze(0).to(device)
                    rgb_t = torch.zeros(1, int(rgb_dim), device=device)
                    with torch.no_grad():
                        logits = model(rgb_t, pose_t)
                        probs = torch.softmax(logits, dim=-1)
                        last_conf = float(probs.max().item())
                        last_id = int(logits.argmax(dim=-1).item())
                    pred_hist.append(last_id)
                    has_infer = True
                    if not draft_ids or str(draft_ids[-1]) != str(last_id):
                        draft_ids.append(str(last_id))
                else:
                    has_infer = False
            else:
                # Holistic 先于 Hands：前者提供肩肘腕+双手模板对齐；Hands 专用于手指叠加时可再跑一遍。
                if holistic_vis is not None:
                    try:
                        rgb_vis = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        last_mp_result = holistic_vis.process(rgb_vis)
                        hol_for_skel = last_mp_result
                    except Exception:
                        last_mp_result = None
                    if skel_matcher is not None and skel_buf is not None and last_mp_result is not None:
                        from skeleton_corpus import feature144_from_holistic_result

                        skel_buf.append(feature144_from_holistic_result(last_mp_result))
                if hands_vis is not None:
                    try:
                        rgb_vis = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        res = hands_vis.process(rgb_vis)
                        h0, w0 = frame.shape[:2]
                        left_xy, right_xy = _extract_lr_hands_from_mp_hands(res, img_w=w0, img_h=h0)
                        a = float(max(0.0, min(1.0, float(args.kp_smooth_alpha))))
                        if left_xy is not None:
                            last_left_xy = left_xy if last_left_xy is None else (a * last_left_xy + (1.0 - a) * left_xy)
                        if right_xy is not None:
                            last_right_xy = right_xy if last_right_xy is None else (a * last_right_xy + (1.0 - a) * right_xy)
                        last_mp_result = res
                    except Exception:
                        if holistic_vis is None:
                            last_mp_result = None
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pil = Image.fromarray(rgb)
                x = infer_tf(pil).unsqueeze(0).to(device)
                with torch.no_grad():
                    logits = model(x)
                    probs = torch.softmax(logits, dim=-1)
                    last_conf = float(probs.max().item())
                    last_id = int(logits.argmax(dim=-1).item())
                pred_hist.append(last_id)
                has_infer = True
                if not draft_ids or str(draft_ids[-1]) != str(last_id):
                    draft_ids.append(str(last_id))
            if skel_matcher is not None and skel_buf is not None and len(skel_buf) >= int(
                getattr(args, "skeleton_min_frames", 8)
            ):
                try:
                    live = np.stack(list(skel_buf), axis=0)
                    _gid, _zh, _d, _weak = skel_matcher.match(live)
                    if _zh:
                        last_skel_line = f"{_zh}（{_d:.3f}）" + (" 弱匹配" if _weak else "")
                    else:
                        last_skel_line = f"无模板（{_d:.3f}）"
                except Exception:
                    last_skel_line = ""
            if (
                infer_event
                and skel_mlp_model is not None
                and skel_mlp_meta is not None
            ):
                from skeleton_corpus import feature144_from_holistic_result

                mlp_src = last_mp_result if use_fusion else hol_for_skel
                if mlp_src is None and not use_fusion:
                    mlp_src = last_mp_result
                if mlp_src is not None:
                    try:
                        f144 = feature144_from_holistic_result(mlp_src)
                        zh_m, gid_m, cf = _infer_skeleton_mlp_one_frame(
                            skel_mlp_model, skel_mlp_meta, f144, device
                        )
                        last_skel_mlp_line = f"{zh_m}  [{gid_m}] {cf * 100:.1f}%"
                    except Exception:
                        pass
        elif not allow_infer:
            has_infer = False

        smooth_id = max(set(pred_hist), key=list(pred_hist).count) if pred_hist else last_id

        if infer_event:
            stable_hist.append(smooth_id)
            can_repeat = (frame_i - last_commit_frame) >= args.repeat_gap_frames
            changed_motion = motion_score >= args.motion_threshold
            if changed_motion:
                idle_frames = 0
                motion_armed = True
            else:
                idle_frames += 1
            motion_ok_for_commit = args.skip_motion_arm or motion_armed
            if (
                len(stable_hist) == args.commit_hold
                and len(set(stable_hist)) == 1
                and last_conf >= args.commit_conf
                and motion_ok_for_commit
                and (last_committed_id != stable_hist[-1] or (last_committed_id == stable_hist[-1] and can_repeat and changed_motion))
            ):
                commit_id = stable_hist[-1]
                if use_fusion:
                    if fusion_idx_to_gid is not None and int(commit_id) in fusion_idx_to_gid:
                        cls_label = str(int(fusion_idx_to_gid[int(commit_id)]))
                    else:
                        cls_label = str(int(commit_id))
                else:
                    cls_label = idx_to_class.get(int(commit_id), str(int(commit_id)))

                if (not use_fusion) and (not image_labels_are_gloss_ids):
                    tokens_zh.append(str(cls_label))
                    token_ids.append(str(cls_label))
                else:
                    gid = -1
                    if str(cls_label).isdigit():
                        gid = int(str(cls_label))
                    else:
                        try:
                            gid = parse_label_from_name(str(cls_label))
                        except Exception:
                            gid = -1
                    if gid >= 0:
                        sid_commit = f"{gid:04d}"
                        zh_commit = _gloss_zh(gloss, gid)
                        tokens_zh.append(zh_commit if zh_commit else str(cls_label))
                        token_ids.append(str(gid))
                    else:
                        tokens_zh.append(str(cls_label))
                        token_ids.append(str(cls_label))

                last_committed_id = commit_id
                last_commit_frame = frame_i
                stable_hist.clear()
                motion_armed = False

            if idle_frames >= args.idle_reset_frames:
                pred_hist.clear()
                stable_hist.clear()
                draft_ids.clear()
                idle_frames = 0
                motion_armed = False

        if not has_infer:
            zh_word, en_word = "请面向摄像头做手语…", "Show your hands to the camera."
            sid = "----"
        else:
            if use_fusion:
                if fusion_idx_to_gid is not None and int(smooth_id) in fusion_idx_to_gid:
                    cls_label = str(int(fusion_idx_to_gid[int(smooth_id)]))
                else:
                    cls_label = str(int(smooth_id))
            else:
                cls_label = idx_to_class.get(int(smooth_id), str(int(smooth_id)))

            if (not use_fusion) and (not image_labels_are_gloss_ids):
                sid = str(cls_label)
                zh_word, en_word = str(cls_label), ""
            else:
                gid = -1
                if str(cls_label).isdigit():
                    gid = int(str(cls_label))
                else:
                    try:
                        gid = parse_label_from_name(str(cls_label))
                    except Exception:
                        gid = -1
                if gid >= 0:
                    sid = f"{gid:04d}"
                    zh_word = _gloss_zh(gloss, gid) or f"未知词条 {sid}"
                    en_word = ""
                else:
                    sid = str(cls_label)
                    zh_word, en_word = str(cls_label), str(cls_label)

        main = cv2.resize(frame, (640, 480))
        if warmup_left > 0 and warmup_s > 0:
            main = draw_warmup_overlay(main, warmup_left)
        # Visual overlay (fusion uses MediaPipe for inference; image mode uses MediaPipe for visualization only)
        if bool(args.draw_kp):
            if hands_vis is not None:
                # draw using high-quality Hands landmarks (better finger separation)
                h1, w1 = main.shape[:2]
                # map stored pixel coords from original frame to resized main
                sx = float(w1) / float(max(1, frame.shape[1]))
                sy = float(h1) / float(max(1, frame.shape[0]))
                left_ok = last_left_xy is not None
                right_ok = last_right_xy is not None
                if last_left_xy is not None:
                    lm = last_left_xy.copy()
                    lm[:, 0] *= sx
                    lm[:, 1] *= sy
                    main = _draw_hand_colored(main, lm, is_left=True)
                    ang = _finger_bend_angles(lm)
                    if ang:
                        cv2.putText(
                            main,
                            "L bend: " + " ".join([f"{k[0]}{int(v):03d}" for k, v in ang.items()]),
                            (12, 112),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.55,
                            (255, 255, 255),
                            2,
                            cv2.LINE_AA,
                        )
                if last_right_xy is not None:
                    lm = last_right_xy.copy()
                    lm[:, 0] *= sx
                    lm[:, 1] *= sy
                    main = _draw_hand_colored(main, lm, is_left=False)
                    ang = _finger_bend_angles(lm)
                    if ang:
                        cv2.putText(
                            main,
                            "R bend: " + " ".join([f"{k[0]}{int(v):03d}" for k, v in ang.items()]),
                            (12, 132),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.55,
                            (255, 255, 255),
                            2,
                            cv2.LINE_AA,
                        )
                main = _overlay_hand_status(main, left_ok=left_ok, right_ok=right_ok)
                if bool(getattr(args, "draw_hand_roi", True)):
                    mh, mw = main.shape[:2]
                    if last_left_xy is not None:
                        bb = _aabb_pixel_hand_xy(last_left_xy, mw, mh)
                        if bb is not None:
                            x1, y1, x2, y2 = bb
                            cv2.rectangle(main, (x1, y1), (x2, y2), (0, 255, 255), 2)
                            cv2.putText(main, "hand(L)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)
                    if last_right_xy is not None:
                        bb = _aabb_pixel_hand_xy(last_right_xy, mw, mh)
                        if bb is not None:
                            x1, y1, x2, y2 = bb
                            cv2.rectangle(main, (x1, y1), (x2, y2), (0, 255, 255), 2)
                            cv2.putText(main, "hand(R)", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)
            else:
                # draw on resized main to keep alignment
                # Note: last_mp_result comes from original frame; still ok because landmarks are normalized.
                main = _mp_draw_holistic(
                    main,
                    last_mp_result,
                    draw_face_box=bool(args.draw_face_box),
                    draw_hand_roi=bool(getattr(args, "draw_hand_roi", True)),
                    draw_arm_roi=bool(getattr(args, "draw_arm_roi", True)),
                    draw_pose=bool(args.draw_pose),
                    draw_hands=True,
                )
                # overlay a compact status like the sample screenshot
                left_ok = bool(getattr(last_mp_result, "left_hand_landmarks", None)) if last_mp_result is not None else False
                right_ok = bool(getattr(last_mp_result, "right_hand_landmarks", None)) if last_mp_result is not None else False
                main = _overlay_hand_status(main, left_ok=left_ok, right_ok=right_ok)
        panel_h = main.shape[0]

        static_for_ui = allow_infer and idle_frames >= args.idle_ui_frames
        show_live_meaning = not static_for_ui

        if token_ids:
            # Always display Chinese tokens on UI. The sentence model (if enabled) can still be used,
            # but we never show raw numeric IDs as "translation" to avoid confusion.
            if sentence_translator is not None and all(t.isdigit() for t in token_ids):
                try:
                    _model_zh = sentence_translator.translate_ids(list(token_ids))
                    # If model returns empty/degenerate output, fall back to token composition.
                    sentence_zh = _model_zh.strip() or compose_natural_sentence(list(tokens_zh))
                except Exception:
                    sentence_zh = compose_natural_sentence(list(tokens_zh))
            else:
                sentence_zh = compose_natural_sentence(list(tokens_zh))
            sentence_zh = to_colloquial_sentence(sentence_zh, list(tokens_zh))
        elif show_live_meaning and has_infer and sid != "----":
            cur_word = normalize_zh_gloss(zh_word)
            sentence_zh = f"我想表达“{cur_word}”。" if cur_word else "（当前动作暂无可用语义）"
        elif static_for_ui and not token_ids:
            sentence_zh = "（当前画面基本静止，未检测到手语动作；请做手势后再看译文）"
        else:
            sentence_zh = "（请做出清晰手语动作，系统将输出你要表达的意思）"

        draft_zh = "（检测到有效手势后，这里会实时变化）"
        if draft_ids and not static_for_ui:
            draft_seq = dedupe_consecutive_id_tokens(list(draft_ids))
            zh_tokens: list[str] = []
            for x in draft_seq:
                try:
                    cls_i = int(x)
                except Exception:
                    cls_i = -1
                cls_label = idx_to_class.get(cls_i, x)
                # For numeric IDs, map to Chinese via gloss.csv; otherwise show label as-is.
                if str(cls_label).isdigit():
                    zh = _gloss_zh(gloss, int(str(cls_label)))
                    zh_tokens.append(zh if zh else str(cls_label))
                else:
                    zh_tokens.append(str(cls_label))
            draft_zh = compose_natural_sentence(zh_tokens)
            draft_zh = to_colloquial_sentence(draft_zh, zh_tokens)
        elif show_live_meaning and has_infer and sid != "----":
            cur_word = normalize_zh_gloss(zh_word)
            draft_zh = f"实时草稿：{cur_word}" if cur_word else "（当前动作暂无可用语义）"
        elif static_for_ui:
            draft_zh = "（静止中：有手部跟踪不代表正在打手语）"

        translation_status = "句子模型: 已加载" if (sentence_translator is not None and sentence_translator.ready) else "句子模型: 未加载（词典回退）"
        if warmup_left > 0 and warmup_s > 0:
            translation_status = f"启动采集中…{warmup_left:.1f}s | {translation_status}"

        if use_fusion:
            hand_status = "模型: fusion(pose-only) | 输入: MediaPipe hands126"
            show_id = int(fusion_idx_to_gid[int(smooth_id)]) if (fusion_idx_to_gid is not None and int(smooth_id) in fusion_idx_to_gid) else int(smooth_id)
            fusion_pred_text = f"id={show_id:04d}  {last_conf * 100:.1f}%"
        else:
            hand_status = f"模型: image({arch or 'resnet18'}) | 输入: {image_size}x{image_size}"
            fusion_pred_text = f"label={idx_to_class.get(int(smooth_id), str(int(smooth_id)))}  {last_conf * 100:.1f}%"
        template_pred_text = f"motion={motion_score:.4f} idle={idle_frames}"

        side = build_side_panel(
            args.side_width,
            panel_h,
            zh_word,
            en_word,
            sid,
            sentence_zh,
            draft_zh,
            hand_status,
            translation_status,
            fusion_pred_text,
            template_pred_text,
            font_title,
            font_body,
            skeleton_match_text=last_skel_line,
            skeleton_mlp_text=last_skel_mlp_line,
        )

        top = np.hstack([main, side])
        bar_h = 56
        conf_pct = last_conf * 100.0 if has_infer else 0.0
        sid_vote = str(idx_to_class.get(int(smooth_id), smooth_id)) if has_infer else "----"
        tip = str(zh_word)[:12] if has_infer else "…"
        smooth_name = f"{sid_vote} ({tip})" if has_infer else "等待首帧推理"
        if len(smooth_name) > 44:
            smooth_name = smooth_name[:42] + "…"
        bottom = build_bottom_bar(top.shape[1], bar_h, conf_pct, smooth_name, motion_score, 1.0, font_bar)
        vis = np.vstack([top, bottom])

        cv2.imshow("SignLanguage — camera_interface (q 退出)", vis)
        # Video validation: slow down playback for easier inspection.
        wait_ms = 1
        if video_list:
            sp = float(getattr(args, "playback_speed", 1.0) or 1.0)
            sp = max(0.05, sp)
            fps = float(video_fps) if float(video_fps) > 1e-3 else 30.0
            wait_ms = int(max(1.0, (1000.0 / fps) / sp))
        key = cv2.waitKey(int(wait_ms)) & 0xFF
        if key in (ord("q"), ord("Q"), 27):
            break

    try:
        if holistic is not None:
            holistic.close()
    except Exception:
        pass
    try:
        if holistic_vis is not None:
            holistic_vis.close()
    except Exception:
        pass
    try:
        if hands_vis is not None:
            hands_vis.close()
    except Exception:
        pass
    if cap is not None:
        cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()