"""
gloss.csv 与样本文件名的统一解析（27261843 数据集）。

- gloss.csv：首列为 Gloss ID（可与行首 # 的表头共存），第 2、3 列为中文/英文释义。
- 视频：支持常见封装及摄像机 .MTS/.M2TS。
- 文件名：孤立词分类常用「数字前缀或下划线前 ID」；连续句 manifest 可用下划线/连字符分隔多个 ID。
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Set, Tuple

# 与 OpenCV 可读、数据集中常见的扩展名（含大小写变体由迭代函数处理）
VIDEO_EXTENSIONS: Tuple[str, ...] = (
    ".mp4",
    ".avi",
    ".mov",
    ".mkv",
    ".webm",
    ".mts",
    ".m2ts",
)


@dataclass(frozen=True)
class GlossEntry:
    """一行 gloss.csv。"""

    id_int: int
    id_str: str  # 4 位补零，如 "0042"
    zh: str
    en: str


def iter_gloss_rows(gloss_csv: Path) -> Iterator[GlossEntry]:
    """
    流式读取 gloss.csv，跳过空行与以 # 开头的表头/注释行。

    若英文列中含未加引号的逗号导致被拆成多列，会将第 3 列及之后重新合并为英文释义。
    """
    with open(gloss_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or (row[0].strip().startswith("#")):
                continue
            if len(row) < 3:
                continue
            raw_id = str(row[0]).strip()
            if not raw_id:
                continue
            try:
                id_int = int(raw_id)
            except ValueError:
                continue
            zh = str(row[1]).strip()
            en = str(row[2]).strip() if len(row) == 3 else ",".join(str(x).strip() for x in row[2:])
            yield GlossEntry(
                id_int=id_int,
                id_str=str(id_int).zfill(4),
                zh=zh,
                en=en,
            )


def load_gloss_entries(gloss_csv: Path) -> List[GlossEntry]:
    return list(iter_gloss_rows(gloss_csv))


def load_gloss_by_int(gloss_csv: Path) -> Dict[int, GlossEntry]:
    """Gloss ID -> 整行元数据。"""
    return {e.id_int: e for e in iter_gloss_rows(gloss_csv)}


def load_gloss_tuples(gloss_csv: Path) -> Dict[str, Tuple[str, str]]:
    """
    Gloss ID -> (中文, 英文)。
    同时写入四位补零键与未补零数字字符串键（如 '0042' 与 '42'），便于与模型输出、文件名对齐。
    """
    out: Dict[str, Tuple[str, str]] = {}
    for e in iter_gloss_rows(gloss_csv):
        t = (e.zh, e.en)
        out[e.id_str] = t
        out[str(e.id_int)] = t
    return out


def load_id_to_zh_variants(gloss_csv: Path) -> Dict[str, str]:
    """
    gloss id -> 中文，键同时包含补零与不补零（如 '42' 与 '0042'），便于与 manifest / 模型输出对齐。
    """
    out: Dict[str, str] = {}
    for e in iter_gloss_rows(gloss_csv):
        out[e.id_str] = e.zh
        out[str(e.id_int)] = e.zh
    return out


def load_gloss_id_set(gloss_csv: Path) -> Set[int]:
    """词表中所有 Gloss ID 的集合，用于文件名解析时消歧。"""
    return {e.id_int for e in iter_gloss_rows(gloss_csv)}


def _stem_from_any_media(name: str) -> str:
    return Path(name).stem


def _disambiguate_multi_4digit(cands: List[int]) -> int:
    """
    文件名里出现多个四位数字时（如 2024_0810），尽量去掉疑似年份(1900–2035)，
    否则保留最后一个四位段（常见命名：前缀_真实GlossID）。
    """
    if not cands:
        return -1
    if len(cands) == 1:
        return cands[0]
    non_year = [n for n in cands if not (1900 <= n <= 2035)]
    if len(non_year) == 1:
        return non_year[0]
    if non_year:
        return non_year[-1]
    return cands[-1]


def parse_gloss_id_from_filename(name: str, valid_ids: Optional[Set[int]] = None) -> int:
    """
    从图片/视频文件名解析「单个」孤立词 Gloss ID。

    优先级（分高者优先）：
    1. 独立的四位数字段（如 xxx_0810_yyy），避免被更长数字串截断；
    2. 文件名开头「到第一个 _/- 为止的整段数字」（如 0001234_take1 → 1234，而不是只取前四位）；
    3. 分隔符 _ / - 后的 1–4 位数字段。

    若传入 ``valid_ids``（来自 gloss.csv），只保留词表中存在的候选，并在多位候选间消歧（含年份 1900–2035 与真实 Gloss ID 并存时的启发式）。
    解析失败返回 -1。
    """
    stem = _stem_from_any_media(name)
    scored: List[Tuple[int, int, int]] = []  # (-score, position, id) 用于排序：分高、位置靠前

    def allow(n: int) -> bool:
        return valid_ids is None or n in valid_ids

    # 独立四位数（非更长数字的一部分）
    isolated_4: List[int] = []
    for m in re.finditer(r"(?<!\d)(\d{4})(?!\d)", stem):
        n = int(m.group(1))
        isolated_4.append(n)
        if allow(n):
            scored.append((100, m.start(), n))

    # 开头连续数字到 '_'/'-' 或串尾：整段 int，避免 0001234_ 被误读成 0001
    m = re.match(r"^(\d{1,7})(?=[_-]|$)", stem)
    if m:
        n = int(m.group(1))
        if allow(n):
            scored.append((82, 0, n))

    for m in re.finditer(r"(?<=[_-])(\d{1,4})(?=[_-]|$)", stem):
        n = int(m.group(1))
        if allow(n):
            scored.append((70, m.start(), n))

    m = re.search(r"[_-](\d{1,4})(?:[_-]|$)", stem)
    if m:
        n = int(m.group(1))
        if allow(n):
            scored.append((65, m.start(), n))

    if scored:
        scored.sort(key=lambda x: (-x[0], x[1]))
        best_score = scored[0][0]
        top = [t for t in scored if t[0] == best_score]
        if len(top) == 1:
            return top[0][2]
        ids = [t[2] for t in top]
        if len(set(ids)) == 1:
            return ids[0]
        pick = _disambiguate_multi_4digit(isolated_4 if isolated_4 else ids)
        if allow(pick):
            return pick
        return top[0][2]

    if valid_ids is not None:
        return -1

    # 无词表约束时的宽松回退（兼容旧逻辑）
    if isolated_4:
        return _disambiguate_multi_4digit(isolated_4)
    m = re.match(r"^(\d{1,7})(?=[_-]|$)", stem)
    if m:
        return int(m.group(1))
    m = re.match(r"^(\d{1,4})", stem)
    if m:
        return int(m.group(1))
    m = re.search(r"[_-](\d{1,4})(?:[_-]|$)", stem)
    if m:
        return int(m.group(1))
    return -1


def parse_gloss_id_strict(name: str, valid_ids: Optional[Set[int]] = None) -> int:
    """解析失败或（若给定 valid_ids）ID 不在词表中时抛出 ValueError。"""
    n = parse_gloss_id_from_filename(name, valid_ids)
    if n < 0:
        raise ValueError(f"无法从文件名解析 Gloss ID: {name}")
    if valid_ids is not None and n not in valid_ids:
        raise ValueError(f"Gloss ID {n} 不在 gloss.csv 词表中: {name}")
    return n


def extract_gloss_ids_from_stem(stem: str, valid_ids: Set[int]) -> List[int]:
    """
    从文件名片段提取 0 个或多个 Gloss ID（用于 CSLR manifest）。

    优先按 '_' / '-' 分段，只保留「整段为数字且在词表中」的段，保持从左到右顺序。
    其次匹配独立的四位数字段；再尝试片头 1–4 位与其它数字（均在 valid_ids 中过滤）。
    """
    parts = re.split(r"[_-]+", stem)
    found: List[int] = []
    for p in parts:
        s = p.strip()
        if not s.isdigit():
            continue
        n = int(s)
        if n in valid_ids:
            found.append(n)

    if found:
        return found

    for m in re.finditer(r"(?<!\d)(\d{4})(?!\d)", stem):
        n = int(m.group(1))
        if n in valid_ids:
            found.append(n)
    if found:
        return found

    m = re.match(r"^(\d{1,4})", stem.strip())
    if m:
        n = int(m.group(1))
        if n in valid_ids:
            return [n]

    for m in re.finditer(r"\d{1,4}", stem):
        n = int(m.group(0))
        if n in valid_ids:
            found.append(n)
    return found


def iter_video_paths(video_dir: Path) -> List[Path]:
    """递归收集视频文件路径，去重后按路径排序。"""
    if not video_dir.is_dir():
        return []
    seen: Set[str] = set()
    out: List[Path] = []
    for ext in VIDEO_EXTENSIONS:
        for p in video_dir.rglob(f"*{ext}"):
            try:
                key = str(p.resolve())
            except OSError:
                key = str(p)
            if key in seen:
                continue
            seen.add(key)
            out.append(p)
        upper = ext.upper()
        if upper != ext:
            for p in video_dir.rglob(f"*{upper}"):
                try:
                    key = str(p.resolve())
                except OSError:
                    key = str(p)
                if key in seen:
                    continue
                seen.add(key)
                out.append(p)
    return sorted(out, key=lambda x: str(x).lower())


def video_feature_key(video_path: Path, roots: List[Path]) -> str:
    """
    特征 JSON/NPZ 与 manifest ``sample_id`` 的稳定 key。

    使用相对**某一视频根目录**的路径（POSIX），例如 ``Participant_01/0072.mp4``。
    多名参与者沿用相同 ``0072.mp4`` 时仍互不覆盖；解析 Gloss ID 时用 ``Path(key).name`` 的 stem 即可。

    ``roots`` 中按路径长度从长到短尝试 ``relative_to``，避免嵌套根目录时匹配到过短前缀。
    """
    try:
        resolved_vp = video_path.resolve()
    except OSError:
        resolved_vp = video_path
    resolved_roots = sorted(
        (r.resolve() for r in roots if r.is_dir()),
        key=lambda p: len(str(p)),
        reverse=True,
    )
    for root in resolved_roots:
        try:
            return resolved_vp.relative_to(root).as_posix()
        except ValueError:
            continue
    return video_path.name


def dedupe_video_paths_by_basename(paths: List[Path]) -> Tuple[List[Path], int]:
    """
    同一 basename 出现在多个子目录时，只保留第一次出现的路径。

    适用于「多目录实为同一文件的拷贝、且特征 key 只用 basename」的旧流程。
    多名参与者各自一份同名视频时不要使用，应改用 ``video_feature_key`` 区分样本。
    """
    seen: Set[str] = set()
    out: List[Path] = []
    for p in paths:
        name = p.name
        if name in seen:
            continue
        seen.add(name)
        out.append(p)
    return out, len(paths) - len(out)


def resolve_script_path(script_dir: Path, user_path: str) -> Path:
    """绝对路径原样 resolve；相对路径相对于 script_dir（一般为 sign_language_system 目录）。"""
    p = Path(user_path)
    return p.resolve() if p.is_absolute() else (script_dir / p).resolve()


def iter_video_paths_many(roots: List[Path]) -> List[Path]:
    """对多个根目录分别 ``iter_video_paths`` 后合并，按路径字符串排序。"""
    merged: List[Path] = []
    for root in roots:
        if root.is_dir():
            merged.extend(iter_video_paths(root))
    return sorted(merged, key=lambda x: str(x).lower())


def gloss_video_coverage_report(
    gloss_csv: Path, video_files: List[Path], *, max_missing_preview: int = 20
) -> str:
    """
    对比 gloss.csv 与当前待处理视频列表：词表中有多少 ID 至少对应一个可解析的文件名。

    用于检查是否只扫到了小样例子集、或 ``--video_dir`` 未指向完整数据根目录。
    """
    if not gloss_csv.is_file():
        return f"(skip coverage: gloss file not found: {gloss_csv})"
    valid_ids = load_gloss_id_set(gloss_csv)
    gloss_n = len(valid_ids)
    covered: Set[int] = set()
    n_unparsed = 0
    for vp in video_files:
        gid = parse_gloss_id_from_filename(vp.name, valid_ids)
        if gid < 0 or gid not in valid_ids:
            n_unparsed += 1
        else:
            covered.add(gid)
    missing = sorted(valid_ids - covered)
    lines = [
        f"gloss.csv distinct IDs: {gloss_n}",
        f"videos in queue (after basename dedupe): {len(video_files)}",
        f"gloss IDs with at least one matching video filename: {len(covered)}",
        f"gloss IDs with no matching video yet: {len(missing)}",
        f"videos whose name does not map to any in-vocabulary ID: {n_unparsed}",
    ]
    if missing:
        preview = ", ".join(str(i).zfill(4) for i in missing[:max_missing_preview])
        lines.append(f"missing ID preview (first {max_missing_preview}): {preview}")
    return "\n".join(lines)


def parse_restrict_gloss_ids(cli: str | None, base_dir: Path) -> Set[str] | None:
    """
    train_image / train_fusion 共用：--restrict_gloss_ids 语法
    - 空：不过滤
    - \"1770,1597,...\" 或分号分隔
    - @path 文本文件，每行一个 id（可 # 注释）
    返回 4 位数字符串集合。
    """
    if not cli or not str(cli).strip():
        return None
    s = str(cli).strip()
    if s.startswith("@"):
        rel = s[1:].strip()
        p = Path(rel)
        p = p.resolve() if p.is_absolute() else (base_dir / rel).resolve()
        if not p.is_file():
            raise FileNotFoundError(f"--restrict_gloss_ids 文件不存在: {p}")
        lines = p.read_text(encoding="utf-8").splitlines()
        out: Set[str] = set()
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            out.add(str(int(line)).zfill(4))
        return out if out else None
    parts = [p.strip() for p in s.replace(";", ",").split(",") if p.strip()]
    if not parts:
        return None
    return {str(int(x)).zfill(4) for x in parts}
