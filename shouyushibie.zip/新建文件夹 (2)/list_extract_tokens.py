from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, List, Tuple

from glossary import iter_gloss_rows

ID_RE = re.compile(r"\[(\d{1,4})\]")


def zfill4(x: str) -> str:
    return str(int(x)).zfill(4)


def load_id_to_zh(gloss_csv: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for e in iter_gloss_rows(gloss_csv):
        out[str(e.id_str)] = str(e.zh).strip()
    return out


def parse_sentence_ids(sent: str) -> List[str]:
    return [zfill4(m.group(1)) for m in ID_RE.finditer(sent)]


def strip_ids_to_zh_sentence(sent: str) -> str:
    s = ID_RE.sub("", sent)
    return re.sub(r"\s+", " ", s).strip()


def main() -> None:
    ap = argparse.ArgumentParser(description="List gloss tokens from extract.DEFAULT_SENTENCES and print collection commands.")
    ap.add_argument("--gloss_csv", type=str, default=r"..\gloss.csv", help="gloss.csv path for id->Chinese mapping")
    ap.add_argument(
        "--base_dir",
        type=str,
        default=".",
        help="sign_language_system 目录（默认当前目录；用于打印可直接运行的 python 命令）",
    )
    ap.add_argument("--unique", action="store_true", help="只输出去重后的 gloss id 列表（按出现顺序）")
    args = ap.parse_args()

    base = Path(args.base_dir).resolve()
    gloss_csv = (base / args.gloss_csv).resolve() if not Path(args.gloss_csv).is_absolute() else Path(args.gloss_csv).resolve()
    if not gloss_csv.is_file():
        raise SystemExit(f"gloss_csv not found: {gloss_csv}")

    # Import DEFAULT_SENTENCES from extract.py (same folder).
    from extract import DEFAULT_SENTENCES  # noqa: WPS433

    id_to_zh = load_id_to_zh(gloss_csv)

    per_sentence: List[Tuple[int, str, List[str]]] = []
    all_ids: List[str] = []
    for i, s in enumerate(DEFAULT_SENTENCES, start=1):
        ids = parse_sentence_ids(s)
        per_sentence.append((i, strip_ids_to_zh_sentence(s), ids))
        all_ids.extend(ids)

    if args.unique:
        seen = set()
        uniq = []
        for gid in all_ids:
            if gid in seen:
                continue
            seen.add(gid)
            uniq.append(gid)
        all_ids = uniq

    print("=== 十句文案拆分（每句 gloss_id 顺序） ===")
    for i, zh_sent, ids in per_sentence:
        words = [id_to_zh.get(g, f"未知{g}") for g in ids]
        print(f"{i:02d}. {zh_sent}")
        print("    ids :", " ".join(ids))
        print("    zh  :", " / ".join(words))

    print("\n=== 采集命令（逐个词采集） ===")
    print("提示：每次运行会打开摄像头录制 seconds 秒，按 ESC 可提前结束。")
    for gid in all_ids:
        zh = id_to_zh.get(gid, "")
        label = f"（{zh}）" if zh else ""
        cmd = (
            f'python "{(base / "collect_webcam_pose_mediapipe.py").resolve()}" '
            f'--gloss_id {int(gid)} --gloss_csv "{gloss_csv}" --output outputs/pose_features_webcam.json'
        )
        print(f"- {gid} {label}")
        print(f"  {cmd}")


if __name__ == "__main__":
    main()

