from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
from pathlib import Path
from typing import List, Sequence, Tuple

import cv2
import numpy as np
from PIL import Image


ID_RE = re.compile(r"\[(\d{1,4})\]")

_IMAGE_EXTS_LOWER = frozenset({".jpg", ".jpeg", ".png", ".bmp", ".webp"})

_WIN_ILLEGAL_FILENAME_CHARS_RE = re.compile(r'[<>:"/\\\\|?*]+')


DEFAULT_SENTENCES = [
    "今天[1770]，老师[1597]在办公室[0226]认真[1678]工作[2130]。",
    "学生[0526]应该[0906]努力[2922]学习[4462]知识[3430]。",
    "我喜欢[2462]吃水果[0165]、蛋糕[4314]和面包[2985]。",
    "爸爸[0396]和妈妈[2832]一起开车[2776]回家[0869]。",
    "天气[1863]很好[2092]，我们[0488]去公园[2838]玩[5316]。",
    "他跑[0071]得很快[0477]，跳[4227]得也很高[4130]。",
    "这本书[2065]的内容[0269]非常[3809]有趣[1937]。",
    "我[1928]爱[3672]我的祖国[1865]和人民[5562]。",
    "晚上[1406]，天空[2201]有很多[4102]星星[3973]和月亮[2943]。",
    "朋友[5008]之间要互相[1573]帮助[5094]，团结[1228]合作[5664]。",
]


def parse_ids_from_sentences(sentences: list[str]) -> list[str]:
    ids: list[str] = []
    for s in sentences:
        for m in ID_RE.finditer(s):
            ids.append(str(int(m.group(1))).zfill(4))
    # stable unique preserve order
    seen: set[str] = set()
    out: list[str] = []
    for x in ids:
        if x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


def write_gloss_csv_subset_for_default_sentences(master_gloss_csv: Path, output_csv: Path) -> int:
    """
    从完整 gloss.csv 中只保留 DEFAULT_SENTENCES（第 22–32 行十句）里出现的 gloss id 行，
    供 369 / butting_connectro 调用 camera 时「不要用全表」。
    """
    from glossary import iter_gloss_rows

    allow_int = {int(x) for x in parse_ids_from_sentences(DEFAULT_SENTENCES)}
    rows_out: list[tuple[int, str, str]] = []
    for e in iter_gloss_rows(master_gloss_csv):
        if int(e.id_int) in allow_int:
            rows_out.append((int(e.id_int), str(e.zh), str(e.en)))
    rows_out.sort(key=lambda t: t[0])
    found_int = {t[0] for t in rows_out}
    missing = allow_int - found_int
    if missing:
        print(
            "WARN: gloss 源文件中缺少以下 extract 十句词表 id（将仍使用已找到的条目）:",
            ", ".join(str(x).zfill(4) for x in sorted(missing)[:40]),
            ("..." if len(missing) > 40 else ""),
        )
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["# extract.DEFAULT_SENTENCES subset — auto-generated"])
        for id_int, zh, en in rows_out:
            w.writerow([id_int, zh, en])
    if not rows_out:
        raise RuntimeError(
            f"裁剪后 gloss 为空：请确认 {master_gloss_csv} 含 extract 十句中的 id，或路径是否正确。"
        )
    return len(rows_out)


def parse_ordered_gloss_sequence(sentences: Sequence[str]) -> List[str]:
    """
    按「十句话」行文顺序输出所有 [id]（可重复），用于连续手语视频与文案顺序一致。
    """
    out: List[str] = []
    for s in sentences:
        for m in ID_RE.finditer(s):
            out.append(str(int(m.group(1))).zfill(4))
    return out


def sentence_gloss_breakdown(sentences: Sequence[str]) -> List[Tuple[int, List[str]]]:
    """(句序号从1开始, 该句内 gloss 顺序列表)"""
    rows: List[Tuple[int, List[str]]] = []
    for i, s in enumerate(sentences, start=1):
        gids = [str(int(m.group(1))).zfill(4) for m in ID_RE.finditer(s)]
        rows.append((i, gids))
    return rows


def sentence_to_chinese_label(sentence: str) -> str:
    """
    句子作为视频“中文标签/文件名”：
    - 去掉 [####]
    - Windows 文件名非法字符替换为 '_'
    - 去掉首尾空格与末尾 '.'（Windows 不允许以 '.' 结尾）
    """
    s = ID_RE.sub("", str(sentence))
    s = _WIN_ILLEGAL_FILENAME_CHARS_RE.sub("_", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = s.rstrip(". ").strip()
    if not s:
        return "未命名"
    # 避免文件名过长（Windows 路径过长容易出问题）
    if len(s) > 80:
        s = s[:80].rstrip()
    return s


def _list_frames_in_gloss_dir(gloss_dir: Path) -> List[Path]:
    if not gloss_dir.is_dir():
        return []
    fs = [p for p in gloss_dir.iterdir() if p.is_file() and p.suffix.lower() in _IMAGE_EXTS_LOWER]
    fs.sort(key=lambda p: str(p.name).lower())
    return fs


def expand_ordered_glosses_to_frame_paths(
    front_dir: Path,
    ordered_gids: Sequence[str],
    *,
    max_frames_per_gloss: int = 0,
) -> Tuple[List[Path], List[str]]:
    """
    将有序 gloss 列表展开为按文件夹内文件名排序的帧路径；若某 id 无目录则记录 WARN 并跳过。
    返回 (paths, warnings)
    """
    warn: List[str] = []
    out_paths: List[Path] = []
    for gid in ordered_gids:
        d = front_dir / gid
        frames = _list_frames_in_gloss_dir(d)
        if not frames:
            warn.append(f"missing or empty gloss folder: {d}")
            continue
        if max_frames_per_gloss and max_frames_per_gloss > 0:
            frames = frames[: int(max_frames_per_gloss)]
        out_paths.extend(frames)
    return out_paths, warn


def _read_rgb_numpy(path: Path) -> np.ndarray:
    """BGR uint8 for OpenCV, shape (H,W,3)."""
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def _write_video_from_frames(
    frame_paths: Sequence[Path],
    out_video: Path,
    *,
    fps: float,
    target_size: Tuple[int, int] | None,
) -> Path:
    if not frame_paths:
        raise RuntimeError("frame_paths 为空，无法写入视频")
    out_video = out_video.resolve()
    out_video.parent.mkdir(parents=True, exist_ok=True)

    first = _read_rgb_numpy(Path(frame_paths[0]))
    h0, w0 = first.shape[:2]
    if target_size is not None:
        tw, th = int(target_size[0]), int(target_size[1])
        if tw <= 0 or th <= 0:
            raise ValueError("target_size 宽高须为正整数")
    else:
        tw, th = w0, h0

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(out_video), fourcc, float(fps), (tw, th))
    if not writer.isOpened():
        raise RuntimeError(f"无法创建视频文件: {out_video}（可换输出路径或检查 OpenCV 编解码）")

    try:
        for p in frame_paths:
            frame = _read_rgb_numpy(Path(p))
            if frame.shape[1] != tw or frame.shape[0] != th:
                frame = cv2.resize(frame, (tw, th), interpolation=cv2.INTER_AREA)
            writer.write(frame)
    finally:
        writer.release()
    return out_video


def compose_sign_language_video(
    extract_root: Path,
    out_video: Path,
    sentences: Sequence[str],
    *,
    fps: float = 12.0,
    max_frames_per_gloss: int = 0,
    target_size: Tuple[int, int] | None = None,
) -> Path:
    """
    按 sentences 中文案顺序（与 DEFAULT_SENTENCES 一致）将 extract_root/front/<gid> 下图片
    按文件名顺序接成一段连续视频。
    """
    extract_root = extract_root.resolve()
    front = extract_root / "front"
    if not front.is_dir():
        raise FileNotFoundError(f"未找到提取数据 front 目录: {front}")

    ordered = parse_ordered_gloss_sequence(list(sentences))
    paths, warnings = expand_ordered_glosses_to_frame_paths(
        front, ordered, max_frames_per_gloss=int(max_frames_per_gloss)
    )
    if warnings:
        for w in warnings[:20]:
            print(f"WARN: {w}")
        if len(warnings) > 20:
            print(f"WARN: ... 另有 {len(warnings) - 20} 条")

    if not paths:
        raise RuntimeError("没有可用的图片帧，无法生成视频（请检查 extract 是否成功、路径是否为 front/<四位id>/）。")

    out_p = _write_video_from_frames(paths, out_video, fps=float(fps), target_size=target_size)
    print(f"已保存连续手语视频: {out_p} | 帧数={len(paths)} | fps={fps}")
    return out_p


def compose_sign_language_videos_per_sentence(
    extract_root: Path,
    out_dir: Path,
    sentences: Sequence[str],
    *,
    fps: float = 12.0,
    max_frames_per_gloss: int = 0,
    target_size: Tuple[int, int] | None = None,
) -> List[Path]:
    """
    将十句文案分别生成 10 个视频：
      - 每句内部按该句 [####] 顺序取 gloss
      - 每个 gloss 从 front/<gid>/ 下按文件名排序取帧
      - 输出文件名为该句中文（去掉 [####]），并清洗为合法 Windows 文件名
    """
    extract_root = extract_root.resolve()
    front = extract_root / "front"
    if not front.is_dir():
        raise FileNotFoundError(f"未找到提取数据 front 目录: {front}")
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    outputs: List[Path] = []
    breakdown = sentence_gloss_breakdown(list(sentences))
    for idx, gids in breakdown:
        label = sentence_to_chinese_label(str(sentences[idx - 1]))
        # 同名时加句序号前缀，避免覆盖
        filename = f"{idx:02d}_{label}.mp4"
        out_path = out_dir / filename
        frame_paths, warnings = expand_ordered_glosses_to_frame_paths(
            front, gids, max_frames_per_gloss=int(max_frames_per_gloss)
        )
        if warnings:
            for w in warnings[:10]:
                print(f"WARN: {w}")
            if len(warnings) > 10:
                print(f"WARN: ... 另有 {len(warnings) - 10} 条")
        if not frame_paths:
            print(f"WARN: 句 {idx} 无可用帧，跳过生成：{out_path}")
            continue
        _write_video_from_frames(frame_paths, out_path, fps=float(fps), target_size=target_size)
        print(f"已保存第 {idx} 句视频: {out_path} | 帧数={len(frame_paths)} | 标签={label}")
        outputs.append(out_path)
    return outputs


def load_sentences_for_video(extract_root: Path) -> List[str]:
    """从 extract 目录中的 manifest 读取文案；若无则回退到内置十句。"""
    manifest = extract_root.resolve() / "sentence_gloss_manifest.json"
    if manifest.is_file():
        data = json.loads(manifest.read_text(encoding="utf-8"))
        src = data.get("source_sentences")
        if isinstance(src, list) and src and all(isinstance(x, str) for x in src):
            return [str(x) for x in src]
    return list(DEFAULT_SENTENCES)


def write_sequence_artifacts(extract_root: Path, sentences: Sequence[str]) -> None:
    """写入有序 gloss 序列与十句拆分，便于复现与 calling_program 生成视频。"""
    extract_root = extract_root.resolve()
    ordered = parse_ordered_gloss_sequence(list(sentences))
    (extract_root / "ordered_gloss_sequence.txt").write_text("\n".join(ordered) + "\n", encoding="utf-8")
    breakdown = [{"sentence_index": i, "gloss_ids": gids} for i, gids in sentence_gloss_breakdown(list(sentences))]
    (extract_root / "sentence_gloss_manifest.json").write_text(
        json.dumps(
            {
                "sentences": breakdown,
                "ordered_gloss_sequence": ordered,
                "source_sentences": list(sentences),
                "num_tokens": len(ordered),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def copy_tree(src: Path, dst: Path) -> int:
    dst.mkdir(parents=True, exist_ok=True)
    n = 0
    for p in src.iterdir():
        if p.is_file():
            shutil.copy2(p, dst / p.name)
            n += 1
    return n


def main() -> None:
    ap = argparse.ArgumentParser(description="Extract a subset image dataset by Gloss IDs from the large Pics dataset.")
    ap.add_argument(
        "--pics_front_dir",
        type=str,
        default=r"D:\newprojieket\27261843\Pics\Participant_01\Participant_01\front",
        help="Path to Pics/.../front containing 0000..6706 folders",
    )
    ap.add_argument(
        "--out_root",
        type=str,
        default="extract_dataset",
        help="Output dataset root (will create out_root/front/0000/... etc)",
    )
    ap.add_argument(
        "--sentences_file",
        type=str,
        default="",
        help="Optional text file containing sentences with [####] ids; if omitted, uses built-in 10 sentences.",
    )
    ap.add_argument(
        "--ids",
        type=str,
        default="",
        help="Optional comma/space-separated ids to extract (overrides sentences). Example: 1770,1597,0226",
    )
    ap.add_argument(
        "--video_out",
        type=str,
        default="continuous_sign.mp4",
        help=(
            "提取完成后生成的 mp4 路径；默认为本脚本目录下 continuous_sign.mp4 "
            "(即 sign_language_system 文件夹内)。相对路径相对本脚本目录。"
        ),
    )
    ap.add_argument(
        "--skip_video",
        action="store_true",
        help="不生成视频（忽略 --video_out）",
    )
    ap.add_argument(
        "--video_per_sentence",
        action="store_true",
        help="按十句文案分别生成 10 个视频（文件名为中文句子，去掉 [####]；输出到 --video_out_dir）。",
    )
    ap.add_argument(
        "--video_out_dir",
        type=str,
        default="sentence_videos",
        help="--video_per_sentence 时的视频输出目录（相对路径相对脚本目录）。",
    )
    ap.add_argument("--video_fps", type=float, default=12.0, help="合成视频帧率")
    ap.add_argument(
        "--frames_per_gloss",
        type=int,
        default=0,
        help="每个 gloss 文件夹最多取用前 N 帧（0=不限制，使用该文件夹全部图片）",
    )
    ap.add_argument(
        "--video_width",
        type=int,
        default=0,
        help="输出视频宽度（0=与首张帧一致）",
    )
    ap.add_argument(
        "--video_height",
        type=int,
        default=0,
        help="输出视频高度（0=与首张帧一致）",
    )
    ap.add_argument(
        "--export_skeleton_corpus",
        action="store_true",
        help="提取完成后对 front/<gloss>/ 逐帧跑 MediaPipe Holistic，记录双手126维+肩肘腕18维，写入 skeleton_corpus/",
    )
    ap.add_argument(
        "--gloss_csv",
        type=str,
        default="",
        help="骨骼导出时查中文释义：默认上级目录 gloss.csv（与 --export_skeleton_corpus 配套）",
    )
    ap.add_argument(
        "--skeleton_out_subdir",
        type=str,
        default="skeleton_corpus",
        help="骨骼语料输出子目录（位于 --out_root 下）",
    )
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    pics_front = Path(args.pics_front_dir).resolve()
    out_root = (base / args.out_root).resolve() if not Path(args.out_root).is_absolute() else Path(args.out_root).resolve()

    if not pics_front.is_dir():
        raise FileNotFoundError(f"pics_front_dir not found: {pics_front}")

    sentences_for_video: list[str]
    if args.ids.strip():
        raw = re.split(r"[,\s]+", args.ids.strip())
        ids = [str(int(x)).zfill(4) for x in raw if x.strip()]
        # stable unique
        seen: set[str] = set()
        ids = [x for x in ids if not (x in seen or seen.add(x))]
        # 连续视频顺序仍采用内置十句文案，与 extract 默认语义一致；缺图时在合成阶段跳过并告警
        sentences_for_video = list(DEFAULT_SENTENCES)
    else:
        if args.sentences_file.strip():
            p = Path(args.sentences_file)
            p = (base / p).resolve() if not p.is_absolute() else p.resolve()
            if not p.is_file():
                raise FileNotFoundError(f"sentences_file not found: {p}")
            sentences = [ln.strip() for ln in p.read_text(encoding="utf-8").splitlines() if ln.strip()]
            if not sentences:
                raise RuntimeError("sentences_file 为空或无有效行")
        else:
            sentences = list(DEFAULT_SENTENCES)
        ids = parse_ids_from_sentences(sentences)
        sentences_for_video = list(sentences)

    if not ids:
        raise RuntimeError("No ids found to extract.")

    # Create minimal dataset structure compatible with gloss_id_folder:
    # out_root/front/0000/*.jpg
    out_front = out_root / "front"
    out_front.mkdir(parents=True, exist_ok=True)

    total_imgs = 0
    missing: list[str] = []
    for gid in ids:
        src = pics_front / gid
        if not src.is_dir():
            missing.append(gid)
            continue
        dst = out_front / gid
        total_imgs += copy_tree(src, dst)

    # Write manifest for reproducibility
    (out_root / "ids.txt").write_text("\n".join(ids) + "\n", encoding="utf-8")
    write_sequence_artifacts(out_root, sentences_for_video)

    print(f"Extracted ids={len(ids)} -> {out_front}")
    print(f"Copied images: {total_imgs}")
    if missing:
        print(f"WARN: missing id folders ({len(missing)}): {missing[:30]}" + (" ..." if len(missing) > 30 else ""))

    if not bool(args.skip_video) and (str(args.video_out).strip() or bool(args.video_per_sentence)):
        ts: Tuple[int, int] | None = None
        if int(args.video_width) > 0 and int(args.video_height) > 0:
            ts = (int(args.video_width), int(args.video_height))
        if bool(args.video_per_sentence):
            out_dir = Path(args.video_out_dir)
            out_dir = out_dir.resolve() if out_dir.is_absolute() else (base / out_dir).resolve()
            compose_sign_language_videos_per_sentence(
                out_root,
                out_dir,
                sentences_for_video,
                fps=float(args.video_fps),
                max_frames_per_gloss=int(args.frames_per_gloss),
                target_size=ts,
            )
            print(f"10 句视频输出目录: {out_dir}")
        else:
            vo = Path(args.video_out)
            vo = vo.resolve() if vo.is_absolute() else (base / vo).resolve()
            compose_sign_language_video(
                out_root,
                vo,
                sentences_for_video,
                fps=float(args.video_fps),
                max_frames_per_gloss=int(args.frames_per_gloss),
                target_size=ts,
            )

    if bool(getattr(args, "export_skeleton_corpus", False)):
        if str(getattr(args, "gloss_csv", "")).strip():
            gc = Path(str(args.gloss_csv).strip())
            gc = gc.resolve() if gc.is_absolute() else (base / gc).resolve()
        else:
            gc = (base.parent / "gloss.csv").resolve()
        if not gc.is_file():
            raise FileNotFoundError(f"gloss_csv not found for skeleton export: {gc}")
        from skeleton_corpus import export_skeleton_corpus_from_front

        export_skeleton_corpus_from_front(
            out_root,
            gc,
            restrict_gloss_ids=None,
            max_frames_per_gloss=int(args.frames_per_gloss),
            out_subdir=str(getattr(args, "skeleton_out_subdir", "skeleton_corpus") or "skeleton_corpus"),
        )


if __name__ == "__main__":
    main()

