from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from extract import (
    DEFAULT_SENTENCES,
    compose_sign_language_video,
    compose_sign_language_videos_per_sentence,
    load_sentences_for_video,
    parse_ids_from_sentences,
)


def main() -> None:
    ap = argparse.ArgumentParser(
        description=(
            "在 extract 产出上调用 train_image：默认仅 extract.DEFAULT_SENTENCES（十句）中的 gloss、"
            "data_root=extract_root/front、混淆矩阵诊断、balanced 与 label_smoothing。"
            "若要在训练图上加骨骼线，见 --overlay_kp（与独立 MediaPipe 脚本不同，已集成在 train_image）。"
        )
    )
    ap.add_argument("--extract_root", type=str, default="extract_dataset", help="Dataset root created by extract.py")
    # Defaults tuned for a stronger baseline (matches typical local training intent).
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--arch", type=str, default="efficientnet_b0", choices=["resnet18", "resnet50", "efficientnet_b0"])
    _pt = ap.add_mutually_exclusive_group()
    _pt.add_argument("--pretrained", dest="pretrained", action="store_true", help="ImageNet 预训练（默认开启）")
    _pt.add_argument("--no-pretrained", dest="pretrained", action="store_false", help="随机初始化 backbone")
    ap.set_defaults(pretrained=True)
    ap.add_argument("--augment", action="store_true")
    ap.add_argument(
        "--augment_level",
        type=str,
        default="strong",
        choices=["none", "light", "strong"],
        help="训练数据增强强度（传给 train_image.py）。默认 strong 更贴近摄像头噪声/位移。",
    )
    ap.add_argument("--image_size", type=int, default=224)
    ap.add_argument("--output_dir", type=str, default="outputs/image_extract", help="Separate outputs directory")
    ap.add_argument(
        "--scheduler",
        type=str,
        default="cosine",
        choices=["none", "plateau", "cosine"],
        help="学习率调度器（传给 train_image.py）。默认 cosine。",
    )
    ap.add_argument(
        "--class_weight",
        type=str,
        default="balanced",
        choices=["none", "balanced"],
        help="类别权重（传给 train_image.py）。extract 十句子集默认 balanced。",
    )
    ap.add_argument(
        "--label_smoothing",
        type=float,
        default=0.05,
        help="传给 train_image.py 的标签平滑（默认 0.05）",
    )
    _cm = ap.add_mutually_exclusive_group()
    _cm.add_argument(
        "--save_confusion_diag",
        dest="save_confusion_diag",
        action="store_true",
        help="训练结束后导出混淆矩阵 PNG/CSV（默认开启，见 train_image_diagnostics）",
    )
    _cm.add_argument("--no-save_confusion_diag", dest="save_confusion_diag", action="store_false", help="不导出混淆矩阵")
    ap.set_defaults(save_confusion_diag=True)
    # Optional: overlay keypoints on images during training (very slow).
    ap.add_argument("--overlay_kp", action="store_true", help="训练时在图片上叠加 MediaPipe 双手关键点（很慢）")
    ap.add_argument("--overlay_pose", action="store_true", help="配合 --overlay_kp：额外画 pose 骨架")
    ap.add_argument("--overlay_face_box", action="store_true", help="配合 --overlay_kp：额外画 face bbox")
    ap.add_argument("--overlay_prob", type=float, default=1.0, help="叠加关键点的概率(0-1)，默认1")
    # Scheme 1: semantic-aware soft labels
    ap.add_argument("--semantic_soft_labels", action="store_true", help="启用语义知识软标签（方案一）")
    ap.add_argument("--semantic_alpha", type=float, default=0.25, help="语义软标签强度 alpha")
    ap.add_argument("--semantic_tau", type=float, default=0.25, help="语义 softmax 温度 tau")
    ap.add_argument("--semantic_topk", type=int, default=32, help="语义邻居 Top-K")
    ap.add_argument("--semantic_dim", type=int, default=256, help="语义哈希向量维度")
    ap.add_argument(
        "--semantic_text_source",
        type=str,
        default="both",
        choices=["zh", "en", "both", "label"],
        help="语义文本来源：zh/en/both/label",
    )
    # Scheme 2: metric learning (CE + Triplet)
    ap.add_argument("--metric_learning", action="store_true", help="启用方案二：CE + Triplet（度量学习）")
    ap.add_argument("--embed_dim", type=int, default=256, help="embedding 维度")
    ap.add_argument("--triplet_margin", type=float, default=0.20, help="Triplet margin")
    ap.add_argument("--triplet_lambda", type=float, default=0.20, help="Triplet loss 权重")
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--amp", action="store_true")
    ap.add_argument("--num_workers", type=int, default=0)
    ap.add_argument(
        "--split",
        type=str,
        default="stratified",
        choices=["stratified", "group"],
        help=(
            "传给 train_image.py 的划分方式。extract.py 生成的目录为 front/<四位 gloss>/，路径里通常没有 Participant_*；"
            "若仍用 group（默认曾写在 train_image），分组键会变成 gloss 文件夹名，.train/.test 类别互不重叠，Test Acc 会接近 0。"
            "extract 子集训练请保持 stratified。"
        ),
    )
    ap.add_argument(
        "--python",
        type=str,
        default="",
        help=(
            "Python interpreter to run train_image.py. "
            "If omitted, uses current interpreter; if CONDA_PREFIX is set, will prefer that env's python."
        ),
    )
    ap.add_argument(
        "--video_out",
        type=str,
        default="",
        help=(
            "可选：生成 mp4 的输出路径（相对路径相对本脚本目录）。"
            "若不传此参数，则默认不生成视频（满足“只生成一次”的需求）。"
        ),
    )
    ap.add_argument(
        "--skip_video",
        action="store_true",
        help="不生成视频（跳过默认 continuous_sign.mp4）",
    )
    ap.add_argument("--video_fps", type=float, default=12.0, help="合成视频帧率")
    ap.add_argument(
        "--frames_per_gloss",
        type=int,
        default=0,
        help="每个 gloss 文件夹最多使用前 N 帧（0=该文件夹全部图片）",
    )
    ap.add_argument("--video_width", type=int, default=0, help="输出宽（需与 video_height 同时>0，否则按首帧尺寸）")
    ap.add_argument("--video_height", type=int, default=0, help="输出高")
    ap.add_argument(
        "--video_per_sentence",
        action="store_true",
        help="按十句文案分别生成 10 个视频（文件名为中文句子，去掉 [####]；输出到 --video_out_dir）。",
    )
    ap.add_argument(
        "--video_out_dir",
        type=str,
        default="sentence_videos",
        help="--video_per_sentence 时的视频输出目录（相对路径相对本脚本目录）。",
    )
    ap.add_argument(
        "--video_only",
        action="store_true",
        help="不训练，仅根据 extract_root 与 sentence_gloss_manifest.json 生成视频",
    )
    ap.add_argument(
        "--export_skeleton_corpus",
        action="store_true",
        help="从 extract_root/front 导出骨骼语料（frames.jsonl + skeleton_match_index.npz），供摄像头 --skeleton_match_index 序列匹配",
    )
    ap.add_argument(
        "--skeleton_only",
        action="store_true",
        help="仅导出骨骼语料，不运行 train_image（常与 --export_skeleton_corpus 同用）",
    )
    ap.add_argument(
        "--gloss_csv",
        type=str,
        default="",
        help="骨骼导出用的词条表；默认上级目录 gloss.csv",
    )
    ap.add_argument(
        "--skeleton_out_subdir",
        type=str,
        default="skeleton_corpus",
        help="骨骼文件写入 extract_root 下的子目录名",
    )
    ap.add_argument(
        "--confusion_audit_before_train",
        action="store_true",
        help="训练前先用当前 outputs_dir 最新模型跑一次混淆分析，并把易混淆样本分组输出报告（见 reports/confusions）。",
    )
    ap.add_argument("--confusion_topk", type=int, default=30, help="混淆分析输出 Top-K (GT->Pred) 对")
    ap.add_argument("--confusion_copy_per_pair", type=int, default=40, help="每个混淆对最多复制多少张示例图（0=不复制）")
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    extract_root = (base / args.extract_root).resolve() if not Path(args.extract_root).is_absolute() else Path(args.extract_root).resolve()
    if not extract_root.is_dir():
        raise FileNotFoundError(f"extract_root not found: {extract_root}")
    front_dir = extract_root / "front"
    data_root_train = front_dir if front_dir.is_dir() else extract_root

    train_script = (base / "train_image.py").resolve()
    if not train_script.is_file():
        raise FileNotFoundError(f"train_image.py not found: {train_script}")

    python_exe = Path(args.python).resolve() if args.python else None
    if python_exe is None:
        conda_prefix = os.environ.get("CONDA_PREFIX", "")
        if conda_prefix:
            candidate = Path(conda_prefix) / ("python.exe" if sys.platform.startswith("win") else "bin/python")
            if candidate.is_file():
                python_exe = candidate.resolve()
    if python_exe is None:
        python_exe = Path(sys.executable).resolve()

    # Step 0: confusion audit (optional, before training).
    if bool(getattr(args, "confusion_audit_before_train", False)):
        audit_script = (base / "confusion_audit.py").resolve()
        if not audit_script.is_file():
            raise FileNotFoundError(f"confusion_audit.py not found: {audit_script}")
        cmd_audit = [
            str(python_exe),
            str(audit_script),
            "--extract_root",
            str(extract_root),
            "--outputs_dir",
            str(args.output_dir),
            "--topk",
            str(int(args.confusion_topk)),
            "--copy_per_pair",
            str(int(args.confusion_copy_per_pair)),
        ]
        print("Running confusion audit:", " ".join(cmd_audit))
        env = os.environ.copy()
        if sys.platform.startswith("win"):
            env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
        # Audit should not fail the whole training if no checkpoint exists yet.
        try:
            subprocess.run(cmd_audit, check=True, env=env)
        except Exception as e:
            print(f"WARN: confusion audit failed (ignored): {e}")

    def run_compose_video() -> None:
        ts = None
        if int(args.video_width) > 0 and int(args.video_height) > 0:
            ts = (int(args.video_width), int(args.video_height))
        sentences = load_sentences_for_video(extract_root)
        if bool(args.video_per_sentence):
            out_dir = Path(str(args.video_out_dir).strip() or "sentence_videos")
            out_dir = out_dir.resolve() if out_dir.is_absolute() else (base / out_dir).resolve()
            compose_sign_language_videos_per_sentence(
                extract_root,
                out_dir,
                sentences,
                fps=float(args.video_fps),
                max_frames_per_gloss=int(args.frames_per_gloss),
                target_size=ts,
            )
            print(f"10 句视频输出目录: {out_dir}")
            return
        vo = Path(args.video_out.strip())
        if not str(vo):
            raise ValueError("生成单个视频需要 --video_out（或改用 --video_per_sentence）")
        vo = vo.resolve() if vo.is_absolute() else (base / vo).resolve()
        compose_sign_language_video(
            extract_root,
            vo,
            sentences,
            fps=float(args.video_fps),
            max_frames_per_gloss=int(args.frames_per_gloss),
            target_size=ts,
        )

    if bool(args.video_only):
        if bool(args.skip_video):
            raise SystemExit("--video_only 用于生成视频，不能与 --skip_video 同时使用")
        if (not bool(args.video_per_sentence)) and (not str(args.video_out).strip()):
            raise SystemExit("使用 --video_only 生成单个视频时需要有效的 --video_out（或改用 --video_per_sentence）")
        run_compose_video()
        return

    if bool(getattr(args, "skeleton_only", False)) and not bool(getattr(args, "export_skeleton_corpus", False)):
        raise SystemExit("--skeleton_only 需与 --export_skeleton_corpus 同时使用")

    if bool(getattr(args, "export_skeleton_corpus", False)):
        from skeleton_corpus import export_skeleton_corpus_from_front

        if str(getattr(args, "gloss_csv", "")).strip():
            gc = Path(str(args.gloss_csv).strip())
            gc = gc.resolve() if gc.is_absolute() else (base / gc).resolve()
        else:
            gc = (base.parent / "gloss.csv").resolve()
        if not gc.is_file():
            raise FileNotFoundError(f"gloss_csv not found: {gc}")
        export_skeleton_corpus_from_front(
            extract_root,
            gc,
            restrict_gloss_ids=parse_ids_from_sentences(DEFAULT_SENTENCES),
            max_frames_per_gloss=int(args.frames_per_gloss),
            out_subdir=str(getattr(args, "skeleton_out_subdir", "skeleton_corpus") or "skeleton_corpus"),
        )
        if bool(getattr(args, "skeleton_only", False)):
            return

    restrict_csv = ",".join(parse_ids_from_sentences(DEFAULT_SENTENCES))

    cmd = [
        str(python_exe),
        str(train_script),
        "--data_root",
        str(data_root_train),
        "--layout",
        "gloss_id_folder",
        "--epochs",
        str(int(args.epochs)),
        "--batch_size",
        str(int(args.batch_size)),
        "--lr",
        str(float(args.lr)),
        "--weight_decay",
        str(float(args.weight_decay)),
        "--arch",
        str(args.arch),
        "--image_size",
        str(int(args.image_size)),
        "--output_dir",
        str(args.output_dir),
        "--num_workers",
        str(int(args.num_workers)),
        "--split",
        str(args.split),
        "--augment_level",
        str(args.augment_level),
        "--scheduler",
        str(args.scheduler),
        "--class_weight",
        str(args.class_weight),
        "--label_smoothing",
        str(float(args.label_smoothing)),
        "--restrict_gloss_ids",
        restrict_csv,
    ]
    if args.pretrained:
        cmd.append("--pretrained")
    if args.augment:
        cmd.append("--augment")
    if bool(args.overlay_kp):
        cmd.append("--overlay_kp")
        cmd.extend(["--overlay_prob", str(float(args.overlay_prob))])
        if bool(args.overlay_pose):
            cmd.append("--overlay_pose")
        if bool(args.overlay_face_box):
            cmd.append("--overlay_face_box")
    if bool(getattr(args, "semantic_soft_labels", False)):
        cmd.append("--semantic_soft_labels")
        cmd.extend(
            [
                "--semantic_alpha",
                str(float(args.semantic_alpha)),
                "--semantic_tau",
                str(float(args.semantic_tau)),
                "--semantic_topk",
                str(int(args.semantic_topk)),
                "--semantic_dim",
                str(int(args.semantic_dim)),
                "--semantic_text_source",
                str(args.semantic_text_source),
            ]
        )
    if bool(getattr(args, "metric_learning", False)):
        cmd.append("--metric_learning")
        cmd.extend(
            [
                "--embed_dim",
                str(int(args.embed_dim)),
                "--triplet_margin",
                str(float(args.triplet_margin)),
                "--triplet_lambda",
                str(float(args.triplet_lambda)),
                "--triplet_normalize",
            ]
        )
    if args.cpu:
        cmd.append("--cpu")
    if args.amp:
        cmd.append("--amp")
    if bool(getattr(args, "save_confusion_diag", False)):
        cmd.append("--save_confusion_diag")

    print("Running:", " ".join(cmd))
    print(f"[calling_program] data_root={data_root_train} | restrict_gloss_ids={len(restrict_csv.split(','))} ids (extract DEFAULT_SENTENCES)")
    env = os.environ.copy()
    if sys.platform.startswith("win"):
        env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    subprocess.run(cmd, check=True, env=env)

    if (str(args.video_out).strip() or bool(args.video_per_sentence)) and not bool(args.skip_video):
        run_compose_video()


if __name__ == "__main__":
    main()

