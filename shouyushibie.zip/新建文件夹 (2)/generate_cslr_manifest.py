from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple

import numpy as np

from glossary import (
    extract_gloss_ids_from_stem,
    iter_gloss_rows,
    iter_video_paths_many,
    load_gloss_by_int,
    resolve_script_path,
    video_feature_key,
)


def load_gloss_ids(gloss_csv: Path) -> Dict[int, Dict[str, str]]:
    gloss: Dict[int, Dict[str, str]] = {}
    for id_int, row in load_gloss_by_int(gloss_csv).items():
        gloss[id_int] = {"zh": row.zh, "en": row.en}
    return gloss


def extract_token_ids_from_name(name: str, valid_ids: Set[int]) -> List[int]:
    stem = Path(name).stem
    return extract_gloss_ids_from_stem(stem, valid_ids)


def dedupe_videos_by_basename(paths: List[Path]) -> Tuple[List[Path], int]:
    """同一文件名在多个子目录下出现时只保留第一条路径，避免 manifest 重复行。"""
    seen: set[str] = set()
    out: List[Path] = []
    for p in paths:
        name = p.name
        if name in seen:
            continue
        seen.add(name)
        out.append(p)
    return out, len(paths) - len(out)


def dedupe_rows_by_sample_id(rows: List[Dict[str, str]]) -> Tuple[List[Dict[str, str]], int]:
    seen: set[str] = set()
    out: List[Dict[str, str]] = []
    for r in rows:
        sid = r["sample_id"].strip()
        if sid in seen:
            continue
        seen.add(sid)
        out.append(r)
    return out, len(rows) - len(out)


def build_manifest_rows(
    video_files: List[Path],
    valid_ids: Dict[int, Dict[str, str]],
    video_roots: List[Path],
) -> Tuple[List[Dict[str, str]], List[Tuple[str, str]]]:
    rows: List[Dict[str, str]] = []
    failed: List[Tuple[str, str]] = []
    id_set = set(valid_ids.keys())
    for vp in video_files:
        sid = video_feature_key(vp, video_roots)
        token_ids = extract_token_ids_from_name(vp.name, id_set)
        if not token_ids:
            failed.append((sid, "no_token_id_found_in_filename"))
            continue
        if any(tid not in valid_ids for tid in token_ids):
            missing = [str(tid) for tid in token_ids if tid not in valid_ids]
            failed.append((sid, f"unknown_gloss_id:{'|'.join(missing)}"))
            continue

        rows.append(
            {
                "sample_id": sid,
                "target_ids": " ".join(str(t) for t in token_ids),
                "target_words_zh": " ".join(valid_ids[t]["zh"] for t in token_ids),
                "target_words_en": " | ".join(valid_ids[t]["en"] for t in token_ids),
            }
        )
    return rows, failed


def load_sequence_sample_ids(sequence_path: Path) -> List[str]:
    path = Path(sequence_path)
    if not path.is_file():
        raise FileNotFoundError(f"Sequence file not found: {path}")
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=True)
        if "keys" not in z.files:
            raise ValueError("NPZ must contain a 'keys' array (same as extract_pose / 3dcnn export).")
        return [str(x) for x in z["keys"]]
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError("JSON sequence file must be an object mapping sample_id -> features.")
    return sorted(data.keys())


def build_rows_from_sequence_keys(keys: List[str], valid_ids: Dict[int, Dict[str, str]]) -> Tuple[List[Dict[str, str]], List[Tuple[str, str]]]:
    """与 pose_features.json / .npz 或 video_3dcnn_features 的 key 一一对应，每键一行。"""
    rows: List[Dict[str, str]] = []
    failed: List[Tuple[str, str]] = []
    id_set = set(valid_ids.keys())
    for key in keys:
        token_ids = extract_token_ids_from_name(key, id_set)
        if not token_ids:
            failed.append((key, "no_token_id_in_key"))
            continue
        if any(tid not in valid_ids for tid in token_ids):
            missing = [str(tid) for tid in token_ids if tid not in valid_ids]
            failed.append((key, f"unknown_gloss_id:{'|'.join(missing)}"))
            continue
        rows.append(
            {
                "sample_id": key,
                "target_ids": " ".join(str(t) for t in token_ids),
                "target_words_zh": " ".join(valid_ids[t]["zh"] for t in token_ids),
                "target_words_en": " | ".join(valid_ids[t]["en"] for t in token_ids),
            }
        )
    return rows, failed


def build_rows_from_gloss_table(gloss_csv: Path) -> List[Dict[str, str]]:
    """
    按 gloss.csv 每个词目一行（孤立词：sample_id = 「四位补零 id」.mp4，target 为单个 id）。
    用于与「按词目命名」的特征表对齐；若特征 key 为 ``0072_某人.mp4``，请改用 --mode sequence_json。
    """
    rows: List[Dict[str, str]] = []
    for e in iter_gloss_rows(gloss_csv):
        rows.append(
            {
                "sample_id": f"{e.id_str}.mp4",
                "target_ids": str(e.id_int),
                "target_words_zh": e.zh,
                "target_words_en": e.en,
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate CSLR manifest: videos / gloss 全表 / 与 sequence 特征 key 对齐"
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="videos",
        choices=["videos", "gloss", "sequence_json"],
        help="videos: 扫描视频目录；gloss: gloss.csv 每个词一行；sequence_json: 与 pose/rgb 特征文件 key 一致",
    )
    parser.add_argument(
        "--video_dir",
        action="append",
        default=None,
        metavar="DIR",
        help="Video root(s) for --mode videos; repeat to merge. Default ../Videos.",
    )
    parser.add_argument("--gloss_csv", type=str, default=r"..\gloss.csv")
    parser.add_argument(
        "--sequence_json",
        type=str,
        default="outputs/pose_features.json",
        help="--mode sequence_json 时：pose 或 3dcnn 导出的 .json 或 .npz（含 keys）",
    )
    parser.add_argument("--output_csv", type=str, default=r"outputs\cslr_manifest.csv")
    parser.add_argument("--failed_csv", type=str, default=r"outputs\cslr_manifest_failed.csv")
    parser.add_argument(
        "--dedupe_same_basename",
        action="store_true",
        help="Videos mode only: scan then keep one path per filename (legacy). Default: one row per file (sample_id = relative path).",
    )
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    gloss_csv = resolve_script_path(base_dir, args.gloss_csv)
    output_csv = (base_dir / args.output_csv).resolve()
    failed_csv = (base_dir / args.failed_csv).resolve()
    output_csv.parent.mkdir(parents=True, exist_ok=True)

    if not gloss_csv.is_file():
        raise FileNotFoundError(f"Gloss file not found: {gloss_csv}")

    gloss_ids = load_gloss_ids(gloss_csv)
    failed: List[Tuple[str, str]] = []

    if args.mode == "gloss":
        rows = build_rows_from_gloss_table(gloss_csv)
        rows, nd = dedupe_rows_by_sample_id(rows)
        if nd:
            print(f"Note: removed {nd} duplicate sample_id rows (unexpected in gloss mode).")
    elif args.mode == "sequence_json":
        seq_path = (base_dir / args.sequence_json).resolve()
        keys = load_sequence_sample_ids(seq_path)
        rows, failed = build_rows_from_sequence_keys(keys, gloss_ids)
        rows, nd = dedupe_rows_by_sample_id(rows)
        if nd:
            print(f"Note: removed {nd} duplicate sample_id rows.")
        print(f"Sequence keys loaded: {len(keys)} from {seq_path}")
    else:
        rel_dirs = args.video_dir if args.video_dir else [r"..\Videos"]
        video_roots = [resolve_script_path(base_dir, d) for d in rel_dirs]
        existing = [r for r in video_roots if r.is_dir()]
        if not existing:
            raise FileNotFoundError(f"No existing video directory in: {video_roots}")
        print("Video roots (merged):")
        for r in video_roots:
            print(f"  {r}  ({'ok' if r.is_dir() else 'MISSING - skipped'})")
        videos = iter_video_paths_many(existing)
        if not videos:
            raise FileNotFoundError(f"No videos found under: {existing}")
        if args.dedupe_same_basename:
            videos, nd_path = dedupe_videos_by_basename(videos)
            if nd_path:
                print(f"Note: skipped {nd_path} duplicate basename(s) (--dedupe_same_basename).")
        rows, failed = build_manifest_rows(videos, gloss_ids, existing)
        rows, nd_row = dedupe_rows_by_sample_id(rows)
        if nd_row:
            print(f"Note: removed {nd_row} duplicate sample_id row(s) after parse.")

    if not rows:
        raise RuntimeError("No valid manifest rows. Check --mode and inputs.")

    with open(output_csv, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["sample_id", "target_ids", "target_words_zh", "target_words_en"],
        )
        writer.writeheader()
        writer.writerows(rows)

    with open(failed_csv, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["sample_id", "reason"])
        for item in failed:
            writer.writerow(item)

    print(f"Generated manifest: {output_csv}")
    print(f"Rows: {len(rows)}  mode={args.mode}")
    print(f"Failed / skipped report: {failed_csv} ({len(failed)} entries)")


if __name__ == "__main__":
    main()
