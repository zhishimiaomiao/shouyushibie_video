from __future__ import annotations

import argparse
import json
import os
import random
from pathlib import Path
from typing import List, Tuple

import sys

# Workaround for Windows conda OpenMP duplication crash.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import DualStreamDataset, load_dual_stream_samples
from models import DualStreamFusionRecognizer
from glossary import parse_restrict_gloss_ids

from training_io import (
    CHECKPOINT_LAST,
    append_training_run_index,
    finalize_train_log,
    init_train_log,
    maybe_save_epoch_weights,
    resolve_resume_path,
    resolve_run_dir,
    resolve_training_device,
    resume_from_checkpoint,
    save_training_checkpoint,
    should_append_run_index,
    try_run_reports,
    write_history_atomic,
)

LABEL_MAP_NAME = "label_map.json"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def resolve_cli_path(script_dir: Path, user_path: str) -> Path:
    """
    Cross-platform CLI path resolver.

    - Accept Windows-style backslashes even when running on Linux.
    - Relative paths are resolved under script_dir.
    """
    s = str(user_path).strip().replace("\\", "/")
    p = Path(s)
    return p.resolve() if p.is_absolute() else (script_dir / p).resolve()


def stratified_split(indices: np.ndarray, labels: np.ndarray, test_ratio: float, seed: int):
    rng = np.random.default_rng(seed)
    train_idx = []
    test_idx = []
    for class_id in np.unique(labels):
        cls_indices = indices[labels == class_id]
        rng.shuffle(cls_indices)
        n = len(cls_indices)
        if n <= 1:
            # Keep singletons in train so the classifier can at least see them.
            train_idx.extend(cls_indices.tolist())
            continue
        n_test = max(1, int(n * test_ratio))
        if n_test >= n:
            n_test = n - 1
        test_idx.extend(cls_indices[:n_test].tolist())
        train_idx.extend(cls_indices[n_test:].tolist())
    rng.shuffle(train_idx)
    rng.shuffle(test_idx)
    return np.asarray(train_idx, dtype=np.int64), np.asarray(test_idx, dtype=np.int64)


def stratified_kfold_indices(indices: np.ndarray, labels: np.ndarray, k: int, seed: int) -> List[np.ndarray]:
    """
    Simple stratified K-fold split without sklearn:
    returns a list of folds, each fold is an array of indices for that fold's test set.
    """
    if k <= 1:
        raise ValueError("k must be > 1 for k-fold")
    rng = np.random.default_rng(seed)
    folds: List[List[int]] = [[] for _ in range(int(k))]
    for class_id in np.unique(labels):
        cls_indices = indices[labels == class_id].copy()
        rng.shuffle(cls_indices)
        # Round-robin assignment keeps folds balanced.
        for i, idx in enumerate(cls_indices.tolist()):
            folds[i % k].append(int(idx))
    out = [np.asarray(f, dtype=np.int64) for f in folds]
    return out


def stratified_subsample(indices: np.ndarray, labels: np.ndarray, ratio: float, seed: int) -> np.ndarray:
    """
    Stratified subsample of `indices` according to `labels`.
    Keeps at least 1 sample per present class when ratio > 0.
    """
    ratio = float(ratio)
    if ratio >= 1.0:
        return np.asarray(indices, dtype=np.int64)
    if ratio <= 0.0:
        raise ValueError("--train_subset_ratio must be in (0, 1].")

    rng = np.random.default_rng(seed)
    indices = np.asarray(indices, dtype=np.int64)
    chosen: List[int] = []
    sub_labels = labels[indices]
    for class_id in np.unique(sub_labels):
        cls_idx = indices[sub_labels == class_id]
        rng.shuffle(cls_idx)
        n = len(cls_idx)
        k = max(1, int(round(n * ratio)))
        k = min(k, n)
        chosen.extend(cls_idx[:k].tolist())
    rng.shuffle(chosen)
    return np.asarray(chosen, dtype=np.int64)


def run_epoch(model, loader, criterion, optimizer, device, grad_clip_norm: float = 0.0):
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    preds = []
    labels = []
    for rgb, pose, y in tqdm(loader, leave=False):
        rgb = rgb.to(device)
        pose = pose.to(device)
        y = y.to(device)
        with torch.set_grad_enabled(is_train):
            logits = model(rgb, pose)
            loss = criterion(logits, y)
            if is_train:
                optimizer.zero_grad()
                loss.backward()
                if grad_clip_norm and grad_clip_norm > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(grad_clip_norm))
                optimizer.step()
        total_loss += loss.item() * rgb.size(0)
        preds.append(logits.argmax(dim=1).detach().cpu().numpy())
        labels.append(y.detach().cpu().numpy())
    if len(loader.dataset) == 0 or not preds or not labels:
        return {"loss": 0.0, "acc": 0.0}
    preds = np.concatenate(preds)
    labels = np.concatenate(labels)
    acc = float((preds == labels).mean())
    return {"loss": total_loss / len(loader.dataset), "acc": acc}


def remap_labels_to_contiguous(samples) -> tuple[list, dict]:
    """
    Remap arbitrary integer labels (e.g. GlossID 4729) to contiguous class indices 0..C-1.
    This is critical because CrossEntropyLoss expects class indices in [0, C-1].
    """
    raw = np.asarray([int(s.label) for s in samples], dtype=np.int64)
    uniq = sorted(set(raw.tolist()))
    gloss_id_to_idx = {str(g): int(i) for i, g in enumerate(uniq)}
    idx_to_gloss_id = [int(g) for g in uniq]
    for s in samples:
        s.label = int(gloss_id_to_idx[str(int(s.label))])
    label_map = {"idx_to_gloss_id": idx_to_gloss_id, "gloss_id_to_idx": gloss_id_to_idx}
    return samples, label_map


def _train_one_split(
    *,
    samples,
    labels: np.ndarray,
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    args,
    run_dir: Path,
    output_base: Path,
    run_label: str,
    fold_tag: str | None = None,
) -> Tuple[dict, dict]:
    # Optional: shrink training set for quick experiments on huge datasets.
    if float(getattr(args, "train_subset_ratio", 1.0)) < 1.0:
        before = int(len(train_idx))
        train_idx = stratified_subsample(
            train_idx,
            labels=labels,
            ratio=float(args.train_subset_ratio),
            seed=int(args.seed),
        )
        print(
            f"WARN: train_subset_ratio={float(args.train_subset_ratio):.3f} "
            f"-> train samples {before} -> {int(len(train_idx))}"
            + (f" | {fold_tag}" if fold_tag else "")
        )

    train_ds = DualStreamDataset(samples, train_idx)
    test_ds = DualStreamDataset(samples, test_idx)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, num_workers=0)

    rgb_dim = int(samples[0].rgb.shape[0])
    pose_dim = int(samples[0].pose.shape[1])
    num_classes = int(labels.max()) + 1

    device = resolve_training_device(force_cpu=bool(getattr(args, "cpu", False)))
    model = DualStreamFusionRecognizer(
        rgb_dim=rgb_dim,
        pose_dim=pose_dim,
        hidden_dim=args.hidden_dim,
        num_classes=num_classes,
        dropout=float(args.dropout),
    ).to(device)
    try:
        criterion = nn.CrossEntropyLoss(label_smoothing=float(args.label_smoothing))
    except TypeError:
        criterion = nn.CrossEntropyLoss()
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = None
    if args.scheduler == "cosine":
        scheduler = CosineAnnealingLR(optimizer, T_max=int(args.epochs), eta_min=float(args.min_lr))
    elif args.scheduler == "plateau":
        scheduler = ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(args.plateau_factor),
            patience=int(args.plateau_patience),
            min_lr=float(args.min_lr),
        )

    history = {"train_loss": [], "train_acc": [], "test_loss": [], "test_acc": []}
    best_acc = 0.0
    best_epoch = 0
    no_improve = 0
    start_epoch = 1
    if args.resume:
        base_dir = Path(__file__).resolve().parent
        resume_p = resolve_resume_path(base_dir, args.resume)
        if not resume_p.is_file():
            raise FileNotFoundError(f"Resume checkpoint not found: {resume_p}")
        rs = resume_from_checkpoint(resume_p, model, optimizer, scheduler, device, default_history=history)
        start_epoch = rs.start_epoch
        history = rs.history
        best_acc = rs.best_metric
        best_epoch = int(np.argmax(np.asarray(history.get("test_acc", [0.0]), dtype=np.float64))) + 1 if history.get("test_acc") else 0
        print(f"Resumed from epoch {start_epoch - 1}, best_test_acc={best_acc:.6f}, run_dir={run_dir}")

    # Where camera_interface.py looks by default.
    camera_best_path = output_base / "best_fusion_model.pt"

    for epoch in range(start_epoch, args.epochs + 1):
        train_m = run_epoch(model, train_loader, criterion, optimizer, device, grad_clip_norm=float(args.grad_clip_norm))
        test_m = run_epoch(model, test_loader, criterion, None, device, grad_clip_norm=0.0)
        history["train_loss"].append(train_m["loss"])
        history["train_acc"].append(train_m["acc"])
        history["test_loss"].append(test_m["loss"])
        history["test_acc"].append(test_m["acc"])
        improved = (test_m["acc"] - best_acc) > float(args.early_stop_min_delta)
        if improved:
            best_acc = test_m["acc"]
            best_epoch = epoch
            no_improve = 0
            torch.save(model.state_dict(), run_dir / "best_fusion_model.pt")
            # Also export to output_base for camera usage (overwrites previous best).
            if bool(args.export_camera_best):
                try:
                    torch.save(model.state_dict(), camera_best_path)
                except Exception as e:
                    print(f"WARN: failed to export camera best checkpoint to {camera_best_path}: {e}")
        else:
            no_improve += 1

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(float(test_m["loss"]))
            else:
                scheduler.step()

        cur_lr = float(optimizer.param_groups[0]["lr"])
        write_history_atomic(run_dir, history)
        save_training_checkpoint(
            run_dir / CHECKPOINT_LAST,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            epoch=epoch,
            history=history,
            best_metric=best_acc,
            metric_name="test_acc",
            extra={
                "epochs_target": args.epochs,
                "best_epoch": best_epoch,
                "scheduler": args.scheduler,
                "lr": cur_lr,
                "fold_tag": fold_tag,
                "run_label": run_label,
            },
        )
        maybe_save_epoch_weights(run_dir, model, epoch, args.epoch_ckpt_every, prefix="epoch_weights")
        print(
            f"Epoch [{epoch}/{args.epochs}] "
            f"train_acc={train_m['acc']:.4f} test_acc={test_m['acc']:.4f} lr={cur_lr:.2e}"
            + (f" | {fold_tag}" if fold_tag else "")
        )

        if args.early_stop_patience > 0 and no_improve >= int(args.early_stop_patience):
            print(
                f"Early stopping: no test_acc improvement for {no_improve} epochs "
                f"(best={best_acc:.4f} at epoch {best_epoch})."
                + (f" | {fold_tag}" if fold_tag else "")
            )
            break

    # Always generate a per-run SVG curve into run_dir so users can see results immediately.
    try:
        from report_runs import plot_run

        title = f"{run_label}" + (f" | {fold_tag}" if fold_tag else "")
        title += f" | seed={int(args.seed)}"
        plot_run(history, title=title, save_path=(run_dir / "training_curves.svg"))
    except Exception as e:
        print(f"WARN: failed to write per-run plot: {e}")

    metrics = {
        "best_test_accuracy": best_acc,
        "best_epoch": best_epoch,
        "epochs_ran": len(history.get("test_acc", [])),
        "num_classes": num_classes,
        "run_dir": str(run_dir),
        "run_label": run_label,
        "scheduler": args.scheduler,
        "dropout": float(args.dropout),
        "label_smoothing": float(args.label_smoothing),
        "early_stop_patience": int(args.early_stop_patience),
        "early_stop_min_delta": float(args.early_stop_min_delta),
        "seed": int(args.seed),
        "fold_tag": fold_tag,
        "exported_camera_best": str(camera_best_path) if bool(args.export_camera_best) else None,
        "train_size": int(len(train_ds)),
        "test_size": int(len(test_ds)),
    }
    return history, metrics


def main():
    parser = argparse.ArgumentParser(description="Dual-stream fusion trainer (3D-CNN + MediaPipe)")
    parser.add_argument(
        "--pose_only",
        action="store_true",
        help="只用 pose 特征训练（rgb 自动使用全零占位），适合先跑通词汇多分类闭环。",
    )
    parser.add_argument(
        "--rgb_dim",
        type=int,
        default=768,
        help="--pose_only 时使用的 rgb 占位维度（默认 768）。",
    )
    parser.add_argument(
        "--rgb_json",
        type=str,
        default="outputs/video_3dcnn_features.npz",
        help="RGB / 3D-CNN vectors: .json (from real video) or .npz (CSV fallback from extract_3dcnn_features).",
    )
    parser.add_argument(
        "--pose_json",
        type=str,
        default="outputs/pose_features.npz",
        help="Pose features: .json (MediaPipe export) or .npz (keys+pose array) from extract_pose_mediapipe fallback.",
    )
    parser.add_argument(
        "--restrict_gloss_ids",
        type=str,
        default="",
        help="只保留这些 gloss id 的样本（逗号分隔或 @file）；与 train_image 语法一致（如 extract 十句词表）",
    )
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--hidden_dim", type=int, default=256)
    parser.add_argument("--dropout", type=float, default=0.2, help="Model dropout (default matches models.py)")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--test_ratio", type=float, default=0.2, help="Holdout ratio when not using k-fold")
    parser.add_argument(
        "--train_subset_ratio",
        type=float,
        default=1.0,
        help="仅使用训练集的一部分进行训练（0~1]，例如 0.1 表示用 10% 训练数据；分层采样保证各类尽量保留",
    )
    parser.add_argument("--label_smoothing", type=float, default=0.0, help="CrossEntropy label smoothing (0=off)")
    parser.add_argument(
        "--scheduler",
        type=str,
        default="plateau",
        choices=["none", "plateau", "cosine"],
        help="LR scheduler: plateau uses ReduceLROnPlateau on test loss; cosine uses CosineAnnealingLR",
    )
    parser.add_argument("--min_lr", type=float, default=1e-6, help="plateau: min lr; cosine: eta_min")
    parser.add_argument("--plateau_factor", type=float, default=0.5, help="ReduceLROnPlateau factor")
    parser.add_argument("--plateau_patience", type=int, default=3, help="ReduceLROnPlateau patience (epochs)")
    parser.add_argument("--grad_clip_norm", type=float, default=0.0, help="Clip grad norm (0=off)")
    parser.add_argument("--early_stop_patience", type=int, default=10, help="Stop if no test acc improve for N epochs (0=off)")
    parser.add_argument("--early_stop_min_delta", type=float, default=0.0, help="Min test acc delta to count as improvement")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", type=str, default="outputs/fusion")
    parser.add_argument("--run_name", type=str, default=None, help="子目录名；默认 run_YYYY-mm-dd_HHMMSS")
    parser.add_argument("--flat_output", action="store_true", help="直接写入 output_dir，不建时间戳子目录")
    parser.add_argument("--resume", type=str, default=None, help="从 checkpoint_last.pt 续训")
    parser.add_argument("--epoch_ckpt_every", type=int, default=0, help="每 N epoch 保存 epoch_weights_epoch_NNN.pt")
    parser.add_argument("--auto_report", action="store_true", help="训练结束后自动生成 reports/ 图+表")
    parser.add_argument("--reports_dir", type=str, default="reports", help="auto_report 输出目录（相对当前脚本目录）")
    parser.add_argument("--report_limit", type=int, default=20, help="auto_report 仅汇总最近 N 个 runs（0=全部）")
    parser.add_argument(
        "--write_runs_index",
        action="store_true",
        help="在 output 根目录追加 training_runs_index.jsonl（默认关闭，减少杂乱）",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="强制使用 CPU（默认无 GPU 时会报错退出，不进行 CPU 训练）",
    )
    parser.add_argument(
        "--k_folds",
        type=int,
        default=0,
        help="Stratified K-fold CV (0=off). If >1, use folds as test splits.",
    )
    parser.add_argument(
        "--fold",
        type=int,
        default=-1,
        help="When --k_folds>1: which fold index to run (0..K-1). -1 = run all folds sequentially.",
    )
    # Python < 3.9: argparse.BooleanOptionalAction doesn't exist.
    _bool_opt = getattr(argparse, "BooleanOptionalAction", None)
    if _bool_opt is not None:
        parser.add_argument(
            "--export_camera_best",
            action=_bool_opt,
            default=True,
            help="同步保存 best_fusion_model.pt 到 outputs/fusion/best_fusion_model.pt（默认开启）",
        )
    else:
        parser.add_argument(
            "--export_camera_best",
            dest="export_camera_best",
            action="store_true",
            default=True,
            help="同步保存 best_fusion_model.pt 到 outputs/fusion/best_fusion_model.pt（默认开启；旧版 Python 兼容）",
        )
        parser.add_argument(
            "--no-export_camera_best",
            dest="export_camera_best",
            action="store_false",
            help="不导出 outputs/fusion/best_fusion_model.pt（旧版 Python 兼容）",
        )
    args = parser.parse_args()

    set_seed(args.seed)
    base_dir = Path(__file__).resolve().parent
    restrict_ids = parse_restrict_gloss_ids(str(getattr(args, "restrict_gloss_ids", "") or ""), base_dir)
    rgb_json = resolve_cli_path(base_dir, args.rgb_json)
    pose_json = resolve_cli_path(base_dir, args.pose_json)
    output_base = resolve_cli_path(base_dir, args.output_dir)
    resume_p = resolve_resume_path(base_dir, args.resume) if args.resume else None
    run_dir, run_label = resolve_run_dir(output_base, args.run_name, args.flat_output, resume_p)
    init_train_log(run_dir, args, "train_fusion.py", run_label)
    append_training_run_index(
        output_base,
        run_label,
        run_dir,
        append=should_append_run_index(resume_p, args.run_name, run_dir),
        enabled=bool(args.write_runs_index),
    )

    if bool(args.pose_only):
        from dataset import load_pose_feature_map, DualSample, parse_label_from_name

        pose_map = load_pose_feature_map(pose_json)
        if not pose_map:
            raise ValueError("pose_json is empty or invalid.")
        samples = []
        for name in sorted(pose_map.keys()):
            label = parse_label_from_name(name)
            pose = pose_map[name]
            if pose.ndim == 1:
                pose = pose[None, :]
            rgb = np.zeros((int(args.rgb_dim),), dtype=np.float32)
            samples.append(DualSample(rgb=rgb, pose=np.asarray(pose, dtype=np.float32), label=int(label)))
    else:
        samples = load_dual_stream_samples(rgb_json, pose_json)

    if restrict_ids:
        allow_int = {int(x) for x in restrict_ids}
        before_n = len(samples)
        samples = [s for s in samples if int(s.label) in allow_int]
        if len(samples) < 2:
            raise ValueError(
                f"--restrict_gloss_ids 过滤后样本不足 2 条（当前 {len(samples)}），过滤前 {before_n}。"
                "请检查 pose/rgb 特征与词表 id 是否一致。"
            )
        print(f"[train_fusion] restrict_gloss_ids: kept {len(samples)}/{before_n} samples")

    # IMPORTANT: remap labels (GlossID) -> contiguous class indices for classification.
    samples, label_map = remap_labels_to_contiguous(samples)
    try:
        (run_dir / LABEL_MAP_NAME).write_text(json.dumps(label_map, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"WARN: failed to write {LABEL_MAP_NAME} under run_dir: {e}")
    if bool(getattr(args, "export_camera_best", False)):
        try:
            (output_base / LABEL_MAP_NAME).write_text(json.dumps(label_map, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"WARN: failed to export {LABEL_MAP_NAME} to outputs/fusion: {e}")
    labels = np.asarray([s.label for s in samples], dtype=np.int64)
    indices = np.arange(len(samples), dtype=np.int64)

    # Either run a single holdout split, or K-fold CV.
    all_fold_metrics = []
    if int(args.k_folds) and int(args.k_folds) > 1:
        k = int(args.k_folds)
        folds = stratified_kfold_indices(indices, labels, k=k, seed=int(args.seed))
        fold_to_run = int(args.fold)
        fold_ids = list(range(k)) if fold_to_run < 0 else [fold_to_run]
        for fi in fold_ids:
            if fi < 0 or fi >= k:
                raise ValueError(f"--fold must be in [0..{k-1}] or -1, got {fi}")
            test_idx = folds[fi]
            mask = np.ones(len(indices), dtype=bool)
            mask[test_idx] = False
            train_idx = indices[mask]
            fold_tag = f"fold_{fi+1:02d}_of_{k:02d}"
            fold_dir = run_dir / fold_tag if len(fold_ids) > 1 else run_dir
            fold_dir.mkdir(parents=True, exist_ok=True)
            init_train_log(fold_dir, args, "train_fusion.py", run_label if fold_dir == run_dir else f"{run_label}/{fold_tag}")
            history, fold_metrics = _train_one_split(
                samples=samples,
                labels=labels,
                train_idx=train_idx,
                test_idx=test_idx,
                args=args,
                run_dir=fold_dir,
                output_base=output_base,
                run_label=run_label,
                fold_tag=fold_tag,
            )
            all_fold_metrics.append(fold_metrics)
            finalize_train_log(
                fold_dir,
                script="train_fusion.py",
                run_label=run_label if fold_dir == run_dir else f"{run_label}/{fold_tag}",
                args=args,
                history=history,
                metrics=fold_metrics,
            )
        # Aggregate CV summary under root run_dir (even when running a single fold).
        bests = [float(m.get("best_test_accuracy", 0.0)) for m in all_fold_metrics]
        metrics = {
            "cv_k_folds": k,
            "cv_folds_ran": len(all_fold_metrics),
            "cv_best_test_accuracy_mean": float(np.mean(bests)) if bests else 0.0,
            "cv_best_test_accuracy_std": float(np.std(bests)) if bests else 0.0,
            "run_dir": str(run_dir),
            "run_label": run_label,
            "seed": int(args.seed),
            "exported_camera_best": str((output_base / "best_fusion_model.pt")) if bool(args.export_camera_best) else None,
        }
        history = {"folds": all_fold_metrics}
    else:
        train_idx, test_idx = stratified_split(indices, labels, test_ratio=float(args.test_ratio), seed=args.seed)
        if len(test_idx) == 0:
            # Dataset may have many singleton classes (1 sample per class). Stratified split keeps
            # singletons in train, which can produce an empty test set. Fall back to a plain random split.
            rng = np.random.default_rng(int(args.seed))
            shuffled = indices.copy()
            rng.shuffle(shuffled)
            n_test = max(1, int(round(float(args.test_ratio) * len(shuffled)))) if float(args.test_ratio) > 0 else 0
            n_test = min(n_test, max(0, len(shuffled) - 1))
            test_idx = shuffled[:n_test]
            train_idx = shuffled[n_test:]
            print(
                "WARN: stratified split produced empty test set; "
                f"fallback to random split: train={len(train_idx)} test={len(test_idx)}"
            )
        history, metrics = _train_one_split(
            samples=samples,
            labels=labels,
            train_idx=train_idx,
            test_idx=test_idx,
            args=args,
            run_dir=run_dir,
            output_base=output_base,
            run_label=run_label,
            fold_tag=None,
        )
        metrics["resume_from"] = str(resolve_resume_path(base_dir, args.resume)) if args.resume else None
    finalize_train_log(
        run_dir,
        script="train_fusion.py",
        run_label=run_label,
        args=args,
        history=history,
        metrics=metrics,
    )
    if "best_test_accuracy" in metrics:
        print(f"Best fusion accuracy: {float(metrics['best_test_accuracy']):.4f}")
    else:
        print(
            f"CV mean best fusion accuracy: {float(metrics.get('cv_best_test_accuracy_mean', 0.0)):.4f} "
            f"+/- {float(metrics.get('cv_best_test_accuracy_std', 0.0)):.4f}"
        )
    print(f"Run directory: {run_dir}")
    print(f"Per-run plot: {run_dir / 'training_curves.svg'}")
    if args.auto_report:
        try_run_reports(base_dir, outputs_dir=output_base, reports_dir=(base_dir / args.reports_dir).resolve(), limit=int(args.report_limit))


if __name__ == "__main__":
    main()
