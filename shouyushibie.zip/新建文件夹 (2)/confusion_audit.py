from __future__ import annotations

import argparse
import csv
import json
import shutil
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torchvision import transforms

from camera_interface import load_image_model, load_image_training_log, pick_latest_image_run


@dataclass(frozen=True)
class Sample:
    path: Path
    gt_id: str  # 4-digit gloss id
    frame_name: str  # file basename


def iter_gloss_id_images(front_root: Path) -> list[Sample]:
    """
    Scan extract_dataset/front/<gid>/*.jpg.
    """
    out: list[Sample] = []
    front_root = front_root.resolve()
    if not front_root.is_dir():
        return out
    for gid_dir in sorted([p for p in front_root.iterdir() if p.is_dir()], key=lambda p: p.name):
        gid = gid_dir.name.strip()
        if len(gid) != 4 or (not gid.isdigit()):
            continue
        for img_p in sorted([p for p in gid_dir.iterdir() if p.is_file()], key=lambda p: p.name.lower()):
            if img_p.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}:
                continue
            out.append(Sample(path=img_p, gt_id=gid, frame_name=img_p.name))
    return out


def _ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def main() -> None:
    ap = argparse.ArgumentParser(description="Audit confusion pairs on extract_dataset (image model).")
    ap.add_argument("--extract_root", type=str, default="extract_dataset", help="extract.py output root (contains front/0000/*.jpg)")
    ap.add_argument("--outputs_dir", type=str, default="outputs/image_extract", help="Where train_image.py writes runs")
    ap.add_argument("--checkpoint", type=str, default="", help="Optional: explicit best_image_model.pt path")
    ap.add_argument("--train_log", type=str, default="", help="Optional: explicit 训练记录.json path (for class_to_idx/arch/image_size)")
    ap.add_argument("--limit", type=int, default=0, help="Limit number of images to scan (0=all)")
    ap.add_argument("--topk", type=int, default=30, help="Top-K confusion pairs to report")
    ap.add_argument("--copy_per_pair", type=int, default=40, help="Copy up to N example images per confusion pair (0=do not copy)")
    ap.add_argument("--out_dir", type=str, default="reports/confusions", help="Output directory (under sign_language_system)")
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    extract_root = (base / args.extract_root).resolve() if not Path(args.extract_root).is_absolute() else Path(args.extract_root).resolve()
    front = extract_root / "front"
    if not front.is_dir():
        raise FileNotFoundError(f"front not found: {front}")

    outputs_dir = (base / args.outputs_dir).resolve() if not Path(args.outputs_dir).is_absolute() else Path(args.outputs_dir).resolve()
    ckpt: Path | None = None
    log_p: Path | None = None
    if str(args.checkpoint).strip():
        ckpt = (base / args.checkpoint).resolve() if not Path(args.checkpoint).is_absolute() else Path(args.checkpoint).resolve()
        if str(args.train_log).strip():
            log_p = (base / args.train_log).resolve() if not Path(args.train_log).is_absolute() else Path(args.train_log).resolve()
        else:
            cand = ckpt.parent / "训练记录.json"
            log_p = cand if cand.is_file() else None
    else:
        ckpt, log_p = pick_latest_image_run(outputs_dir)
    if ckpt is None or not ckpt.is_file():
        raise FileNotFoundError(f"No checkpoint found under: {outputs_dir}. Pass --checkpoint explicitly.")
    if log_p is None or not log_p.is_file():
        raise FileNotFoundError("Missing 训练记录.json. Pass --train_log explicitly.")

    arch, image_size, class_to_idx = load_image_training_log(log_p)
    if not isinstance(class_to_idx, dict) or not class_to_idx:
        raise RuntimeError("训练记录.json missing class_to_idx; cannot map predictions to labels.")
    idx_to_class = {int(v): str(k) for k, v in class_to_idx.items()}
    num_classes = len(class_to_idx)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = load_image_model(ckpt, device, arch=arch, num_classes=num_classes)
    image_size = int(image_size) if image_size is not None else 224
    tfm = transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )

    samples = iter_gloss_id_images(front)
    if int(args.limit) > 0:
        samples = samples[: int(args.limit)]
    if not samples:
        raise RuntimeError(f"No images found under: {front}")

    # Confusion bookkeeping.
    pair_to_items: dict[tuple[str, str], list[tuple[Path, str]]] = defaultdict(list)
    pair_counts: Counter[tuple[str, str]] = Counter()
    total = 0
    wrong = 0

    model.eval()
    with torch.no_grad():
        for s in samples:
            total += 1
            img = Image.open(s.path).convert("RGB")
            x = tfm(img).unsqueeze(0).to(device)
            logits = model(x)
            pred_idx = int(logits.argmax(dim=1).item())
            pred_label = idx_to_class.get(pred_idx, str(pred_idx))
            gt_label = s.gt_id
            # Normalize numeric labels to 4-digit if possible.
            if str(pred_label).isdigit():
                pred_label = str(int(str(pred_label))).zfill(4)
            if pred_label != gt_label:
                wrong += 1
                key = (gt_label, pred_label)  # GT -> Pred
                pair_counts[key] += 1
                pair_to_items[key].append((s.path, s.frame_name))

    stamp = time.strftime("run_%Y-%m-%d_%H%M%S")
    out_root = _ensure_dir((base / args.out_dir).resolve() / stamp)
    (out_root / "meta.json").write_text(
        json.dumps(
            {
                "checkpoint": str(ckpt),
                "train_log": str(log_p),
                "extract_root": str(extract_root),
                "front": str(front),
                "total_images": total,
                "wrong_images": wrong,
                "wrong_rate": (wrong / max(1, total)),
                "topk": int(args.topk),
                "copy_per_pair": int(args.copy_per_pair),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    topk = int(args.topk)
    top_pairs = pair_counts.most_common(topk)

    # CSV summary.
    with open(out_root / "confusion_pairs.csv", "w", encoding="utf-8-sig", newline="") as f:
        wcsv = csv.writer(f)
        wcsv.writerow(["rank", "gt_id", "pred_id", "count"])
        for i, ((gt, pred), cnt) in enumerate(top_pairs, start=1):
            wcsv.writerow([i, gt, pred, int(cnt)])

    # Per-pair indices + optional image grouping.
    groups_dir = _ensure_dir(out_root / "groups")
    for (gt, pred), cnt in top_pairs:
        items = pair_to_items.get((gt, pred), [])
        pair_dir = _ensure_dir(groups_dir / f"GT_{gt}__PRED_{pred}__N_{int(cnt)}")
        # Write indices list (frame names + absolute paths).
        lines = [f"{name}\t{str(p)}" for (p, name) in items]
        (pair_dir / "frames_and_paths.txt").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
        # Extract image indices (numbers in filename) for quick lookup.
        idxs = []
        for _, name in items:
            stem = Path(name).stem
            if stem.isdigit():
                idxs.append(int(stem))
        if idxs:
            idxs_sorted = sorted(idxs)
            (pair_dir / "frame_indices.txt").write_text(
                " ".join(str(x).zfill(5) for x in idxs_sorted) + "\n",
                encoding="utf-8",
            )
        # Copy example images.
        if int(args.copy_per_pair) > 0:
            for j, (p, _) in enumerate(items[: int(args.copy_per_pair)]):
                try:
                    shutil.copy2(p, pair_dir / f"{j:04d}_{p.name}")
                except Exception:
                    continue

    print(f"[confusion_audit] Saved: {out_root}")
    print(f"[confusion_audit] total={total} wrong={wrong} wrong_rate={wrong/max(1,total):.4f}")


if __name__ == "__main__":
    main()

