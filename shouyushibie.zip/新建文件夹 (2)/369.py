"""
(369) 离线验证快捷入口：参数与 butting_connectro.py 中「--video 模式」一致（默认 sentence_videos、
半速、无额外预热等由 butting_connectro 与 camera_interface 处理）。

识别与 UI 逻辑在 butting_connectro.py -> camera_interface.py；本文件仅子进程包装，便于旧命令行习惯。
等效命令示例：

  python butting_connectro.py --video sentence_videos --max_videos 0 --warmup_seconds 0

（--draw_kp 在 butting_connectro 中已默认开启。词表仅 extract 十句子集，见 butting_connectro --gloss_source。）
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

# Workaround for Windows conda OpenMP duplication crash.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")


def main() -> None:
    parser = argparse.ArgumentParser(description="(369) Offline validation wrapper (butting_connectro -> camera_interface)")
    parser.add_argument(
        "--video",
        type=str,
        default="sentence_videos",
        help="要验证的视频文件或目录（默认 sentence_videos，来自 extract.py / calling_program.py 输出）",
    )
    parser.add_argument("--max_videos", type=int, default=0, help="--video 为目录时最多跑前 N 个视频（0=全部）")
    parser.add_argument("--outputs_dir", type=str, default="outputs/image_extract", help="butting_connectro 使用的训练输出目录")
    parser.add_argument(
        "--gloss_source",
        type=str,
        default=r"..\gloss.csv",
        help="完整 gloss.csv；butting_connectro 会裁剪为 extract 十句词表子集再给界面（不传全表）",
    )
    parser.add_argument("--camera", type=int, default=0, help="当 --video 为空时才会用到（一般不需要）")
    _bool_opt = getattr(argparse, "BooleanOptionalAction", None)
    if _bool_opt is not None:
        parser.add_argument("--draw_kp", action=_bool_opt, default=True, help="叠加骨骼关键点（默认开启；可用 --no-draw_kp 关闭）")
    else:
        # Old Python fallback: default ON, user can still omit by passing --draw_kp_off
        parser.add_argument("--draw_kp", action="store_true", default=True, help="叠加骨骼关键点（默认开启）")
    parser.add_argument("--draw_pose", action="store_true")
    parser.add_argument("--draw_face_box", action="store_true")
    parser.add_argument("--playback_speed", type=float, default=0.5, help="视频验证播放速度倍率（默认 0.5=半速）")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    runner = (base / "butting_connectro.py").resolve()
    if not runner.is_file():
        raise FileNotFoundError(f"butting_connectro.py not found: {runner}")

    cmd = [
        sys.executable,
        str(runner),
        "--outputs_dir",
        str(args.outputs_dir),
        "--gloss_source",
        str(args.gloss_source),
        "--camera",
        str(int(args.camera)),
        "--video",
        str(args.video),
        "--max_videos",
        str(int(args.max_videos)),
    ]
    if bool(args.draw_kp):
        cmd.append("--draw_kp")
        if bool(args.draw_pose):
            cmd.append("--draw_pose")
        if bool(args.draw_face_box):
            cmd.append("--draw_face_box")

    print("[369] Running:", " ".join(cmd))
    env = os.environ.copy()
    if sys.platform.startswith("win"):
        env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    # For offline video validation: do not wait warmup; make commits easier to observe.
    cmd.extend(["--warmup_seconds", "0", "--playback_speed", str(float(args.playback_speed))])
    subprocess.run(cmd, check=True, env=env)


if __name__ == "__main__":
    main()

