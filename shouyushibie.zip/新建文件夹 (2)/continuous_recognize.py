from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter, deque
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import cv2
import numpy as np
import torch
from PIL import Image
from torchvision import transforms

from glossary import load_gloss_tuples as load_gloss_map
from train_image import build_model


def _normalize_state_dict(state: dict) -> dict:
    if not state:
        return state
    if any(k.startswith("module.") for k in state.keys()):
        return {k.replace("module.", "", 1): v for k, v in state.items()}
    return state


def _infer_num_classes_from_state(state: dict) -> int | None:
    for k in ("fc.weight", "classifier.1.weight", "classifier.0.weight", "classifier.2.weight"):
        w = state.get(k)
        if w is not None and hasattr(w, "shape") and len(w.shape) == 2:
            return int(w.shape[0])
    return None


def load_image_training_log(log_path: Path) -> tuple[str | None, int | None, dict[str, int] | None]:
    if not log_path or not log_path.is_file():
        return None, None, None
    doc = json.loads(log_path.read_text(encoding="utf-8"))
    cfg = doc.get("命令与配置") or {}
    res = doc.get("训练结果") or {}
    arch = cfg.get("arch")
    image_size = cfg.get("image_size")
    c2i = res.get("class_to_idx")
    if isinstance(c2i, dict):
        class_to_idx = {str(k): int(v) for k, v in c2i.items()}
    else:
        class_to_idx = None
    return (str(arch) if arch is not None else None, int(image_size) if image_size is not None else None, class_to_idx)


def pick_latest_image_extract_run(outputs_dir: Path) -> tuple[Path | None, Path | None]:
    """
    Pick newest run under outputs/image_extract or outputs/image.
    Returns (checkpoint_path, train_log_path).
    """
    if not outputs_dir.is_dir():
        return None, None
    runs = sorted(outputs_dir.glob("run_*"), key=lambda p: p.name, reverse=True)
    for r in runs:
        if not r.is_dir():
            continue
        log_p = r / "训练记录.json"
        if not log_p.is_file():
            continue
        for ckpt_name in ("best_image_model.pt", "checkpoint_last.pt"):
            ckpt_p = r / ckpt_name
            if ckpt_p.is_file():
                return ckpt_p, log_p
    return None, None


def load_image_model(
    ckpt: Path,
    device: torch.device,
    *,
    arch: str | None,
    num_classes: int | None,
) -> torch.nn.Module:
    payload = torch.load(ckpt, map_location="cpu")
    if isinstance(payload, dict) and "model_state_dict" in payload:
        state = payload["model_state_dict"]
    else:
        state = payload
    if not isinstance(state, dict):
        raise RuntimeError(f"Unsupported checkpoint format: {ckpt}")
    state = _normalize_state_dict(state)
    if num_classes is None:
        num_classes = _infer_num_classes_from_state(state)
    if num_classes is None or int(num_classes) <= 0:
        raise RuntimeError("无法从 checkpoint 推断 num_classes；请提供包含 class_to_idx 的 训练记录.json。")

    arch = (arch or "resnet18").strip().lower()
    model = build_model(num_classes=int(num_classes), pretrained=False, arch=arch).to(device)
    model.load_state_dict(state, strict=True)
    model.eval()
    return model


def _idx_to_label_maps(class_to_idx: dict[str, int] | None) -> tuple[dict[int, str], bool]:
    if not isinstance(class_to_idx, dict) or not class_to_idx:
        return {}, False
    idx_to_class = {int(v): str(k) for k, v in class_to_idx.items()}
    keys = [str(k).strip() for k in class_to_idx.keys() if str(k).strip()]
    numish = sum(1 for k in keys if k.isdigit())
    looks_like_gloss = (numish / float(max(1, len(keys)))) >= 0.95
    return idx_to_class, looks_like_gloss


def _gloss_zh(gloss: dict[str, tuple[str, str]], gid: int) -> str:
    sid = f"{int(gid):04d}"
    try:
        zh = (gloss.get(sid) or ("", ""))[0]
    except Exception:
        zh = ""
    return zh.strip()


def iter_video_frames(video_path: Path) -> Iterable[np.ndarray]:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise FileNotFoundError(f"无法打开视频: {video_path}")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            yield frame
    finally:
        cap.release()


def predict_tokens_from_video(
    *,
    video_path: Path,
    model: torch.nn.Module,
    tfm,
    device: torch.device,
    idx_to_class: dict[int, str],
    labels_are_gloss_ids: bool,
    gloss: dict[str, tuple[str, str]],
    infer_every: int,
    window: int,
    stride: int,
    vote_min_conf: float,
    min_gap_windows: int,
) -> List[str]:
    infer_every = max(1, int(infer_every))
    window = max(1, int(window))
    stride = max(1, int(stride))

    pred_ids: deque[int] = deque(maxlen=window)
    pred_confs: deque[float] = deque(maxlen=window)
    outputs: List[str] = []
    last_out: str | None = None
    gap_left = 0

    for i, frame_bgr in enumerate(iter_video_frames(video_path)):
        if i % infer_every != 0:
            continue
        img = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(img)
        x = tfm(pil).unsqueeze(0).to(device)
        with torch.no_grad():
            logits = model(x)
            probs = torch.softmax(logits.float(), dim=1)[0]
            conf = float(probs.max().item())
            pred = int(probs.argmax().item())

        pred_ids.append(pred)
        pred_confs.append(conf)

        if len(pred_ids) < window:
            continue
        if (i // infer_every) % stride != 0:
            continue

        # vote
        counts = Counter(pred_ids)
        best_id, best_cnt = counts.most_common(1)[0]
        # average confidence of frames voting for best_id
        confs_for_best = [c for pid, c in zip(list(pred_ids), list(pred_confs)) if pid == best_id]
        mean_conf = float(np.mean(confs_for_best)) if confs_for_best else 0.0
        if mean_conf < float(vote_min_conf):
            continue
        if gap_left > 0:
            gap_left -= 1
            continue

        cls_label = idx_to_class.get(int(best_id), str(int(best_id)))
        out_token = cls_label
        if labels_are_gloss_ids and str(cls_label).isdigit():
            out_token = _gloss_zh(gloss, int(cls_label)) or f"{int(cls_label):04d}"

        if out_token and out_token != last_out:
            outputs.append(out_token)
            last_out = out_token
            gap_left = int(min_gap_windows)

    return outputs


def _collect_inputs(p: Path) -> List[Path]:
    p = p.resolve()
    if p.is_file():
        return [p]
    if p.is_dir():
        vids = sorted([x for x in p.glob("*.mp4") if x.is_file()], key=lambda x: x.name.lower())
        if vids:
            return vids
    raise FileNotFoundError(f"未找到 mp4 输入: {p}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Continuous token recognition from mp4 (sliding-window vote + dedupe).")
    ap.add_argument("--input", type=str, required=True, help="mp4 文件路径，或包含 mp4 的目录（如 sentence_videos）")
    ap.add_argument("--checkpoint", type=str, default="", help="best_image_model.pt 路径；为空则自动取最新 outputs/image_extract")
    ap.add_argument("--train_log", type=str, default="", help="训练记录.json 路径；为空则随 checkpoint 自动选择")
    ap.add_argument("--outputs_dir", type=str, default="outputs/image_extract", help="自动找最新 run 的目录（相对脚本目录）")
    ap.add_argument("--gloss", type=str, default=r"..\gloss.csv", help="gloss.csv 路径（用于 id->中文）")
    ap.add_argument("--infer_every", type=int, default=2, help="每隔多少帧推理一次")
    ap.add_argument("--window", type=int, default=15, help="滑动窗口大小（多少次推理结果参与投票）")
    ap.add_argument("--stride", type=int, default=5, help="窗口步长（多少次推理触发一次投票输出）")
    ap.add_argument("--vote_min_conf", type=float, default=0.55, help="投票输出的最低平均置信度")
    ap.add_argument("--min_gap_windows", type=int, default=1, help="输出同一词后至少跳过多少个投票窗口（抑制重复）")
    ap.add_argument("--save_txt", type=str, default="", help="保存识别结果到 txt（相对脚本目录或绝对路径）")
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ckpt_p: Path | None = None
    log_p: Path | None = None
    if str(args.checkpoint).strip():
        ckpt_p = (base / args.checkpoint).resolve() if not Path(args.checkpoint).is_absolute() else Path(args.checkpoint).resolve()
        if str(args.train_log).strip():
            log_p = (base / args.train_log).resolve() if not Path(args.train_log).is_absolute() else Path(args.train_log).resolve()
        else:
            cand = ckpt_p.parent / "训练记录.json"
            log_p = cand if cand.is_file() else None
    else:
        outd = (base / args.outputs_dir).resolve()
        ckpt_p, log_p = pick_latest_image_extract_run(outd)
    if ckpt_p is None or not ckpt_p.is_file():
        raise FileNotFoundError("未找到 checkpoint。请用 --checkpoint 指定 best_image_model.pt")
    if log_p is None or (not log_p.is_file()):
        raise FileNotFoundError("未找到 训练记录.json。请用 --train_log 指定")

    arch, image_size, class_to_idx = load_image_training_log(log_p)
    idx_to_class, labels_are_gloss_ids = _idx_to_label_maps(class_to_idx)
    num_classes = len(class_to_idx) if isinstance(class_to_idx, dict) else None

    model = load_image_model(ckpt_p, device, arch=arch, num_classes=num_classes)
    image_size = int(image_size) if image_size is not None else 224
    tfm = transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )

    gloss_path = (base / args.gloss).resolve() if not Path(args.gloss).is_absolute() else Path(args.gloss).resolve()
    gloss = load_gloss_map(gloss_path) if gloss_path.is_file() else {}

    inputs = _collect_inputs(Path(args.input))
    all_tokens: List[str] = []
    for vp in inputs:
        tokens = predict_tokens_from_video(
            video_path=vp,
            model=model,
            tfm=tfm,
            device=device,
            idx_to_class=idx_to_class,
            labels_are_gloss_ids=labels_are_gloss_ids,
            gloss=gloss,
            infer_every=int(args.infer_every),
            window=int(args.window),
            stride=int(args.stride),
            vote_min_conf=float(args.vote_min_conf),
            min_gap_windows=int(args.min_gap_windows),
        )
        print(f"[{vp.name}] " + (" ".join(tokens) if tokens else "（无输出）"))
        if tokens:
            all_tokens.extend(tokens)

    if all_tokens:
        print("\n=== combined ===")
        print(" ".join(all_tokens))

    if str(args.save_txt).strip():
        outp = Path(args.save_txt)
        outp = outp.resolve() if outp.is_absolute() else (base / outp).resolve()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(" ".join(all_tokens) + "\n", encoding="utf-8")
        print(f"\nSaved: {outp}")


if __name__ == "__main__":
    # Workaround for Windows conda OpenMP duplication crash.
    if sys.platform.startswith("win"):
        os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    main()

