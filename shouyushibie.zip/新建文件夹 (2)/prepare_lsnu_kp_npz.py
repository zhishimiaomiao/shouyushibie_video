from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

from glossary import iter_gloss_rows


def build_zh_to_id(gloss_csv: Path) -> Dict[str, int]:
    zh_to_id: Dict[str, int] = {}
    for e in iter_gloss_rows(gloss_csv):
        z = str(e.zh).strip()
        if not z:
            continue
        # If duplicates exist, keep the first (stable).
        zh_to_id.setdefault(z, int(e.id_int))
    return zh_to_id


def infer_word_from_npy_name(npy_path: Path) -> str:
    """
    LSNU-SCL_kp filename examples:
      - 办法.MTS.npy
      - 包包.MTS.npy
      - 伪装.MP4.npy
    We treat the part before the first dot as the word label.
    """
    name = npy_path.name
    first = name.split(".", 1)[0]
    return first.strip()


def iter_npy_files(root: Path) -> List[Path]:
    out: List[Path] = []
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.lower().endswith(".npy"):
                out.append(Path(dirpath) / fn)
    out.sort(key=lambda p: str(p))
    return out


def load_pose_npy(path: Path) -> np.ndarray:
    arr = np.load(path, allow_pickle=True)
    if not isinstance(arr, np.ndarray):
        raise ValueError(f"Unsupported npy content: {path}")
    if arr.ndim != 3:
        raise ValueError(f"Expected pose array with shape [T, J, C], got {arr.shape} in {path}")
    # Flatten joints+coords -> [T, D]
    return arr.astype(np.float32).reshape(arr.shape[0], -1)


def main() -> None:
    ap = argparse.ArgumentParser(description="Convert LSNU-SCL_kp (*.npy) into pose_features.npz (+ dummy rgb_features.npz)")
    ap.add_argument("--kp_root", type=str, required=True, help="LSNU-SCL_kp root (contains participant folders like CSY/..)")
    ap.add_argument("--gloss_csv", type=str, default=r"..\gloss.csv", help="Path to gloss.csv (for zh->GlossID mapping)")
    ap.add_argument("--out_pose_npz", type=str, default="outputs/pose_features_lsnu_kp.npz")
    ap.add_argument("--out_rgb_npz", type=str, default="outputs/rgb_features_zeros_lsnu_kp.npz")
    ap.add_argument("--rgb_dim", type=int, default=768, help="Dummy RGB feature dimension (for fusion trainer compatibility)")
    ap.add_argument("--min_frames", type=int, default=4, help="Skip samples shorter than this")
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    kp_root = (base / args.kp_root).resolve() if not Path(args.kp_root).is_absolute() else Path(args.kp_root).resolve()
    gloss_csv = (base / args.gloss_csv).resolve() if not Path(args.gloss_csv).is_absolute() else Path(args.gloss_csv).resolve()
    out_pose = (base / args.out_pose_npz).resolve()
    out_rgb = (base / args.out_rgb_npz).resolve()

    if not kp_root.is_dir():
        raise FileNotFoundError(f"kp_root not found: {kp_root}")
    if not gloss_csv.is_file():
        raise FileNotFoundError(f"gloss_csv not found: {gloss_csv}")

    zh_to_id = build_zh_to_id(gloss_csv)
    npy_files = iter_npy_files(kp_root)
    if not npy_files:
        raise FileNotFoundError(f"No *.npy found under: {kp_root}")

    keys: List[str] = []
    pose_list: List[np.ndarray] = []
    skipped_no_gloss: List[str] = []
    skipped_bad_shape: List[str] = []
    skipped_short: int = 0

    for p in npy_files:
        word = infer_word_from_npy_name(p)
        gid = zh_to_id.get(word)
        if gid is None:
            skipped_no_gloss.append(word)
            continue
        try:
            pose = load_pose_npy(p)  # [T, D]
        except Exception:
            skipped_bad_shape.append(str(p))
            continue
        if pose.shape[0] < int(args.min_frames):
            skipped_short += 1
            continue
        # Key must contain gloss id digits so dataset.parse_label_from_name can parse it.
        key = f"{int(gid):04d}_{word}.npy"
        keys.append(key)
        pose_list.append(pose)

    if not keys:
        raise RuntimeError(
            "No usable samples produced. "
            "Check kp_root encoding and whether gloss.csv contains matching Chinese words."
        )

    max_t = max(x.shape[0] for x in pose_list)
    feat_dim = int(pose_list[0].shape[1])
    pose_padded = np.zeros((len(pose_list), int(max_t), int(feat_dim)), dtype=np.float32)
    for i, x in enumerate(pose_list):
        pose_padded[i, : x.shape[0], :] = x

    rgb = np.zeros((len(keys), int(args.rgb_dim)), dtype=np.float32)
    out_pose.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_pose, keys=np.asarray(keys, dtype=object), pose=pose_padded)
    np.savez_compressed(out_rgb, keys=np.asarray(keys, dtype=object), rgb=rgb)

    uniq_missing = sorted(set(skipped_no_gloss))
    print(f"Saved pose npz: {out_pose} | samples={len(keys)} | max_t={max_t} | pose_dim={feat_dim}")
    print(f"Saved rgb  npz: {out_rgb} | samples={len(keys)} | rgb_dim={int(args.rgb_dim)} (all zeros)")
    if uniq_missing:
        print(f"WARN: {len(uniq_missing)} unique words not found in gloss.csv (first 30): {uniq_missing[:30]}")
    if skipped_bad_shape:
        print(f"WARN: {len(skipped_bad_shape)} files failed to load/shape mismatch (first 5): {skipped_bad_shape[:5]}")
    if skipped_short:
        print(f"WARN: skipped short sequences (<{int(args.min_frames)} frames): {skipped_short}")


if __name__ == "__main__":
    main()

