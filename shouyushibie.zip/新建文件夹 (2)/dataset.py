from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from glossary import parse_gloss_id_strict


@dataclass
class Sample:
    feature: np.ndarray
    label: int


@dataclass
class DualSample:
    rgb: np.ndarray
    pose: np.ndarray
    label: int


@dataclass
class CSLRSample:
    sequence: np.ndarray
    target: List[int]


def load_gloss_map(gloss_csv: Path):
    """兼容旧接口：返回 {'id': 四位字符串, 'zh', 'en'} 列表。"""
    from glossary import load_gloss_entries

    return [{"id": e.id_str, "zh": e.zh, "en": e.en} for e in load_gloss_entries(gloss_csv)]


def parse_label_from_name(name: str) -> int:
    """从样本文件名解析 Gloss ID（与 glossary.parse_gloss_id_strict 一致）。"""
    return parse_gloss_id_strict(name)


def load_lsnu_feature_samples(feature_dir: Path) -> List[Sample]:
    csv_files = sorted(feature_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No feature csv files found in: {feature_dir}")

    all_samples: List[Sample] = []
    for csv_file in csv_files:
        values = np.loadtxt(csv_file, delimiter=",", dtype=np.float32)
        if values.ndim == 1:
            values = values.reshape(1, -1)
        if values.shape[1] < 768:
            raise ValueError(f"{csv_file} has invalid shape: {values.shape}")

        # Each row index is a sign class id in LSNU-SCL.
        for class_id in range(values.shape[0]):
            all_samples.append(Sample(feature=values[class_id, :768], label=class_id))
    return all_samples


def load_json_feature_map(path: Path) -> Dict[str, np.ndarray]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    out = {}
    for k, v in raw.items():
        out[k] = np.asarray(v, dtype=np.float32)
    return out


def load_rgb_feature_map(path: Path) -> Dict[str, np.ndarray]:
    """
    RGB / 3D-CNN vectors from JSON or compressed NPZ (preferred for large CSV fallbacks).

    NPZ format: keys=object array of str, rgb=float32 array [N, D]
    """
    path = Path(path)
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=True)
        keys = z["keys"]
        rgb = z["rgb"]
        out: Dict[str, np.ndarray] = {}
        for i, k in enumerate(keys):
            out[str(k)] = np.asarray(rgb[i], dtype=np.float32).reshape(-1)
        return out
    return load_json_feature_map(path)


def load_pose_feature_map(path: Path) -> Dict[str, np.ndarray]:
    """
    Load pose features from JSON or from compressed NPZ (preferred for large fallbacks).

    NPZ format: keys=object array of str, pose=float32 array [N, T, D]
    """
    path = Path(path)
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=True)
        keys = z["keys"]
        pose = z["pose"]
        out: Dict[str, np.ndarray] = {}
        for i, k in enumerate(keys):
            out[str(k)] = np.asarray(pose[i], dtype=np.float32)
        return out
    return load_json_feature_map(path)


def load_dual_stream_samples(rgb_json: Path, pose_json: Path) -> List[DualSample]:
    rgb_map = load_rgb_feature_map(rgb_json)
    pose_map = load_pose_feature_map(pose_json)
    shared = sorted(set(rgb_map.keys()) & set(pose_map.keys()))
    if not shared:
        raise ValueError("No shared samples between RGB and pose feature files.")

    samples: List[DualSample] = []
    for name in shared:
        label = parse_label_from_name(name)
        rgb = rgb_map[name]
        pose = pose_map[name]
        if rgb.ndim != 1:
            rgb = rgb.reshape(-1)
        if pose.ndim == 1:
            pose = pose[None, :]
        samples.append(DualSample(rgb=rgb, pose=pose, label=label))
    return samples


def load_cslr_manifest(manifest_path: Path) -> List[Tuple[str, List[int]]]:
    rows = []
    with open(manifest_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            sample_id = row["sample_id"].strip()
            target_tokens = [int(x) for x in row["target_ids"].strip().split()]
            rows.append((sample_id, target_tokens))
    return rows


def load_cslr_samples(sequence_json: Path, manifest_csv: Path) -> List[CSLRSample]:
    seq_map = load_json_feature_map(sequence_json)
    manifest = load_cslr_manifest(manifest_csv)
    samples: List[CSLRSample] = []
    for sample_id, target in manifest:
        if sample_id not in seq_map:
            continue
        seq = seq_map[sample_id]
        if seq.ndim == 1:
            seq = seq[None, :]
        samples.append(CSLRSample(sequence=seq, target=target))
    if not samples:
        raise ValueError("No CSLR samples loaded, check manifest and sequence feature ids.")
    return samples


class SignFeatureDataset(Dataset):
    def __init__(self, samples: List[Sample], indices: np.ndarray):
        self.samples = samples
        self.indices = indices.astype(np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        sample = self.samples[self.indices[idx]]
        feature = torch.from_numpy(sample.feature)  # [768]
        label = torch.tensor(sample.label, dtype=torch.long)
        return feature, label


class DualStreamDataset(Dataset):
    def __init__(self, samples: List[DualSample], indices: np.ndarray):
        self.samples = samples
        self.indices = indices.astype(np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        sample = self.samples[self.indices[idx]]
        rgb = torch.from_numpy(sample.rgb).float()
        pose = torch.from_numpy(sample.pose).float()
        label = torch.tensor(sample.label, dtype=torch.long)
        return rgb, pose, label


class CSLRSequenceDataset(Dataset):
    def __init__(self, samples: List[CSLRSample], indices: np.ndarray):
        self.samples = samples
        self.indices = indices.astype(np.int64)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        sample = self.samples[self.indices[idx]]
        x = torch.from_numpy(sample.sequence).float()  # [T, D]
        y = torch.tensor(sample.target, dtype=torch.long)
        return x, y


def cslr_collate_fn(batch):
    xs, ys = zip(*batch)
    input_lengths = torch.tensor([x.shape[0] for x in xs], dtype=torch.long)
    target_lengths = torch.tensor([y.shape[0] for y in ys], dtype=torch.long)
    feat_dim = xs[0].shape[1]
    max_t = int(max(input_lengths).item())

    padded = torch.zeros(len(xs), max_t, feat_dim, dtype=torch.float32)
    for i, x in enumerate(xs):
        padded[i, : x.shape[0]] = x

    targets = torch.cat(ys, dim=0)
    return padded, targets, input_lengths, target_lengths, ys
