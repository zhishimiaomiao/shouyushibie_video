"""
将 outputs/**/run_* 下旧版 run_meta + history（+ 可选 metrics）合并为「训练记录.json」并删除重复文件。

用法（在 sign_language_system 目录）::

    python consolidate_runs.py
    python consolidate_runs.py --outputs_dir outputs
"""

from __future__ import annotations

import argparse
from pathlib import Path

from training_io import consolidate_outputs_tree


def main() -> None:
    parser = argparse.ArgumentParser(description="Merge legacy run_meta/history/metrics into 训练记录.json")
    parser.add_argument("--outputs_dir", type=str, default="outputs", help="相对本脚本目录")
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    root = (base / args.outputs_dir).resolve()
    n = consolidate_outputs_tree(root)
    print(f"Merged {n} run director(y/ies) under {root}")


if __name__ == "__main__":
    main()
