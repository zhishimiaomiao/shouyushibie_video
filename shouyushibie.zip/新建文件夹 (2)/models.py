from __future__ import annotations

import os
import sys

# Workaround for Windows conda OpenMP duplication crash:
# "OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll already initialized."
# Prefer fixing the environment (single OpenMP runtime), but this keeps scripts runnable.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import torch
from torch import nn


class TemporalConvNet(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(input_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, D]
        x = x.transpose(1, 2)  # [B, D, T]
        x = self.net(x)
        x = x.transpose(1, 2)  # [B, T, D]
        return x.mean(dim=1)


class SignRecognizer(nn.Module):
    """
    Core recognizer with pluggable temporal modeling:
    - bilstm
    - transformer
    - tcn
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        num_classes: int,
        temporal_type: str = "bilstm",
        num_layers: int = 2,
        nhead: int = 8,
        dropout: float = 0.2,
    ):
        super().__init__()
        self.temporal_type = temporal_type.lower()
        self.in_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        if self.temporal_type == "bilstm":
            self.temporal = nn.LSTM(
                input_size=hidden_dim,
                hidden_size=hidden_dim // 2,
                num_layers=num_layers,
                dropout=dropout if num_layers > 1 else 0.0,
                bidirectional=True,
                batch_first=True,
            )
        elif self.temporal_type == "transformer":
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=hidden_dim,
                nhead=nhead,
                dim_feedforward=hidden_dim * 4,
                dropout=dropout,
                batch_first=True,
                activation="gelu",
            )
            self.temporal = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        elif self.temporal_type == "tcn":
            self.temporal = TemporalConvNet(hidden_dim, hidden_dim)
        else:
            raise ValueError(f"Unsupported temporal type: {temporal_type}")

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x from current dataset: [B, D]
        x = self.in_proj(x)
        x = x.unsqueeze(1)  # [B, T=1, H]

        if self.temporal_type == "bilstm":
            x, _ = self.temporal(x)
            x = x.mean(dim=1)
        elif self.temporal_type == "transformer":
            x = self.temporal(x).mean(dim=1)
        else:
            x = self.temporal(x)

        return self.classifier(x)


class PoseTemporalEncoder(nn.Module):
    def __init__(self, pose_dim: int, hidden_dim: int, num_layers: int = 2, dropout: float = 0.2):
        super().__init__()
        self.pose_proj = nn.Sequential(
            nn.Linear(pose_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.temporal = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim // 2,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=True,
            batch_first=True,
        )

    def forward(self, pose_seq: torch.Tensor) -> torch.Tensor:
        x = self.pose_proj(pose_seq)
        x, _ = self.temporal(x)
        return x.mean(dim=1)


class DualStreamFusionRecognizer(nn.Module):
    """
    3D-CNN RGB stream + MediaPipe pose stream fusion classifier.
    """

    def __init__(
        self,
        rgb_dim: int,
        pose_dim: int,
        hidden_dim: int,
        num_classes: int,
        dropout: float = 0.2,
    ):
        super().__init__()
        self.rgb_proj = nn.Sequential(
            nn.Linear(rgb_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.pose_encoder = PoseTemporalEncoder(pose_dim=pose_dim, hidden_dim=hidden_dim, dropout=dropout)
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, rgb_feat: torch.Tensor, pose_seq: torch.Tensor) -> torch.Tensor:
        rgb_repr = self.rgb_proj(rgb_feat)
        pose_repr = self.pose_encoder(pose_seq)
        fused = torch.cat([rgb_repr, pose_repr], dim=1)
        return self.fusion(fused)


class CSLRCTCRecognizer(nn.Module):
    """
    Continuous sign recognition with CTC loss.
    Input: sequence features [B, T, D]
    Output: log_probs [B, T, vocab_size]
    """

    def __init__(self, input_dim: int, hidden_dim: int, vocab_size: int, num_layers: int = 2, dropout: float = 0.2):
        super().__init__()
        self.in_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.encoder = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim // 2,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=True,
            batch_first=True,
        )
        self.out = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.in_proj(x)
        x, _ = self.encoder(x)
        logits = self.out(x)
        return torch.log_softmax(logits, dim=-1)
