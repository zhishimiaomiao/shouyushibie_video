from __future__ import annotations

from typing import Iterable, List


def levenshtein_distance(ref: List[int], hyp: List[int]) -> int:
    n, m = len(ref), len(hyp)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        dp[i][0] = i
    for j in range(m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = 0 if ref[i - 1] == hyp[j - 1] else 1
            dp[i][j] = min(
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + cost,
            )
    return dp[n][m]


def wer(refs: Iterable[List[int]], hyps: Iterable[List[int]]) -> float:
    total_dist = 0
    total_words = 0
    for ref, hyp in zip(refs, hyps):
        total_dist += levenshtein_distance(ref, hyp)
        total_words += len(ref)
    return total_dist / max(1, total_words)


def ctc_greedy_decode(token_ids: List[int], blank_id: int) -> List[int]:
    out = []
    prev = blank_id
    for t in token_ids:
        if t != blank_id and t != prev:
            out.append(t)
        prev = t
    return out
