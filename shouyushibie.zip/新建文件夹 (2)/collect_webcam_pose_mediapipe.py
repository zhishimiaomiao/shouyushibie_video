from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np

from glossary import iter_gloss_rows


# Workaround for Windows conda OpenMP duplication crash.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")


def frame_to_hands126(frame_bgr, holistic) -> np.ndarray:
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    result = holistic.process(rgb)
    keypoints = []
    for hand in (result.left_hand_landmarks, result.right_hand_landmarks):
        if hand is None:
            keypoints.extend([0.0] * (21 * 3))
        else:
            for lm in hand.landmark:
                keypoints.extend([lm.x, lm.y, lm.z])
    return np.asarray(keypoints, dtype=np.float32)


def main() -> None:
    ap = argparse.ArgumentParser(description="Collect MediaPipe hands126 pose sequence from webcam into pose_features.json")
    ap.add_argument("--gloss_id", type=int, default=None, help="词汇 GlossID（例如 4729 表示 办法）")
    ap.add_argument("--word", type=str, default=None, help="中文词（例如 办法）。若提供则从 gloss_csv 中查 gloss_id。")
    ap.add_argument("--gloss_csv", type=str, default=r"..\gloss.csv", help="用于 --word 查找 GlossID")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--seconds", type=float, default=3.0, help="采集时长（秒）")
    ap.add_argument("--fps", type=float, default=20.0, help="目标采样帧率（尽量接近）")
    ap.add_argument("--max_frames", type=int, default=64, help="最多保存多少帧（超出则截断）")
    ap.add_argument("--output", type=str, default="outputs/pose_features_webcam.json")
    ap.add_argument("--tag", type=str, default="", help="可选：样本标签（如 P01_front_01），用于生成不同 key")
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    gloss_csv = (base / args.gloss_csv).resolve() if args.gloss_csv else None
    out_path = (base / args.output).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    gid = args.gloss_id
    if gid is None:
        w = str(args.word or "").strip()
        if not w:
            raise SystemExit("必须提供 --gloss_id 或 --word。")
        if gloss_csv is None or not gloss_csv.is_file():
            raise SystemExit(f"--word 需要有效的 --gloss_csv，当前不存在: {gloss_csv}")
        zh_to_id = {}
        for e in iter_gloss_rows(gloss_csv):
            z = str(e.zh).strip()
            if z and z not in zh_to_id:
                zh_to_id[z] = int(e.id_int)
        if w not in zh_to_id:
            raise SystemExit(f"未在 gloss.csv 找到中文词: {w!r}")
        gid = int(zh_to_id[w])
    else:
        gid = int(gid)

    import mediapipe as mp

    holistic = mp.solutions.holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    cap = cv2.VideoCapture(int(args.camera))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera: {int(args.camera)}")

    try:
        # Load existing json map if present.
        data = {}
        if out_path.is_file():
            try:
                data = json.loads(out_path.read_text(encoding="utf-8"))
            except Exception:
                data = {}

        tag = str(args.tag).strip()
        stamp = time.strftime("%Y%m%d_%H%M%S")
        key = f"{gid:04d}_{tag+'_' if tag else ''}{stamp}.mp4"

        seq = []
        t_end = time.time() + float(args.seconds)
        period = 1.0 / max(1.0, float(args.fps))
        next_t = time.time()

        print(f"Collecting... key={key} seconds={float(args.seconds):.2f} max_frames={int(args.max_frames)}")
        while time.time() < t_end and len(seq) < int(args.max_frames):
            ok, frame = cap.read()
            if not ok:
                break
            # UI
            cv2.putText(
                frame,
                f"REC {len(seq)}/{int(args.max_frames)}  gid={gid:04d}",
                (12, 32),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.imshow("collect_webcam_pose_mediapipe (ESC to stop)", frame)
            if (cv2.waitKey(1) & 0xFF) == 27:
                break

            kp = frame_to_hands126(frame, holistic)
            seq.append(kp.tolist())

            # crude FPS control
            now = time.time()
            if now < next_t:
                time.sleep(max(0.0, next_t - now))
            next_t += period

        if not seq:
            raise RuntimeError("No frames collected.")

        data[key] = seq
        out_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        print(f"Saved: {out_path} | total_keys={len(data)} | this_seq_len={len(seq)}")
        print("Next:")
        print(f"  python train_fusion.py --pose_only --pose_json {out_path.as_posix()} --export_camera_best --cpu")
    finally:
        try:
            holistic.close()
        except Exception:
            pass
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

