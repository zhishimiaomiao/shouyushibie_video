"""
启动 camera_interface.py。

本脚本仅面向 extract.py 中 DEFAULT_SENTENCES（约第 22–32 行十句）所出现的 gloss 数据集：
训练与特征过滤始终带 --restrict_gloss_ids；界面词表从 --gloss_source 读入完整 gloss.csv 后
**裁剪** 为十句子集，写入 outputs/gloss_extract_default_sentences.csv 再交给 camera，不加载全量词表行。

- image：train_image 图像分类（默认，适用于「图片识别」流水线）
- fusion：train_fusion 骨骼双流（摄像头端 MediaPipe hands126）

骨骼序列记忆（与图像 CNN 并行，非替代）：
  - extract / calling_program / 本脚本可加 --export_skeleton_corpus：对 front/<id>/ 逐帧记录双手 126 维 + 肩肘腕 18 维，
    写入 extract_root/skeleton_corpus/（frames.jsonl + skeleton_match_index.npz），并与 gloss 中文对齐。
  - 摄像头侧用实时 144 维缓冲与模板做序列比对（camera_interface --skeleton_match_index）；默认若存在上述 npz 则自动启用。
  - 可选 --train_skeleton_mlp：在已有 frames.jsonl 上训练帧级骨骼 MLP（train_skeleton_sequence.py），与模板匹配并行，权重写在 outputs/skeleton_mlp/。

默认摄像头；--video 为离线验证。其余见 camera_interface。

准确率相关默认：train_first 时默认 EfficientNet-B0 + ImageNet 预训练 + 类别 balanced + 标签平滑；
实时推理加大平滑窗口与连续确认帧，但仍依赖训练质量——置信度长期偏低时请重新训练（不要用旧 checkpoint）。
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

# 与 369.py 一致：避免 Windows 下 conda OpenMP 重复库崩溃
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")


def _ten_sentence_gloss_id_csv() -> str:
    """与 extract.DEFAULT_SENTENCES 中 [id] 去重后顺序一致，供 --restrict_gloss_ids。"""
    _here = Path(__file__).resolve().parent
    if str(_here) not in sys.path:
        sys.path.insert(0, str(_here))
    from extract import DEFAULT_SENTENCES, parse_ids_from_sentences

    return ",".join(parse_ids_from_sentences(DEFAULT_SENTENCES))


def pick_latest_image_run(outputs_dir: Path) -> tuple[Path | None, Path | None]:
    if not outputs_dir.is_dir():
        return None, None
    runs = sorted(outputs_dir.glob("run_*"), key=lambda p: p.name, reverse=True)
    for r in runs:
        if not r.is_dir():
            continue
        log_p = r / "训练记录.json"
        if not log_p.is_file():
            continue
        for ckpt_name in ("best_image_model.pt", "checkpoint_last.pt"):
            ckpt_p = r / ckpt_name
            if ckpt_p.is_file():
                return ckpt_p, log_p
    return None, None


def pick_latest_skeleton_mlp(outputs_skeleton_dir: Path) -> Path | None:
    """最新修改的 outputs/skeleton_mlp/run_*/best_skeleton_frame_mlp.pt。"""
    if not outputs_skeleton_dir.is_dir():
        return None
    cands = list(outputs_skeleton_dir.glob("run_*/best_skeleton_frame_mlp.pt"))
    if not cands:
        return None
    return max(cands, key=lambda p: p.stat().st_mtime)


def pick_latest_fusion_run(fusion_dir: Path) -> tuple[Path | None, Path | None]:
    """优先 run_* 下 best_fusion_model.pt；否则 outputs/fusion/best_fusion_model.pt。"""
    if not fusion_dir.is_dir():
        return None, None
    runs = sorted(fusion_dir.glob("run_*"), key=lambda p: p.name, reverse=True)
    for r in runs:
        if not r.is_dir():
            continue
        ckpt_p = r / "best_fusion_model.pt"
        if not ckpt_p.is_file():
            continue
        log_p = r / "训练记录.json"
        return ckpt_p, log_p if log_p.is_file() else None
    root_best = fusion_dir / "best_fusion_model.pt"
    if root_best.is_file():
        return root_best, None
    return None, None


def main() -> None:
    ap = argparse.ArgumentParser(
        description="仅使用 extract.DEFAULT_SENTENCES（十句）词表；train_image / train_fusion 均强制 restrict_gloss_ids。"
    )
    ap.add_argument(
        "--recognizer",
        type=str,
        default="image",
        choices=["image", "fusion"],
        help="image=train_image 图像分类（默认）；fusion=train_fusion 骨骼双流。",
    )
    ap.add_argument(
        "--outputs_dir",
        type=str,
        default="outputs/image_extract",
        help="train_image 写入目录（image 模式加载其中最新 run）",
    )
    ap.add_argument(
        "--fusion_output_dir",
        type=str,
        default="outputs/fusion",
        help="train_fusion 输出根目录（fusion 模式加载其中最新 best_fusion_model.pt）",
    )
    ap.add_argument("--extract_root", type=str, default="extract_dataset", help="extract.py 输出根目录（其下应有 front/<四位id>/）")
    ap.add_argument("--train_first", action="store_true", help="先训练再启动界面")
    ap.add_argument("--epochs", type=int, default=35, help="train_image 默认加长，便于小类别集收敛")
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--arch", type=str, default="efficientnet_b0", choices=["resnet18", "resnet50", "efficientnet_b0"])
    _pt = ap.add_mutually_exclusive_group()
    _pt.add_argument(
        "--pretrained",
        dest="pretrained",
        action="store_true",
        help="train_image：使用 ImageNet 预训练（默认开；样本少时显著提准确率）",
    )
    _pt.add_argument("--no-pretrained", dest="pretrained", action="store_false", help="train_image：随机初始化权重")
    ap.set_defaults(pretrained=True)
    ap.add_argument(
        "--class_weight",
        type=str,
        default="balanced",
        choices=["none", "balanced"],
        help="train_image：类别频次不均衡时用 balanced（默认）",
    )
    ap.add_argument(
        "--label_smoothing",
        type=float,
        default=0.05,
        help="train_image：标签平滑，减轻过拟合（默认 0.05）",
    )
    ap.add_argument(
        "--augment_level",
        type=str,
        default="strong",
        choices=["none", "light", "strong"],
        help="train_image 增强强度",
    )
    ap.add_argument("--amp", action="store_true", help="train_image：CUDA AMP")
    ap.add_argument(
        "--fusion_dual_stream",
        action="store_true",
        help="train_fusion：同时使用 rgb_json 与 pose_json。省略则默认 --pose_only（只需 pose 特征即可训练骨骼分类）",
    )
    ap.add_argument("--rgb_json", type=str, default="outputs/video_3dcnn_features.npz", help="train_fusion：RGB/3dcnn 特征")
    ap.add_argument("--pose_json", type=str, default="outputs/pose_features.npz", help="train_fusion：MediaPipe pose 特征")
    ap.add_argument(
        "--gloss_source",
        type=str,
        default=r"..\gloss.csv",
        help="完整项目 gloss.csv（仅作源文件）；运行时会裁剪为 extract.DEFAULT_SENTENCES 子表再交给界面，不加载全词表",
    )
    ap.add_argument(
        "--gloss",
        type=str,
        default=None,
        help="已弃用：请用 --gloss_source。若仍传入则等同于 --gloss_source（兼容旧命令行）",
    )
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument(
        "--video",
        type=str,
        default="",
        help="可选：视频文件/目录离线验证。默认空=摄像头。",
    )
    ap.add_argument("--max_videos", type=int, default=0, help="--video 为目录时最多 N 个 mp4（0=全部）")
    ap.add_argument(
        "--playback_speed",
        type=float,
        default=None,
        help="视频模式播放倍率；省略时：有 --video 默认 0.5，摄像头默认 1.0",
    )
    ap.add_argument("--infer_every", type=int, default=1, help="每隔多少帧做一次图像推理；默认 1 以增加平滑窗口采样")
    ap.add_argument(
        "--smooth_k",
        type=int,
        default=13,
        help="多数投票窗口（增大可减少抖动；默认 13）",
    )
    ap.add_argument(
        "--commit_conf",
        type=float,
        default=0.40,
        help="提交词条最低置信度；略低于易误报线，若长期低于此值请重训或加 --pretrained / 加数据",
    )
    ap.add_argument(
        "--commit_hold",
        type=int,
        default=2,
        help="同一平滑标签连续多少次才允许提交（默认 2，更稳）",
    )
    ap.add_argument("--repeat_gap_frames", type=int, default=30)
    ap.add_argument("--motion_threshold", type=float, default=0.010)
    ap.add_argument("--warmup_seconds", type=float, default=5.0)
    _kp = ap.add_mutually_exclusive_group()
    _kp.add_argument("--draw_kp", dest="draw_kp", action="store_true", help="叠加 MediaPipe 关键点（默认开启）")
    _kp.add_argument("--no-draw_kp", dest="draw_kp", action="store_false", help="关闭关键点叠加")
    ap.set_defaults(draw_kp=True)
    _pose = ap.add_mutually_exclusive_group()
    _pose.add_argument(
        "--draw_pose",
        dest="draw_pose",
        action="store_true",
        help="绘制 MediaPipe Pose：肩-肘-腕与躯干连线（参考示例图；默认开启，需 kp_source=holistic）",
    )
    _pose.add_argument(
        "--no-draw_pose",
        dest="draw_pose",
        action="store_false",
        help="仅绘制手掌与手指，不画手臂/躯干",
    )
    ap.set_defaults(draw_pose=True)
    _fb = ap.add_mutually_exclusive_group()
    _fb.add_argument(
        "--draw_face_box",
        dest="draw_face_box",
        action="store_true",
        help="绘制人脸矩形框（默认关闭；手语识别以手为主体，面部框易干扰）",
    )
    _fb.add_argument("--no-draw_face_box", dest="draw_face_box", action="store_false", help="不画人脸框（默认）")
    ap.set_defaults(draw_face_box=False)
    _hroi = ap.add_mutually_exclusive_group()
    _hroi.add_argument(
        "--draw_hand_roi",
        dest="draw_hand_roi",
        action="store_true",
        help="双手关键点外包黄色 ROI，标签 hand(L)/hand(R)（默认开启）",
    )
    _hroi.add_argument("--no-draw_hand_roi", dest="draw_hand_roi", action="store_false", help="不画手部黄色框")
    ap.set_defaults(draw_hand_roi=True)
    _aroi = ap.add_mutually_exclusive_group()
    _aroi.add_argument(
        "--draw_arm_roi",
        dest="draw_arm_roi",
        action="store_true",
        help="Pose 肩/肘/腕外包红色 ROI（肘与小臂；默认开；需 kp_source=holistic）",
    )
    _aroi.add_argument("--no-draw_arm_roi", dest="draw_arm_roi", action="store_false", help="不画红色手臂 ROI")
    ap.set_defaults(draw_arm_roi=True)
    ap.add_argument(
        "--kp_source",
        type=str,
        default="holistic",
        choices=["hands", "holistic"],
        help="可视化关键点来源：holistic 才显示肩臂躯干（默认）；hands 仅手掌手指且无法画手臂",
    )
    ap.add_argument("--hands_min_det", type=float, default=0.6)
    ap.add_argument("--hands_min_track", type=float, default=0.6)
    ap.add_argument("--kp_smooth_alpha", type=float, default=0.7)
    ap.add_argument("--enable_sentence_model", action="store_true", help="启用整句翻译器（默认关）")
    ap.add_argument(
        "--export_skeleton_corpus",
        action="store_true",
        help="从 extract_root/front 导出骨骼语料（仅限十句 gloss），写入 skeleton_corpus/；可在 train_first 之前执行",
    )
    ap.add_argument(
        "--skeleton_only",
        action="store_true",
        help="仅导出骨骼语料后退出（不训练、不打开摄像头）",
    )
    ap.add_argument(
        "--skeleton_out_subdir",
        type=str,
        default="skeleton_corpus",
        help="骨骼输出子目录（位于 extract_root 下）",
    )
    ap.add_argument(
        "--skeleton_match_index",
        type=str,
        default="",
        help="传给 camera_interface；默认可留空：若 extract_root/skeleton_corpus/skeleton_match_index.npz 存在则自动使用",
    )
    ap.add_argument(
        "--skeleton_match_threshold",
        type=float,
        default=2.4,
        help="骨骼序列匹配上限距离（默认对应 metric=hands_l2）",
    )
    ap.add_argument(
        "--skeleton_match_metric",
        type=str,
        default="hands_l2",
        choices=["hands_l2", "full_l2", "cosine_flat"],
        help="hands_l2 仅双手126维（推荐）；full_l2 全144维；cosine_flat 余弦距离（阈值需改小，如约0.35）",
    )
    ap.add_argument("--skeleton_buffer", type=int, default=48)
    ap.add_argument("--skeleton_min_frames", type=int, default=8)
    ap.add_argument("--skeleton_match_len", type=int, default=16)
    ap.add_argument(
        "--train_skeleton_mlp",
        action="store_true",
        help="在启动摄像头前训练骨骼帧级 MLP（train_skeleton_sequence.py，需已有 skeleton_corpus/frames.jsonl）",
    )
    ap.add_argument(
        "--skeleton_mlp_out",
        type=str,
        default="outputs/skeleton_mlp",
        help="--train_skeleton_mlp 时输出目录（相对本脚本目录）",
    )
    ap.add_argument(
        "--skeleton_mlp_checkpoint",
        type=str,
        default="",
        help="camera_interface 骨骼MLP权重；默认可空，自动使用 outputs/skeleton_mlp/run_*/best_skeleton_frame_mlp.pt 最新文件",
    )
    ap.add_argument(
        "--no_skeleton_mlp",
        action="store_true",
        help="禁用骨骼MLP推理（即使已训练）",
    )
    args = ap.parse_args()
    if getattr(args, "gloss", None):
        # backward compat: `butting_connectro.py --gloss path` used to mean full csv
        args.gloss_source = str(args.gloss)

    # Hands 模式只有手部骨架；肩臂骨架 / 红色手臂 ROI 需要 Holistic + Pose。
    if (
        str(args.kp_source).strip().lower() == "hands"
        and (bool(args.draw_pose) or bool(getattr(args, "draw_arm_roi", True)))
    ):
        print("[butting_connectro] draw_pose / draw_arm_roi 需要 Pose，已将 kp_source 改为 holistic。")
        args.kp_source = "holistic"

    if args.playback_speed is None:
        args.playback_speed = 0.5 if str(args.video).strip() else 1.0

    base = Path(__file__).resolve().parent
    if str(base) not in sys.path:
        sys.path.insert(0, str(base))
    from extract import DEFAULT_SENTENCES, parse_ids_from_sentences, write_gloss_csv_subset_for_default_sentences

    gloss_src = Path(args.gloss_source)
    gloss_src = gloss_src.resolve() if gloss_src.is_absolute() else (base / gloss_src).resolve()
    if not gloss_src.is_file():
        raise FileNotFoundError(f"--gloss_source 未找到: {gloss_src}")
    gloss_subset_path = (base / "outputs" / "gloss_extract_default_sentences.csv").resolve()
    n_gloss_rows = write_gloss_csv_subset_for_default_sentences(gloss_src, gloss_subset_path)

    outputs_image = (base / args.outputs_dir).resolve() if not Path(args.outputs_dir).is_absolute() else Path(args.outputs_dir).resolve()
    fusion_out = (base / args.fusion_output_dir).resolve() if not Path(args.fusion_output_dir).is_absolute() else Path(args.fusion_output_dir).resolve()
    extract_root = (base / args.extract_root).resolve() if not Path(args.extract_root).is_absolute() else Path(args.extract_root).resolve()
    front_dir = extract_root / "front"
    data_root = front_dir if front_dir.is_dir() else extract_root

    restrict_csv = _ten_sentence_gloss_id_csv()

    if bool(getattr(args, "skeleton_only", False)) and not bool(getattr(args, "export_skeleton_corpus", False)):
        raise SystemExit("--skeleton_only 需与 --export_skeleton_corpus 同时使用")

    if bool(getattr(args, "export_skeleton_corpus", False)):
        from skeleton_corpus import export_skeleton_corpus_from_front

        export_skeleton_corpus_from_front(
            extract_root,
            gloss_src,
            restrict_gloss_ids=parse_ids_from_sentences(DEFAULT_SENTENCES),
            max_frames_per_gloss=0,
            out_subdir=str(getattr(args, "skeleton_out_subdir", "skeleton_corpus") or "skeleton_corpus"),
        )
        print("[butting_connectro] skeleton_corpus 导出完成（十句 gloss 子集）")
        if bool(getattr(args, "skeleton_only", False)):
            return

    if bool(args.train_first):
        if str(args.recognizer).strip().lower() == "fusion":
            train_script = (base / "train_fusion.py").resolve()
            if not train_script.is_file():
                raise FileNotFoundError(f"train_fusion.py not found: {train_script}")
            cmd_train = [
                sys.executable,
                str(train_script),
                "--epochs",
                str(int(args.epochs)),
                "--batch_size",
                str(int(args.batch_size)),
                "--lr",
                str(float(args.lr)),
                "--weight_decay",
                str(float(args.weight_decay)),
                "--output_dir",
                str(fusion_out),
                "--pose_json",
                str((base / args.pose_json).resolve() if not Path(args.pose_json).is_absolute() else Path(args.pose_json).resolve()),
            ]
            if bool(args.fusion_dual_stream):
                cmd_train.extend(
                    [
                        "--rgb_json",
                        str((base / args.rgb_json).resolve() if not Path(args.rgb_json).is_absolute() else Path(args.rgb_json).resolve()),
                    ]
                )
            else:
                cmd_train.append("--pose_only")
            cmd_train.extend(["--restrict_gloss_ids", restrict_csv])
            print("Training fusion:", " ".join(cmd_train))
            _env = os.environ.copy()
            if sys.platform.startswith("win"):
                _env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
            subprocess.run(cmd_train, check=True, env=_env)
        else:
            train_script = (base / "train_image.py").resolve()
            if not train_script.is_file():
                raise FileNotFoundError(f"train_image.py not found: {train_script}")
            cmd_train = [
                sys.executable,
                str(train_script),
                "--data_root",
                str(data_root),
                "--layout",
                "gloss_id_folder",
                "--output_dir",
                str(outputs_image),
                "--epochs",
                str(int(args.epochs)),
                "--batch_size",
                str(int(args.batch_size)),
                "--lr",
                str(float(args.lr)),
                "--weight_decay",
                str(float(args.weight_decay)),
                "--arch",
                str(args.arch),
                "--augment_level",
                str(args.augment_level),
                "--class_weight",
                str(args.class_weight),
                "--label_smoothing",
                str(float(args.label_smoothing)),
            ]
            cmd_train.append("--augment")
            if args.pretrained:
                cmd_train.append("--pretrained")
            if args.amp:
                cmd_train.append("--amp")
            cmd_train.extend(["--restrict_gloss_ids", restrict_csv])
            print("Training image:", " ".join(cmd_train))
            _env = os.environ.copy()
            if sys.platform.startswith("win"):
                _env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
            subprocess.run(cmd_train, check=True, env=_env)

    if bool(getattr(args, "train_skeleton_mlp", False)):
        sk_script = (base / "train_skeleton_sequence.py").resolve()
        if not sk_script.is_file():
            raise FileNotFoundError(f"train_skeleton_sequence.py not found: {sk_script}")
        frames_j = extract_root / str(getattr(args, "skeleton_out_subdir", "skeleton_corpus") or "skeleton_corpus") / "frames.jsonl"
        if not frames_j.is_file():
            print(
                f"WARN: 未找到 {frames_j}，跳过 --train_skeleton_mlp。请先执行 --export_skeleton_corpus 或运行 skeleton_corpus.py。"
            )
        else:
            out_mlp = Path(str(getattr(args, "skeleton_mlp_out", "outputs/skeleton_mlp") or "outputs/skeleton_mlp").strip())
            out_mlp = out_mlp.resolve() if out_mlp.is_absolute() else (base / out_mlp).resolve()
            cmd_sk = [
                sys.executable,
                str(sk_script),
                "--frames_jsonl",
                str(frames_j),
                "--output_dir",
                str(out_mlp),
                "--restrict_gloss_ids",
                restrict_csv,
            ]
            print("train_skeleton_mlp:", " ".join(cmd_sk))
            _env2 = os.environ.copy()
            if sys.platform.startswith("win"):
                _env2.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
            subprocess.run(cmd_sk, check=True, env=_env2)

    if str(args.recognizer).strip().lower() == "fusion":
        ckpt, train_log = pick_latest_fusion_run(fusion_out)
        auto_prefer = "fusion"
    else:
        ckpt, train_log = pick_latest_image_run(outputs_image)
        auto_prefer = "image"

    if ckpt is None:
        hint = fusion_out if str(args.recognizer).strip().lower() == "fusion" else outputs_image
        raise FileNotFoundError(f"未找到可用权重（recognizer={args.recognizer}）。请先训练或检查目录: {hint}")

    camera_script = (base / "camera_interface.py").resolve()
    if not camera_script.is_file():
        raise FileNotFoundError(f"camera_interface.py not found: {camera_script}")

    cmd = [
        sys.executable,
        str(camera_script),
        "--checkpoint",
        str(ckpt),
        "--prefer",
        str(auto_prefer),
        "--train_log",
        str(train_log) if train_log is not None else "",
        "--gloss",
        str(gloss_subset_path),
        "--camera",
        str(int(args.camera)),
        "--infer_every",
        str(int(args.infer_every)),
        "--smooth_k",
        str(int(args.smooth_k)),
        "--commit_conf",
        str(float(args.commit_conf)),
        "--commit_hold",
        str(int(args.commit_hold)),
        "--repeat_gap_frames",
        str(int(args.repeat_gap_frames)),
        "--motion_threshold",
        str(float(args.motion_threshold)),
        "--warmup_seconds",
        str(float(args.warmup_seconds)),
    ]
    skel_arg = str(getattr(args, "skeleton_match_index", "") or "").strip()
    skel_npz: Path | None = None
    if skel_arg:
        _sp = Path(skel_arg)
        skel_npz = _sp.resolve() if _sp.is_absolute() else (base / _sp).resolve()
    else:
        _cand = extract_root / str(getattr(args, "skeleton_out_subdir", "skeleton_corpus") or "skeleton_corpus") / "skeleton_match_index.npz"
        if _cand.is_file():
            skel_npz = _cand
    if skel_npz is not None:
        if skel_npz.is_file():
            cmd.extend(
                [
                    "--skeleton_match_index",
                    str(skel_npz),
                    "--skeleton_match_threshold",
                    str(float(getattr(args, "skeleton_match_threshold", 2.4))),
                    "--skeleton_match_metric",
                    str(getattr(args, "skeleton_match_metric", "hands_l2")),
                    "--skeleton_buffer",
                    str(int(getattr(args, "skeleton_buffer", 48))),
                    "--skeleton_min_frames",
                    str(int(getattr(args, "skeleton_min_frames", 8))),
                    "--skeleton_match_len",
                    str(int(getattr(args, "skeleton_match_len", 16))),
                ]
            )
            print(f"[butting_connectro] 骨骼序列匹配已启用: {skel_npz}")
        else:
            print(f"WARN: --skeleton_match_index 路径不存在，跳过骨骼匹配: {skel_npz}")
    if not bool(getattr(args, "no_skeleton_mlp", False)):
        mlp_ck = str(getattr(args, "skeleton_mlp_checkpoint", "") or "").strip()
        mlp_path: Path | None = None
        if mlp_ck:
            mp = Path(mlp_ck)
            mlp_path = mp.resolve() if mp.is_absolute() else (base / mp).resolve()
        else:
            mlp_path = pick_latest_skeleton_mlp((base / "outputs" / "skeleton_mlp").resolve())
        if mlp_path is not None and mlp_path.is_file():
            cmd.extend(["--skeleton_mlp_checkpoint", str(mlp_path)])
            print(f"[butting_connectro] 骨骼MLP 推理: {mlp_path}")
        elif mlp_ck:
            print(f"WARN: --skeleton_mlp_checkpoint 不存在，跳过: {mlp_path}")
    if str(getattr(args, "video", "")).strip():
        cmd.extend(
            [
                "--video",
                str(args.video),
                "--max_videos",
                str(int(args.max_videos)),
                "--playback_speed",
                str(float(args.playback_speed)),
            ]
        )
    if bool(args.enable_sentence_model):
        cmd.append("--enable_sentence_model")
    if bool(args.draw_kp):
        cmd.append("--draw_kp")
        cmd.extend(
            [
                "--kp_source",
                str(args.kp_source),
                "--hands_min_det",
                str(float(args.hands_min_det)),
                "--hands_min_track",
                str(float(args.hands_min_track)),
                "--kp_smooth_alpha",
                str(float(args.kp_smooth_alpha)),
            ]
        )
        if bool(args.draw_pose):
            cmd.append("--draw_pose")
        if bool(args.draw_face_box):
            cmd.append("--draw_face_box")
        if bool(getattr(args, "draw_hand_roi", True)):
            cmd.append("--draw_hand_roi")
        else:
            cmd.append("--no-draw_hand_roi")
        if bool(getattr(args, "draw_arm_roi", True)):
            cmd.append("--draw_arm_roi")
        else:
            cmd.append("--no-draw_arm_roi")
    cmd = [x for x in cmd if str(x).strip() != ""]

    print(f"Using checkpoint: {ckpt} (recognizer={args.recognizer})")
    if train_log:
        print(f"Using train_log: {train_log}")
    print(f"Scope: extract.py DEFAULT_SENTENCES only ({len(restrict_csv.split(','))} gloss ids)")
    print(f"Glossary: subset file for UI ({n_gloss_rows} rows) <- {gloss_src.name}")
    print("Running:", " ".join(cmd))
    _env = os.environ.copy()
    if sys.platform.startswith("win"):
        _env.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    subprocess.run(cmd, check=True, env=_env)


if __name__ == "__main__":
    main()
