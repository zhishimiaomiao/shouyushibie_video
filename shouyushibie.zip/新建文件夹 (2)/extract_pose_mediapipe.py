from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np

from glossary import (
    dedupe_video_paths_by_basename,
    gloss_video_coverage_report,
    iter_video_paths_many,
    resolve_script_path,
    video_feature_key,
)


def extract_keypoints(video_path: Path, max_frames: int = 64) -> np.ndarray:
    import mediapipe as mp

    mp_holistic = mp.solutions.holistic
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    all_frames = []
    with mp_holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ) as holistic:
        while len(all_frames) < max_frames:
            ok, frame = cap.read()
            if not ok:
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = holistic.process(rgb)

            keypoints = []
            for hand in [result.left_hand_landmarks, result.right_hand_landmarks]:
                if hand is None:
                    keypoints.extend([0.0] * (21 * 3))
                else:
                    for lm in hand.landmark:
                        keypoints.extend([lm.x, lm.y, lm.z])
            all_frames.append(keypoints)
    cap.release()

    if not all_frames:
        return np.zeros((max_frames, 126), dtype=np.float32)

    arr = np.array(all_frames, dtype=np.float32)
    if arr.shape[0] < max_frames:
        pad = np.zeros((max_frames - arr.shape[0], arr.shape[1]), dtype=np.float32)
        arr = np.concatenate([arr, pad], axis=0)
    return arr[:max_frames]


def load_keys_from_rgb_json(rgb_json: Path):
    if not rgb_json.exists():
        return []
    with open(rgb_json, "r", encoding="utf-8") as f:
        data = json.load(f)
    return sorted(data.keys())


def load_keys_from_rgb_npz(npz_path: Path):
    if not npz_path.exists() or npz_path.suffix.lower() != ".npz":
        return []
    z = np.load(npz_path, allow_pickle=True)
    return [str(k) for k in z["keys"]]


def load_keys_from_feature_csv(feature_dir: Path):
    csv_files = sorted(feature_dir.glob("*.csv"))
    keys = []
    for csv_file in csv_files:
        person = csv_file.stem
        # Count rows without importing pandas.
        with open(csv_file, "r", encoding="utf-8-sig", newline="") as f:
            row_count = sum(1 for _ in csv.reader(f))
        for class_id in range(row_count):
            keys.append(f"{class_id:04d}_{person}.mp4")
    return keys


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract hand skeleton sequence with MediaPipe")
    parser.add_argument(
        "--video_dir",
        action="append",
        default=None,
        metavar="DIR",
        help=(
            "Video root (recursive). Repeat to merge multiple folders. "
            "Relative paths are under sign_language_system. Default: ../Videos."
        ),
    )
    parser.add_argument(
        "--gloss_csv",
        type=str,
        default=r"..\gloss.csv",
        help="If present, print gloss vs video coverage before extraction.",
    )
    parser.add_argument(
        "--no_gloss_report",
        action="store_true",
        help="Skip gloss coverage printout.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="outputs/pose_features.npz",
        help="Where to save features. Default .npz matches train_fusion; MediaPipe video export is written as .json (same stem).",
    )
    parser.add_argument("--max_frames", type=int, default=64)
    parser.add_argument(
        "--rgb_json",
        type=str,
        default="outputs/video_3dcnn_features.npz",
        help="Optional key list for alignment: NPZ/JSON from extract_3dcnn_features (same sample ids).",
    )
    parser.add_argument("--fallback_feature_dir", type=str, default=r"..\Code\tech code\LSNU-SCL_feature_768")
    parser.add_argument(
        "--strict_input",
        action="store_true",
        help="Raise error when no videos found (default: create empty json and continue).",
    )
    parser.add_argument(
        "--dedupe_same_basename",
        action="store_true",
        help="Keep only the first path per filename (default: keep all; keys like Participant_01/0072.mp4).",
    )
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    rel_dirs = args.video_dir if args.video_dir else [r"..\Videos"]
    video_roots = [resolve_script_path(base_dir, d) for d in rel_dirs]
    gloss_csv = resolve_script_path(base_dir, args.gloss_csv)
    output_path = (base_dir / args.output).resolve()
    rgb_json_path = (base_dir / args.rgb_json).resolve()
    fallback_feature_dir = (base_dir / args.fallback_feature_dir).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    print("Video roots (merged):")
    for root in video_roots:
        tag = "ok" if root.is_dir() else "MISSING - skipped"
        print(f"  {root}  ({tag})")
    video_files = iter_video_paths_many(video_roots)
    if args.dedupe_same_basename:
        video_files, nd_dup = dedupe_video_paths_by_basename(video_files)
        if nd_dup:
            print(f"Note: skipped {nd_dup} path(s) (--dedupe_same_basename: one path per filename).")
    else:
        print(
            "Pose keys = path relative to each --video_dir root (e.g. Participant_01/0072.mp4); "
            "align extract_3dcnn_features with the same --video_dir list."
        )
    if not args.no_gloss_report:
        print("--- gloss vs videos ---")
        print(gloss_video_coverage_report(gloss_csv, video_files))
        print("--- end report ---")

    if not video_files:
        roots_hint = ", ".join(str(r) for r in video_roots)
        msg = f"No videos found under: {roots_hint}. Add data or pass more --video_dir (absolute paths allowed)."
        # Prefer CSV for key list; else NPZ keys (no huge JSON load); last resort legacy JSON.
        keys = load_keys_from_feature_csv(fallback_feature_dir)
        if not keys:
            keys = load_keys_from_rgb_npz(rgb_json_path)
        if not keys:
            keys = load_keys_from_rgb_json(rgb_json_path)

        if keys:
            # Lightweight fallback: NPZ only (JSON for ~67k samples would be multi‑GB).
            npz_path = output_path if output_path.suffix.lower() == ".npz" else output_path.with_suffix(".npz")
            pose_stack = np.zeros((len(keys), 1, 126), dtype=np.float32)
            np.savez_compressed(npz_path, keys=np.asarray(keys, dtype=object), pose=pose_stack)
            print(msg)
            try:
                rel_npz = npz_path.relative_to(base_dir)
            except ValueError:
                rel_npz = npz_path
            print(f"Fallback: {len(keys)} keys (aligned with 3D-CNN naming) -> {rel_npz}")
            print(f"Next: python train_fusion.py --pose_json {rel_npz.as_posix()}")
            return

        if args.strict_input:
            raise FileNotFoundError(msg)
        empty_path = output_path if output_path.suffix.lower() == ".json" else output_path.with_suffix(".json")
        with open(empty_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        print(msg)
        print(f"Created empty pose feature file: {empty_path}")
        return

    data = {}
    for vp in video_files:
        key = video_feature_key(vp, video_roots)
        arr = extract_keypoints(vp, max_frames=args.max_frames)
        data[key] = arr.tolist()
        print(f"Processed: {key}, shape={arr.shape}")

    json_path = output_path if output_path.suffix.lower() == ".json" else output_path.with_suffix(".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f)
    print(f"Saved pose features (JSON) to: {json_path}")


if __name__ == "__main__":
    main()
