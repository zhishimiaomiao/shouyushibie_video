from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, List

import numpy as np


def count_csv_rows(path: Path) -> int:
    if not path.exists():
        return 0
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return 0
    # Heuristic: first row is header if any non-numeric token exists.
    header_like = any(not cell.strip().isdigit() for cell in rows[0] if cell.strip())
    return max(0, len(rows) - (1 if header_like else 0))


def count_json_items(path: Path) -> int:
    if not path.exists():
        return 0
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        return len(data)
    if isinstance(data, list):
        return len(data)
    return 1


def count_npz_items(path: Path) -> int:
    if not path.exists():
        return 0
    z = np.load(path, allow_pickle=True)
    if "keys" in z:
        return int(len(z["keys"]))
    # fallback: first array length
    for k in z.files:
        arr = z[k]
        if hasattr(arr, "shape") and len(arr.shape) > 0:
            return int(arr.shape[0])
    return 0


def read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def latest_train_result_block(dir_path: Path) -> Dict[str, Any]:
    """Prefer new layout: newest ``run_*/训练记录.json`` → 训练结果."""
    logs = sorted(dir_path.glob("run_*/训练记录.json"))
    if not logs:
        return {}
    doc = read_json(logs[-1])
    block = doc.get("训练结果")
    return block if isinstance(block, dict) else {}


def analyze(base: Path) -> Dict[str, Any]:
    outputs = base / "outputs"
    report: Dict[str, Any] = {
        "project_root": str(base),
        "summary": {},
        "models": [],
    }

    # Common data sources
    feature_csv_dir = (base.parent / "Code" / "tech code" / "LSNU-SCL_feature_768").resolve()
    gloss_csv = (base.parent / "gloss.csv").resolve()
    videos_dir = (base.parent / "Videos").resolve()
    pics_dir = (base.parent / "Pics").resolve()
    cslr_manifest = outputs / "cslr_manifest.csv"
    translation_library = outputs / "translation_library.csv"
    pose_json = outputs / "pose_features.json"
    pose_npz = outputs / "pose_features.npz"
    rgb_json = outputs / "video_3dcnn_features.json"
    rgb_npz = outputs / "video_3dcnn_features.npz"

    # Counts / availability
    feature_csv_files = sorted(feature_csv_dir.glob("*.csv")) if feature_csv_dir.exists() else []
    feature_rows = 0
    for fp in feature_csv_files:
        try:
            arr = np.loadtxt(fp, delimiter=",", dtype=np.float32)
            if arr.ndim == 1:
                feature_rows += 1
            else:
                feature_rows += int(arr.shape[0])
        except Exception:
            pass

    report["summary"] = {
        "gloss_entries": count_csv_rows(gloss_csv),
        "feature_csv_files": len(feature_csv_files),
        "feature_samples_from_csv_rows": feature_rows,
        "cslr_manifest_samples": count_csv_rows(cslr_manifest),
        "translation_library_pairs": count_csv_rows(translation_library),
        "pose_json_samples": count_json_items(pose_json),
        "pose_npz_samples": count_npz_items(pose_npz),
        "rgb_json_samples": count_json_items(rgb_json),
        "rgb_npz_samples": count_npz_items(rgb_npz),
        "videos_dir_exists": videos_dir.exists(),
        "pics_dir_exists": pics_dir.exists(),
    }

    # Model: train.py baseline
    m_base = read_json(outputs / "metrics.json") or latest_train_result_block(outputs)
    if m_base:
        report["models"].append(
            {
                "name": "train.py (isolated sign baseline)",
                "metrics_file": str(outputs / "metrics.json")
                if (outputs / "metrics.json").exists()
                else "(see newest outputs/run_*/训练记录.json)",
                "dataset_used": str(feature_csv_dir),
                "dataset_count": {
                    "csv_files": len(feature_csv_files),
                    "samples_from_rows": feature_rows,
                    "num_train_samples": m_base.get("num_train_samples"),
                    "num_test_samples": m_base.get("num_test_samples"),
                },
                "how_used": [
                    "Read each CSV row as one 768-d feature sample.",
                    "Parse row index as class id.",
                    "Do stratified train/test split, then classify with SignRecognizer.",
                ],
                "preprocess": [
                    "No video decoding; directly use pre-extracted 768-d vectors.",
                    "Convert to torch tensor and feed to temporal head (BiLSTM/Transformer/TCN).",
                ],
            }
        )

    # Model: fusion train
    fusion_dir = outputs / "fusion"
    fusion_metrics = read_json(fusion_dir / "metrics.json") or latest_train_result_block(fusion_dir)
    if fusion_metrics:
        rgb_used = rgb_npz if rgb_npz.exists() else rgb_json
        pose_used = pose_npz if pose_npz.exists() else pose_json
        rgb_count = count_npz_items(rgb_used) if rgb_used.suffix.lower() == ".npz" else count_json_items(rgb_used)
        pose_count = count_npz_items(pose_used) if pose_used.suffix.lower() == ".npz" else count_json_items(pose_used)
        report["models"].append(
            {
                "name": "train_fusion.py (dual-stream fusion)",
                "metrics_file": str(fusion_dir / "metrics.json")
                if (fusion_dir / "metrics.json").exists()
                else "(see newest outputs/fusion/run_*/训练记录.json)",
                "dataset_used": [str(rgb_used), str(pose_used)],
                "dataset_count": {
                    "rgb_samples": rgb_count,
                    "pose_samples": pose_count,
                    "shared_rgb_pose_samples_est": min(rgb_count, pose_count) if rgb_count > 0 and pose_count > 0 else 0,
                    "num_classes": fusion_metrics.get("num_classes"),
                },
                "how_used": [
                    "Match samples by same key name between RGB stream and Pose stream.",
                    "RGB vector + Pose sequence are encoded and fused for classification.",
                ],
                "preprocess": [
                    "If videos are absent, fallback features may be generated from CSV.",
                    "Pose fallback may use zero-pose placeholders; real mode uses MediaPipe landmarks.",
                ],
            }
        )

    # Model: CTC
    ctc_dir = outputs / "ctc"
    ctc_metrics = read_json(ctc_dir / "metrics.json") or latest_train_result_block(ctc_dir)
    if ctc_metrics:
        report["models"].append(
            {
                "name": "train_ctc.py (continuous sign recognition)",
                "metrics_file": str(ctc_dir / "metrics.json")
                if (ctc_dir / "metrics.json").exists()
                else "(see newest outputs/ctc/run_*/训练记录.json)",
                "dataset_used": {
                    "sequence_features": str(pose_json if pose_json.exists() else pose_npz),
                    "manifest": str(cslr_manifest),
                },
                "dataset_count": {
                    "manifest_rows": count_csv_rows(cslr_manifest),
                    "sequence_samples": count_json_items(pose_json) if pose_json.exists() else count_npz_items(pose_npz),
                    "vocab_size": ctc_metrics.get("vocab_size"),
                },
                "how_used": [
                    "Use cslr_manifest sample_id to align target_ids with sequence features.",
                    "Train CTC model on variable-length sequences.",
                ],
                "preprocess": [
                    "Pad sequences in collate_fn and keep input_lengths/target_lengths.",
                    "Greedy CTC decode for WER evaluation.",
                ],
            }
        )

    # Model: interpretive scheme
    interp_cfg = read_json(outputs / "interpretive_scheme" / "config.json")
    interp_hist = read_json(outputs / "interpretive_scheme" / "history.json")
    if interp_cfg or interp_hist:
        report["models"].append(
            {
                "name": "interpretive_scheme.py (gloss->Chinese translation)",
                "metrics_file": str(outputs / "interpretive_scheme" / "history.json"),
                "dataset_used": str(translation_library if translation_library.exists() else cslr_manifest),
                "dataset_count": {
                    "translation_pairs": count_csv_rows(translation_library) if translation_library.exists() else count_csv_rows(cslr_manifest),
                    "epochs_recorded": len(interp_hist.get("train_loss", [])),
                },
                "how_used": [
                    "Build seq2seq source from gloss id sequence (src_ids).",
                    "Build target from Chinese sentence/phrase (tgt_zh).",
                    "Train Transformer encoder-decoder and decode Chinese at runtime.",
                ],
                "preprocess": [
                    "Auto-build translation library from manifest via windows + random composition.",
                    "Chinese side uses character-level tokenization; source uses gloss-id tokens.",
                ],
            }
        )

    return report


def render_text(report: Dict[str, Any]) -> str:
    lines: List[str] = []
    lines.append("=== 训练数据使用审计报告 ===")
    lines.append(f"项目路径: {report.get('project_root', '')}")
    lines.append("")
    lines.append("[总体数据概览]")
    for k, v in report.get("summary", {}).items():
        lines.append(f"- {k}: {v}")
    lines.append("")
    lines.append("[各模型数据使用详情]")
    for m in report.get("models", []):
        lines.append(f"\n模型: {m.get('name')}")
        lines.append(f"  指标文件: {m.get('metrics_file')}")
        lines.append(f"  使用数据: {m.get('dataset_used')}")
        lines.append(f"  数据量: {m.get('dataset_count')}")
        lines.append("  怎么用到数据:")
        for x in m.get("how_used", []):
            lines.append(f"    - {x}")
        lines.append("  数据处理方式:")
        for x in m.get("preprocess", []):
            lines.append(f"    - {x}")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit which datasets were used by current training artifacts.")
    parser.add_argument("--base_dir", type=str, default=".", help="sign_language_system directory")
    parser.add_argument("--output_txt", type=str, default="outputs/dataset_usage_audit.txt")
    parser.add_argument("--output_json", type=str, default="outputs/dataset_usage_audit.json")
    args = parser.parse_args()

    base = Path(args.base_dir).resolve()
    report = analyze(base)

    output_txt = (base / args.output_txt).resolve()
    output_json = (base / args.output_json).resolve()
    output_txt.parent.mkdir(parents=True, exist_ok=True)
    output_json.parent.mkdir(parents=True, exist_ok=True)

    text = render_text(report)
    output_txt.write_text(text, encoding="utf-8")
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(text)
    print(f"\nSaved text report: {output_txt}")
    print(f"Saved json report: {output_json}")


if __name__ == "__main__":
    main()

