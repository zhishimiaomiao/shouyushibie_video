"""
训练运行目录、时间戳、断点续训与多检查点的共用工具。

- 每次训练默认写入 ``<output_dir>/<run_YYYY-mm-dd_HHMMSS>/``，避免覆盖旧结果。
- ``checkpoint_last.pt``：每 epoch 更新，含 model + optimizer + history，用于 ``--resume``。
- ``best_*.pt``：验证集最优权重（state_dict，与原先脚本命名兼容）。
- 可选 ``epoch_weights_epoch_NNN.pt``：仅权重，便于对比。

产物约定（避免 outputs 里一堆难辨文件）：
- 每个 run 目录只保留一份 ``训练记录.json``，内含「时间 / 命令与配置 / 训练结果(含 history) / 问题分析」。
- 另写入 ``训练记录说明.txt``：明文说明「勿把 .pt 当日志打开」，并摘要关键指标（避免误开权重文件看到乱码）。
- 训练结束会删除同目录下的 ``run_meta.json``、``metrics.json``、``history.json``（若存在）。
- ``training_runs_index.jsonl`` 默认不再写入，需要时脚本加 ``--write_runs_index``。
"""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import torch
from torch import nn
from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler

CHECKPOINT_LAST = "checkpoint_last.pt"
TRAIN_LOG_NAME = "训练记录.json"
TRAIN_README_TXT = "训练记录说明.txt"

DEFAULT_ANALYSIS_NOTES = (
    "在此手写问题分析：数据是否平衡、过拟合、难类别、域偏移、下一步调参等。"
    "训练脚本会保留本字段已有文字，不会在结束时清空。"
)


def resolve_training_device(force_cpu: bool) -> torch.device:
    """
    Default policy for all training scripts:

    - Prefer GPU (CUDA / Apple MPS) for training.
    - Refuse CPU unless explicitly forced via --cpu.
    """
    if force_cpu:
        return torch.device("cpu")
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
        return torch.device("mps")
    raise RuntimeError(
        "未检测到可用的 GPU（CUDA 或 Apple MPS）。训练默认必须使用 GPU。\n"
        "请安装/配置 CUDA 版 PyTorch 与显卡驱动后再运行；"
        "若仅需在 CPU 上调试，请添加命令行参数 --cpu。"
    )


def resolve_resume_path(base_dir: Path, resume: str) -> Path:
    # Allow Windows-style paths when running on Linux (treat '\' as separator).
    # On Linux, a backslash is a valid filename char, so we normalize here.
    s = str(resume).strip().replace("\\", "/")
    p = Path(s)
    return p.resolve() if p.is_absolute() else (base_dir / p).resolve()


def should_append_run_index(
    resume_checkpoint: Optional[Path],
    run_name: Optional[str],
    run_dir: Path,
) -> bool:
    """续训且未指定 run_name、输出目录与检查点目录相同时，不向 index 重复追加。"""
    if resume_checkpoint is not None and resume_checkpoint.is_file() and run_name is None:
        if run_dir.resolve() == resume_checkpoint.parent.resolve():
            return False
    return True


def default_run_name() -> str:
    return datetime.now().strftime("run_%Y-%m-%d_%H%M%S")


def resolve_run_dir(
    base_output: Path,
    run_name: Optional[str],
    flat: bool,
    resume_checkpoint: Optional[Path] = None,
) -> Tuple[Path, str]:
    """
    flat=True：直接使用 base_output（与旧版「单目录覆盖」行为一致）。
    flat=False：
    - 若显式传入 ``run_name``：``base_output / run_name``；
    - 若传入 ``resume_checkpoint`` 且未指定 ``run_name``：**沿用检查点所在目录**（续训不新建 run 文件夹）；
    - 否则新建 ``run_YYYY-mm-dd_HHMMSS``。
    返回 (run_dir, run_label)。
    """
    base_output = base_output.resolve()
    if flat:
        base_output.mkdir(parents=True, exist_ok=True)
        return base_output, "flat"
    if run_name:
        run_dir = base_output / run_name
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir, run_name
    if resume_checkpoint is not None and resume_checkpoint.is_file():
        run_dir = resume_checkpoint.parent.resolve()
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir, run_dir.name
    label = default_run_name()
    run_dir = base_output / label
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir, label


def append_training_run_index(
    base_output: Path,
    run_label: str,
    run_dir: Path,
    *,
    append: bool = True,
    enabled: bool = False,
) -> None:
    """在 base_output 下追加一行 JSONL。默认关闭（enabled=False），避免 outputs 根目录堆积索引。"""
    if not enabled or run_label == "flat" or not append:
        return
    log_path = base_output.resolve() / "training_runs_index.jsonl"
    rec = {
        "time": datetime.now().isoformat(timespec="seconds"),
        "run_label": run_label,
        "path": str(run_dir.resolve()),
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def write_run_meta(run_dir: Path, args: Any, extra: Optional[Dict[str, Any]] = None) -> None:
    """旧版元数据；新流程请用 ``init_train_log`` / ``finalize_train_log``。保留函数供迁移脚本调用。"""
    meta: Dict[str, Any] = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir.resolve()),
        "args": vars(args) if hasattr(args, "__dict__") else dict(args),
    }
    if extra:
        meta.update(extra)
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "run_meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)


def write_training_readme_txt(
    run_dir: Path,
    *,
    script: str,
    run_label: str,
    started_at: str,
    finished_at: str,
    metrics: Dict[str, Any],
    history: Dict[str, Any],
) -> None:
    """
    明文说明：可读日志是「训练记录.json」；``.pt`` 为二进制权重，文本打开会乱码。
    """
    lines: list[str] = [
        "=" * 72,
        "训练输出里哪些是「日志」，哪些是「模型权重」",
        "=" * 72,
        "",
        "【要看训练曲线、准确率、超参数】",
        f"  → 请用编辑器打开本目录下的：{TRAIN_LOG_NAME}",
        "     （UTF-8 的 JSON，含完整 history、配置等。）",
        "",
        "【不要用文本方式打开以下文件当「日志」】",
        "  → *.pt、*.pth（如 best_image_model.pt、checkpoint_last.pt）",
        "     这是 PyTorch 的二进制权重，用记事本 / IDE 当文本打开会出现乱码、NUL、",
        "     SOH 等控制符，属于正常现象，不是文件损坏。",
        "  → 在代码里加载请使用：torch.load(path, map_location=\"cpu\") 等。",
        "",
        "-" * 72,
        "本次运行摘要",
        "-" * 72,
        f"脚本: {script}",
        f"run: {run_label}",
        f"目录: {run_dir.resolve()}",
        f"开始: {started_at}",
        f"结束: {finished_at}",
        "",
    ]
    for key in (
        "best_test_accuracy",
        "best_epoch",
        "epochs_ran",
        "num_classes",
        "layout",
        "num_train_samples",
        "num_test_samples",
    ):
        if key in metrics:
            lines.append(f"  {key}: {metrics[key]}")
    ta = history.get("test_acc") if isinstance(history, dict) else None
    tl = history.get("test_loss") if isinstance(history, dict) else None
    if isinstance(ta, list) and ta:
        tail = ta[-min(10, len(ta)) :]
        lines.append("")
        lines.append(f"  test_acc（最后 {len(tail)} 个 epoch）: " + ", ".join(f"{float(x):.4f}" for x in tail))
    if isinstance(tl, list) and tl:
        tail = tl[-min(10, len(tl)) :]
        lines.append(f"  test_loss（最后 {len(tail)} 个 epoch）: " + ", ".join(f"{float(x):.4f}" for x in tail))
    lines.extend(["", "=" * 72, ""])
    (run_dir / TRAIN_README_TXT).write_text("\n".join(lines), encoding="utf-8")


def init_train_log(run_dir: Path, args: Any, script: str, run_label: str) -> None:
    """训练开始时写入 ``训练记录.json`` 骨架；续训时保留 started_at 与「问题分析」手写内容。"""
    run_dir.mkdir(parents=True, exist_ok=True)
    # 尽早提示勿把 .pt 当作文本日志打开（训练结束会由 finalize 覆盖为带指标版）
    hint_path = run_dir / TRAIN_README_TXT
    if not hint_path.is_file():
        hint_path.write_text(
            "\n".join(
                [
                    "【训练中】完整训练日志请打开：「训练记录.json」",
                    "",
                    "请勿用文本方式打开本目录下的 .pt 文件（模型权重为二进制，会显示乱码）。",
                    "",
                ]
            ),
            encoding="utf-8",
        )
    log_path = run_dir / TRAIN_LOG_NAME
    now = datetime.now().isoformat(timespec="seconds")
    notes = DEFAULT_ANALYSIS_NOTES
    started = now
    if log_path.is_file():
        try:
            prev = json.loads(log_path.read_text(encoding="utf-8"))
            t = prev.get("时间") or {}
            started = str(t.get("started_at") or started)
            pa = prev.get("问题分析") or {}
            if isinstance(pa.get("notes"), str) and pa.get("notes").strip():
                notes = pa["notes"]
        except Exception:
            pass
    cfg = vars(args) if hasattr(args, "__dict__") else dict(args)
    doc: Dict[str, Any] = {
        "脚本": script,
        "时间": {
            "run_label": run_label,
            "run_dir": str(run_dir.resolve()),
            "started_at": started,
        },
        "命令与配置": cfg,
        "训练结果": {"状态": "训练中"},
        "问题分析": {"notes": notes},
    }
    log_path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")


def finalize_train_log(
    run_dir: Path,
    *,
    script: str,
    run_label: str,
    args: Any,
    history: Dict[str, Any],
    metrics: Dict[str, Any],
) -> None:
    """训练结束时写入完整 ``训练记录.json``，并删除 run_meta / metrics / history 冗余副本。"""
    run_dir.mkdir(parents=True, exist_ok=True)
    log_path = run_dir / TRAIN_LOG_NAME
    finished = datetime.now().isoformat(timespec="seconds")
    notes = DEFAULT_ANALYSIS_NOTES
    started = finished
    if log_path.is_file():
        try:
            prev = json.loads(log_path.read_text(encoding="utf-8"))
            t = prev.get("时间") or {}
            started = str(t.get("started_at") or started)
            pa = prev.get("问题分析") or {}
            if isinstance(pa.get("notes"), str) and pa.get("notes").strip():
                notes = pa["notes"]
        except Exception:
            pass
    cfg = vars(args) if hasattr(args, "__dict__") else dict(args)
    result_block = {**metrics, "history": history, "状态": "已完成"}
    doc: Dict[str, Any] = {
        "脚本": script,
        "时间": {
            "run_label": run_label,
            "run_dir": str(run_dir.resolve()),
            "started_at": started,
            "finished_at": finished,
        },
        "命令与配置": cfg,
        "训练结果": result_block,
        "问题分析": {"notes": notes},
    }
    log_path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    write_training_readme_txt(
        run_dir,
        script=script,
        run_label=run_label,
        started_at=started,
        finished_at=finished,
        metrics=dict(metrics),
        history=dict(history),
    )
    for name in ("run_meta.json", "metrics.json", "history.json"):
        p = run_dir / name
        if p.is_file():
            p.unlink()


def consolidate_legacy_run(run_dir: Path) -> bool:
    """将旧版 ``run_meta`` + ``history``（及可选 ``metrics``）合并为 ``训练记录.json`` 并删除旧文件。"""
    log_path = run_dir / TRAIN_LOG_NAME
    if log_path.is_file():
        return False
    meta_p = run_dir / "run_meta.json"
    m_p = run_dir / "metrics.json"
    h_p = run_dir / "history.json"
    if not (meta_p.is_file() and h_p.is_file()):
        return False
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    metrics = json.loads(m_p.read_text(encoding="utf-8")) if m_p.is_file() else {}
    history = json.loads(h_p.read_text(encoding="utf-8"))
    created = str(meta.get("created_at") or "")
    script = str(meta.get("script", ""))
    run_label = str(meta.get("run_label") or run_dir.name)
    doc: Dict[str, Any] = {
        "脚本": script,
        "时间": {
            "run_label": run_label,
            "run_dir": str(run_dir.resolve()),
            "started_at": created,
            "finished_at": created,
        },
        "命令与配置": meta.get("args") or {},
        "训练结果": {**metrics, "history": history, "状态": "已完成"},
        "问题分析": {"notes": "（由旧版 run_meta/metrics/history 合并；可在此补充分析）"},
    }
    log_path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    for p in (meta_p, h_p):
        p.unlink(missing_ok=True)
    if m_p.is_file():
        m_p.unlink(missing_ok=True)
    return True


def consolidate_outputs_tree(outputs_root: Path) -> int:
    """遍历 ``outputs_root/**/run_*``，合并旧三件套；返回成功合并的 run 目录数。"""
    n = 0
    outputs_root = outputs_root.resolve()
    if not outputs_root.is_dir():
        return 0
    for run_dir in sorted(outputs_root.glob("**/run_*")):
        if not run_dir.is_dir():
            continue
        if consolidate_legacy_run(run_dir):
            n += 1
    return n


def save_training_checkpoint(
    path: Path,
    *,
    model: nn.Module,
    optimizer: Optimizer,
    scheduler: _LRScheduler | None = None,
    epoch: int,
    history: Dict[str, Any],
    best_metric: float,
    metric_name: str,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    payload: Dict[str, Any] = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict() if scheduler is not None else None,
        "history": history,
        "best_metric": best_metric,
        "metric_name": metric_name,
    }
    if extra:
        payload["extra"] = extra
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, path)


def load_training_checkpoint(
    path: Path,
    device: torch.device,
) -> Dict[str, Any]:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


def apply_checkpoint_to_model_optimizer(
    ckpt: Dict[str, Any],
    model: nn.Module,
    optimizer: Optional[Optimizer],
    scheduler: _LRScheduler | None = None,
) -> None:
    model.load_state_dict(ckpt["model_state_dict"])
    od = ckpt.get("optimizer_state_dict")
    if optimizer is not None and od is not None:
        optimizer.load_state_dict(od)
    sd = ckpt.get("scheduler_state_dict")
    if scheduler is not None and sd is not None:
        try:
            scheduler.load_state_dict(sd)
        except Exception:
            # scheduler type changed; skip restore
            pass


@dataclass
class ResumeState:
    start_epoch: int
    history: Dict[str, Any]
    best_metric: float


def resume_from_checkpoint(
    resume_path: Path,
    model: nn.Module,
    optimizer: Optimizer,
    scheduler: _LRScheduler | None,
    device: torch.device,
    default_history: Optional[Dict[str, Any]] = None,
) -> ResumeState:
    ckpt = load_training_checkpoint(resume_path, device)
    apply_checkpoint_to_model_optimizer(ckpt, model, optimizer, scheduler)
    ep = int(ckpt.get("epoch", 0))
    hist = ckpt.get("history") or default_history or {}
    if not hist and default_history:
        hist = {k: list(v) for k, v in default_history.items()}
    return ResumeState(
        start_epoch=ep + 1,
        history=hist,
        best_metric=float(ckpt.get("best_metric", 0.0)),
    )


def write_history_atomic(run_dir: Path, history: Dict[str, Any]) -> None:
    """每个 epoch 落盘，避免中断时丢失全部曲线。"""
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)


def maybe_save_epoch_weights(
    run_dir: Path,
    model: nn.Module,
    epoch: int,
    every: int,
    prefix: str = "epoch_weights",
) -> None:
    """every>0 且 epoch % every == 0 时保存仅权重的快照。"""
    if every <= 0:
        return
    if epoch % every != 0:
        return
    path = run_dir / f"{prefix}_epoch_{epoch:03d}.pt"
    torch.save(model.state_dict(), path)


def try_run_reports(base_dir: Path, outputs_dir: Path, reports_dir: Path, limit: int = 0) -> None:
    """
    Best-effort call to generate analysis artifacts (plots + CSV) after training.
    Never raises (so training result isn't lost if report fails).
    """
    try:
        script = (base_dir / "report_runs.py").resolve()
        if not script.is_file():
            return
        cmd = [
            sys.executable,
            str(script),
            "--outputs_dir",
            str(outputs_dir),
            "--reports_dir",
            str(reports_dir),
        ]
        if limit and int(limit) > 0:
            cmd.extend(["--limit", str(int(limit))])
        subprocess.run(cmd, cwd=str(base_dir), check=False)
    except Exception:
        return
