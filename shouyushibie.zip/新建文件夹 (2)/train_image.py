from __future__ import annotations

import argparse
import json
import os
import random
import sys
from contextlib import nullcontext
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Literal

# Workaround for Windows conda OpenMP duplication crash:
# "OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll already initialized."
# Prefer fixing the environment (single OpenMP runtime), but this keeps scripts runnable.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch
from torch.cuda.amp import GradScaler, autocast
from PIL import Image
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from torch.utils.data import DataLoader, Dataset, Subset
from torchvision import datasets, models, transforms
from tqdm import tqdm

from glossary import parse_restrict_gloss_ids

from training_io import (
    CHECKPOINT_LAST,
    TRAIN_README_TXT,
    append_training_run_index,
    finalize_train_log,
    init_train_log,
    maybe_save_epoch_weights,
    resolve_resume_path,
    resolve_run_dir,
    resume_from_checkpoint,
    save_training_checkpoint,
    should_append_run_index,
    try_run_reports,
    write_history_atomic,
)

_IMAGE_EXTS_LOWER = frozenset({".jpg", ".jpeg", ".png", ".bmp", ".webp"})


def _hash_text_to_vec(text: str, *, dim: int, ngram: int = 3) -> np.ndarray:
    """
    Very lightweight hashing embedding (no extra dependencies):
    - character n-grams hashed into a fixed-dim vector
    - L2 normalized for cosine similarity
    """
    dim = int(dim)
    if dim <= 8:
        raise ValueError("dim too small")
    s = "".join(str(text or "").strip().lower().split())
    if not s:
        v = np.zeros((dim,), dtype=np.float32)
        v[0] = 1.0
        return v
    grams = []
    if len(s) <= ngram:
        grams = [s]
    else:
        grams = [s[i : i + ngram] for i in range(0, len(s) - ngram + 1)]
    v = np.zeros((dim,), dtype=np.float32)
    for g in grams:
        # stable-ish hash: python hash is salted per process; use a manual hash
        h = 2166136261
        for ch in g:
            h ^= ord(ch)
            h = (h * 16777619) & 0xFFFFFFFF
        idx = int(h % dim)
        v[idx] += 1.0
    n = float(np.linalg.norm(v))
    if n > 1e-8:
        v /= n
    return v


def build_semantic_class_vectors(
    *,
    classes: list[str],
    gloss_csv: Path | None,
    dim: int,
    text_source: str,
) -> np.ndarray:
    """
    Build per-class normalized vectors for semantic soft labels.

    - classes: dataset.classes (labels as strings)
    - gloss_csv: optional mapping for numeric gloss ids
    - text_source: 'zh'|'en'|'both'|'label'
    """
    text_source = str(text_source).strip().lower()
    if text_source not in {"zh", "en", "both", "label"}:
        raise ValueError("text_source must be one of: zh,en,both,label")

    gloss_map: dict[str, tuple[str, str]] = {}
    if gloss_csv is not None and gloss_csv.is_file():
        from glossary import load_gloss_tuples

        gloss_map = load_gloss_tuples(gloss_csv)

    vecs = np.zeros((len(classes), int(dim)), dtype=np.float32)
    for i, c in enumerate(classes):
        c0 = str(c).strip()
        zh, en = "", ""
        if c0.isdigit():
            key4 = str(int(c0)).zfill(4)
            zh, en = (gloss_map.get(key4) or gloss_map.get(str(int(c0))) or ("", ""))
        if text_source == "label":
            text = c0
        elif text_source == "zh":
            text = zh or c0
        elif text_source == "en":
            text = en or c0
        else:
            text = (zh + " " + en).strip() or c0
        vecs[i] = _hash_text_to_vec(text, dim=int(dim))
    return vecs


def semantic_soft_ce_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    *,
    class_vecs: torch.Tensor,
    alpha: float,
    tau: float,
    topk: int,
) -> torch.Tensor:
    """
    Soft-label cross entropy using semantic neighbors.

    soft_target = (1-alpha)*onehot + alpha*softmax(sim/tau) over Top-K neighbors (including self)
    sim computed from hashed text embeddings (cosine).
    """
    if logits.ndim != 2:
        raise ValueError("logits must be (B,C)")
    b, c = logits.shape
    if class_vecs.ndim != 2 or int(class_vecs.shape[0]) != int(c):
        raise ValueError("class_vecs must be (C,D) and aligned with logits C")

    alpha = float(alpha)
    tau = float(tau)
    topk = int(topk)
    topk = max(2, min(topk, int(c)))
    tau = max(1e-6, tau)
    alpha = max(0.0, min(1.0, alpha))

    # (B,D) for GT label vectors
    gt_vec = class_vecs.index_select(0, targets)  # normalized
    # (B,C) cosine sims
    sims = gt_vec @ class_vecs.t()
    vals, idx = torch.topk(sims, k=topk, dim=1, largest=True, sorted=False)
    # neighbor distribution
    w = torch.softmax(vals / tau, dim=1)  # (B,K)

    logp = torch.log_softmax(logits, dim=1)  # (B,C)

    # - sum soft_target * logp, computed sparsely for neighbor part
    # neighbor loss
    lp_sel = torch.gather(logp, dim=1, index=idx)  # (B,K)
    loss_neighbor = -(w * lp_sel).sum(dim=1)  # (B,)
    # one-hot loss
    loss_hard = -logp.gather(dim=1, index=targets.view(-1, 1)).squeeze(1)

    loss = (1.0 - alpha) * loss_hard + alpha * loss_neighbor
    return loss.mean()


def _pairwise_distances(x: torch.Tensor) -> torch.Tensor:
    """Compute pairwise Euclidean distances for (B,D) -> (B,B)."""
    # squared norms
    x2 = (x * x).sum(dim=1, keepdim=True)
    # squared distance matrix
    d2 = x2 + x2.t() - 2.0 * (x @ x.t())
    d2 = torch.clamp(d2, min=0.0)
    # numeric stability
    return torch.sqrt(d2 + 1e-12)


def batch_hard_triplet_loss(
    emb: torch.Tensor,
    labels: torch.Tensor,
    *,
    margin: float,
) -> torch.Tensor:
    """
    Batch-hard triplet loss:
    - hardest positive: farthest sample with same label
    - hardest negative: closest sample with different label
    Anchors with no positive in batch are ignored.
    """
    if emb.ndim != 2:
        raise ValueError("emb must be (B,D)")
    b = int(emb.shape[0])
    if b <= 1:
        return emb.new_tensor(0.0)
    labels = labels.view(-1)
    dist = _pairwise_distances(emb)  # (B,B)
    same = labels.unsqueeze(0) == labels.unsqueeze(1)  # (B,B)
    eye = torch.eye(b, device=emb.device, dtype=torch.bool)
    same = same & (~eye)  # exclude self
    diff = ~same & (~eye)

    # hardest positive: max dist among same-label
    pos_dist = dist.masked_fill(~same, float("-inf")).max(dim=1).values
    # hardest negative: min dist among diff-label
    neg_dist = dist.masked_fill(~diff, float("inf")).min(dim=1).values

    valid = torch.isfinite(pos_dist) & torch.isfinite(neg_dist)
    if valid.sum().item() == 0:
        return emb.new_tensor(0.0)
    loss = torch.relu(pos_dist[valid] - neg_dist[valid] + float(margin))
    return loss.mean()


class EmbeddingClassifier(nn.Module):
    """
    Classification model with an embedding head for metric learning.
    Returns (logits, embedding).
    """

    def __init__(self, *, arch: str, num_classes: int, pretrained: bool, embed_dim: int) -> None:
        super().__init__()
        arch = str(arch).strip().lower()
        embed_dim = int(embed_dim)
        if embed_dim <= 0:
            raise ValueError("embed_dim must be > 0")

        self.arch = arch
        self.embed_dim = embed_dim

        if arch in {"resnet18", "resnet50"}:
            if arch == "resnet18":
                base = models.resnet18(weights=models.ResNet18_Weights.DEFAULT if pretrained else None)
            else:
                base = models.resnet50(weights=models.ResNet50_Weights.DEFAULT if pretrained else None)
            feat_dim = int(base.fc.in_features)
            base.fc = nn.Identity()
            self.backbone = base
            self.embed = nn.Sequential(nn.Linear(feat_dim, embed_dim), nn.ReLU(inplace=True))
            self.classifier = nn.Linear(embed_dim, int(num_classes))
            return

        if arch == "efficientnet_b0":
            base = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT if pretrained else None)
            # EfficientNet forward: features -> avgpool -> flatten -> classifier
            feat_dim = int(base.classifier[-1].in_features)
            self.backbone = base.features
            self.avgpool = base.avgpool
            self.dropout = base.classifier[0] if isinstance(base.classifier, nn.Sequential) and len(base.classifier) > 0 else nn.Identity()
            self.embed = nn.Sequential(nn.Linear(feat_dim, embed_dim), nn.ReLU(inplace=True))
            self.classifier = nn.Linear(embed_dim, int(num_classes))
            return

        raise ValueError(f"Unsupported arch for embedding: {arch}")

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if self.arch in {"resnet18", "resnet50"}:
            feat = self.backbone(x)
        else:
            feat = self.backbone(x)
            feat = self.avgpool(feat)
            feat = torch.flatten(feat, 1)
            feat = self.dropout(feat)
        emb = self.embed(feat)
        logits = self.classifier(emb)
        return logits, emb

def _looks_like_image_root(p: Path, *, max_checks: int = 2000) -> bool:
    """
    Heuristic: treat a folder as a valid image root iff it contains at least one image file.
    We keep the scan bounded to avoid hanging on huge folders.
    """
    try:
        if not p.is_dir():
            return False
        checked = 0
        # Use extension-targeted glob first; it skips enumerating unrelated paths.
        for ext in _IMAGE_EXTS_LOWER:
            # Path.rglob yields only matching paths; far faster on nested datasets.
            for x in p.rglob(f"*{ext}"):
                checked += 1
                if checked > int(max_checks):
                    return False
                if x.is_file():
                    return True
        return False
    except Exception:
        return False


class MediaPipeOverlayTransform:
    """
    Optional: draw MediaPipe Holistic landmarks on a PIL image.

    Notes:
    - This is intentionally an *opt-in* transform: it is slow.
    - We use lazy initialization so it works with DataLoader workers.
    - Default draws hands only (best signal for sign language).
    """

    def __init__(
        self,
        *,
        draw_pose: bool = False,
        draw_face_box: bool = False,
        prob: float = 1.0,
        model_complexity: int = 1,
        min_det: float = 0.5,
        min_track: float = 0.5,
    ) -> None:
        self.draw_pose = bool(draw_pose)
        self.draw_face_box = bool(draw_face_box)
        self.prob = float(prob)
        self.model_complexity = int(model_complexity)
        self.min_det = float(min_det)
        self.min_track = float(min_track)
        self._mp = None
        self._holistic = None

    def _lazy_init(self) -> None:
        if self._holistic is not None:
            return
        import mediapipe as mp  # local import: optional dependency

        self._mp = mp
        self._holistic = mp.solutions.holistic.Holistic(
            static_image_mode=False,
            model_complexity=int(self.model_complexity),
            min_detection_confidence=float(self.min_det),
            min_tracking_confidence=float(self.min_track),
        )

    def __call__(self, img: Image.Image) -> Image.Image:
        if self.prob <= 0:
            return img
        if self.prob < 1.0 and random.random() > self.prob:
            return img

        try:
            self._lazy_init()
            assert self._mp is not None and self._holistic is not None

            mp = self._mp
            rgb = np.asarray(img.convert("RGB"))
            result = self._holistic.process(rgb)
            if result is None:
                return img

            out = rgb.copy()
            mp_drawing = mp.solutions.drawing_utils
            mp_styles = mp.solutions.drawing_styles
            mp_holistic = mp.solutions.holistic

            # hands
            if result.left_hand_landmarks is not None:
                mp_drawing.draw_landmarks(
                    out,
                    result.left_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )
            if result.right_hand_landmarks is not None:
                mp_drawing.draw_landmarks(
                    out,
                    result.right_hand_landmarks,
                    mp_holistic.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )

            # pose (optional)
            if self.draw_pose and result.pose_landmarks is not None:
                mp_drawing.draw_landmarks(
                    out,
                    result.pose_landmarks,
                    mp_holistic.POSE_CONNECTIONS,
                    mp_styles.get_default_pose_landmarks_style(),
                )

            # face bbox (optional; do NOT draw dense face mesh)
            if self.draw_face_box and result.face_landmarks is not None:
                h, w = out.shape[:2]
                xs = [lm.x for lm in result.face_landmarks.landmark]
                ys = [lm.y for lm in result.face_landmarks.landmark]
                if xs and ys:
                    x1 = int(max(0.0, min(xs)) * w)
                    y1 = int(max(0.0, min(ys)) * h)
                    x2 = int(min(1.0, max(xs)) * w)
                    y2 = int(min(1.0, max(ys)) * h)
                    x1 = max(0, min(w - 1, x1))
                    x2 = max(0, min(w - 1, x2))
                    y1 = max(0, min(h - 1, y1))
                    y2 = max(0, min(h - 1, y2))
                    # yellow bbox
                    out[y1 : y1 + 2, x1:x2] = (255, 255, 0)
                    out[y2 - 2 : y2, x1:x2] = (255, 255, 0)
                    out[y1:y2, x1 : x1 + 2] = (255, 255, 0)
                    out[y1:y2, x2 - 2 : x2] = (255, 255, 0)

            return Image.fromarray(out)
        except Exception:
            # Never break training because of overlay failures.
            return img


class PathLabelDataset(Dataset):
    """Dataset backed by explicit (paths, targets) lists to allow different transforms for train/test."""

    def __init__(self, paths: List[Path], targets: List[int], transform) -> None:
        if len(paths) != len(targets):
            raise ValueError("paths and targets must have same length")
        self.paths = list(paths)
        self.targets = [int(x) for x in targets]
        self.transform = transform

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int):
        path = self.paths[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.targets[idx]


def extract_paths_targets_from_dataset(ds: Dataset) -> Tuple[List[Path], List[int]]:
    """
    Return (paths, targets) from supported dataset types used in this project.
    Avoids materializing image tensors.
    """
    if hasattr(ds, "paths") and hasattr(ds, "targets"):
        paths = [Path(p) for p in getattr(ds, "paths")]
        targets = [int(x) for x in getattr(ds, "targets")]
        return paths, targets
    if isinstance(ds, datasets.ImageFolder):
        paths = [Path(p) for (p, _) in ds.samples]
        targets = [int(y) for y in ds.targets]
        return paths, targets
    raise TypeError(f"Unsupported dataset type for path extraction: {type(ds)!r}")


def infer_group_key_from_path(path: Path) -> str:
    """
    Heuristic group key for leakage-safe split.
    Prefer Participant_* segment if present; else fall back to parent folder name.
    """
    parts = [p for p in path.parts]
    for seg in parts:
        s = str(seg)
        if s.lower().startswith("participant_"):
            return s
    return path.parent.name or "UNKNOWN"


def group_split_is_class_disjoint(paths: List[Path], labels: np.ndarray) -> bool:
    """
    Detect degenerate ``group`` split: every group maps to exactly one class AND
    #groups == #classes (typical when paths lack Participant_* and group key becomes
    the gloss folder name, e.g. extract_dataset/front/0071/*.jpg).

    Then ``group_split_indices`` assigns whole classes to train OR test → disjoint
    label spaces → test accuracy stays ~0 while train memorizes.
    """
    labels = np.asarray(labels, dtype=np.int64)
    groups = np.asarray([infer_group_key_from_path(p) for p in paths], dtype=object)
    uniq_groups = np.unique(groups)
    uniq_labels = np.unique(labels)
    if int(uniq_groups.size) != int(uniq_labels.size):
        return False
    for g in uniq_groups:
        idx = np.where(groups == g)[0]
        if int(np.unique(labels[idx]).size) != 1:
            return False
    return True


def group_split_indices(
    *,
    paths: List[Path],
    labels: np.ndarray,
    test_ratio: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Split by group (participant/video folder) to avoid leakage.
    Ensures groups do not overlap. Tries to keep class distribution roughly balanced
    by greedy assignment of groups to test set until reaching target size.
    """
    rng = np.random.default_rng(seed)
    groups = np.asarray([infer_group_key_from_path(p) for p in paths], dtype=object)
    uniq_groups = np.unique(groups)
    rng.shuffle(uniq_groups)

    # group -> indices
    g2idx: Dict[str, np.ndarray] = {}
    for g in uniq_groups:
        g = str(g)
        g2idx[g] = np.where(groups == g)[0]

    n_total = len(paths)
    n_test_target = max(1, int(round(float(test_ratio) * n_total)))
    # Greedy: sort groups by size desc so the target can be met closely.
    group_order = sorted(uniq_groups.tolist(), key=lambda g: int(g2idx[str(g)].size), reverse=True)
    rng.shuffle(group_order)
    # After shuffle, stably sort by size again with randomness.
    group_order = sorted(group_order, key=lambda g: int(g2idx[str(g)].size), reverse=True)

    test_groups: List[str] = []
    n_test = 0
    for g in group_order:
        if n_test >= n_test_target:
            break
        test_groups.append(str(g))
        n_test += int(g2idx[str(g)].size)

    test_mask = np.isin(groups, np.asarray(test_groups, dtype=object))
    test_idx = np.where(test_mask)[0].astype(np.int64)
    train_idx = np.where(~test_mask)[0].astype(np.int64)
    rng.shuffle(train_idx)
    rng.shuffle(test_idx)

    # Ensure non-empty
    if train_idx.size == 0 or test_idx.size == 0:
        raise RuntimeError(
            "Group split produced empty train/test set. "
            "Please add more groups (participants/videos) or reduce --test_ratio."
        )
    return train_idx, test_idx

def resolve_cli_path(script_dir: Path, user_path: str) -> Path:
    """
    Cross-platform CLI path resolver.

    - Accept Windows-style backslashes even when running on Linux.
    - Relative paths are resolved under script_dir.
    """
    s = str(user_path).strip().replace("\\", "/")
    p = Path(s)
    return p.resolve() if p.is_absolute() else (script_dir / p).resolve()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_transforms(
    *,
    image_size: int,
    augment: bool,
    augment_level: str,
    overlay_tfm=None,
) -> tuple[transforms.Compose, transforms.Compose]:
    """
    Build (train_transform, test_transform).

    - test_transform: deterministic; matches inference preprocessing.
    - train_transform: optional augmentation controlled by augment/augment_level.
    - overlay_tfm (optional): MediaPipe overlay transform inserted BEFORE augmentation/resize.
    """
    image_size = int(image_size)
    augment_level = str(augment_level or "light").strip().lower()
    if bool(augment) and augment_level == "none":
        augment_level = "light"

    test_steps = []
    if overlay_tfm is not None:
        test_steps.append(overlay_tfm)
    test_steps.extend(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )
    test_transform = transforms.Compose(test_steps)

    if augment_level == "none":
        return test_transform, test_transform

    if augment_level == "strong":
        train_steps = []
        if overlay_tfm is not None:
            train_steps.append(overlay_tfm)
        train_steps.extend(
            [
                transforms.RandomResizedCrop(int(image_size), scale=(0.7, 1.0), ratio=(0.85, 1.18)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=15),
                transforms.ColorJitter(brightness=0.30, contrast=0.30, saturation=0.20, hue=0.08),
                transforms.RandomApply([transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0))], p=0.35),
                transforms.RandomAffine(
                    degrees=0,
                    translate=(0.10, 0.10),
                    scale=(0.90, 1.10),
                    shear=(-6, 6),
                ),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                transforms.RandomErasing(p=0.25, scale=(0.02, 0.15), ratio=(0.3, 3.3), value="random"),
            ]
        )
        return transforms.Compose(train_steps), test_transform

    # light (default)
    train_steps = []
    if overlay_tfm is not None:
        train_steps.append(overlay_tfm)
    train_steps.extend(
        [
            transforms.Resize((image_size, image_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(degrees=10),
            transforms.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.15, hue=0.03),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )
    return transforms.Compose(train_steps), test_transform


def resolve_training_device(force_cpu: bool) -> torch.device:
    """Prefer GPU (CUDA / MPS); refuse CPU unless ``force_cpu``."""
    if force_cpu:
        return torch.device("cpu")
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
        return torch.device("mps")
    raise RuntimeError(
        "未检测到可用的 GPU（CUDA 或 Apple MPS）。请安装 CUDA 版 PyTorch 与显卡驱动后再运行；"
        "若仅需在 CPU 上调试，请添加命令行参数 --cpu。"
    )


def stratified_split(labels: np.ndarray, test_ratio: float, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    all_indices = np.arange(len(labels), dtype=np.int64)
    train_idx: List[int] = []
    test_idx: List[int] = []
    for class_id in np.unique(labels):
        cls_indices = all_indices[labels == class_id]
        rng.shuffle(cls_indices)
        n = len(cls_indices)
        if n == 1:
            train_idx.append(int(cls_indices[0]))
            continue
        n_test = max(1, int(n * test_ratio))
        if n_test >= n:
            n_test = n - 1
        test_idx.extend(cls_indices[:n_test].tolist())
        train_idx.extend(cls_indices[n_test:].tolist())
    rng.shuffle(train_idx)
    rng.shuffle(test_idx)
    return np.array(train_idx, dtype=np.int64), np.array(test_idx, dtype=np.int64)


def stratified_subsample(indices: np.ndarray, labels: np.ndarray, ratio: float, seed: int) -> np.ndarray:
    """
    Stratified subsample of `indices` according to `labels`.
    Keeps at least 1 sample per present class when ratio > 0.
    """
    ratio = float(ratio)
    if ratio >= 1.0:
        return indices
    if ratio <= 0.0:
        raise ValueError("--train_subset_ratio must be > 0")

    rng = np.random.default_rng(seed)
    indices = np.asarray(indices, dtype=np.int64)
    chosen: List[int] = []
    sub_labels = labels[indices]
    for class_id in np.unique(sub_labels):
        cls_idx = indices[sub_labels == class_id]
        rng.shuffle(cls_idx)
        n = len(cls_idx)
        k = max(1, int(round(n * ratio)))
        k = min(k, n)
        chosen.extend(cls_idx[:k].tolist())
    rng.shuffle(chosen)
    return np.asarray(chosen, dtype=np.int64)


def stratified_cap_per_class(indices: np.ndarray, labels: np.ndarray, max_per_class: int, seed: int) -> np.ndarray:
    """
    Cap samples per class (stratified), keeping at most `max_per_class` per present class.
    """
    max_per_class = int(max_per_class)
    if max_per_class <= 0:
        return np.asarray(indices, dtype=np.int64)
    rng = np.random.default_rng(seed)
    indices = np.asarray(indices, dtype=np.int64)
    chosen: List[int] = []
    sub_labels = labels[indices]
    for class_id in np.unique(sub_labels):
        cls_idx = indices[sub_labels == class_id]
        rng.shuffle(cls_idx)
        k = min(int(max_per_class), int(len(cls_idx)))
        chosen.extend(cls_idx[:k].tolist())
    rng.shuffle(chosen)
    return np.asarray(chosen, dtype=np.int64)


ArchName = Literal["resnet18", "resnet50", "efficientnet_b0"]


def build_model(num_classes: int, pretrained: bool, arch: str = "resnet18") -> nn.Module:
    arch = str(arch).strip().lower()
    if arch not in {"resnet18", "resnet50", "efficientnet_b0"}:
        raise ValueError(f"Unsupported --arch {arch!r}. Choose from: resnet18, resnet50, efficientnet_b0")

    if arch == "resnet18":
        if pretrained:
            try:
                model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
            except Exception as e:
                print(f"WARN: failed to load pretrained ResNet18 weights, falling back to random init. Reason: {e}")
                model = models.resnet18(weights=None)
        else:
            model = models.resnet18(weights=None)
        in_features = model.fc.in_features
        model.fc = nn.Linear(in_features, num_classes)
        return model

    if arch == "resnet50":
        if pretrained:
            try:
                model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
            except Exception as e:
                print(f"WARN: failed to load pretrained ResNet50 weights, falling back to random init. Reason: {e}")
                model = models.resnet50(weights=None)
        else:
            model = models.resnet50(weights=None)
        in_features = model.fc.in_features
        model.fc = nn.Linear(in_features, num_classes)
        return model

    # efficientnet_b0
    if pretrained:
        try:
            model = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT)
        except Exception as e:
            print(f"WARN: failed to load pretrained EfficientNet_B0 weights, falling back to random init. Reason: {e}")
            model = models.efficientnet_b0(weights=None)
    else:
        model = models.efficientnet_b0(weights=None)
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = nn.Linear(in_features, num_classes)
    return model


def _one_train_step_for_oom_probe(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: AdamW,
    device: torch.device,
    use_amp: bool,
    scaler: GradScaler | None,
    non_blocking: bool,
) -> None:
    model.train(True)
    amp_ok = bool(use_amp) and device.type == "cuda"
    amp_ctx = autocast if amp_ok else nullcontext
    it = iter(loader)
    x, y = next(it)
    x = x.to(device, non_blocking=bool(non_blocking))
    y = y.to(device, non_blocking=bool(non_blocking))
    optimizer.zero_grad(set_to_none=True)
    with amp_ctx():
        logits = model(x)
        loss = criterion(logits, y)
    if amp_ok and scaler is not None:
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
    else:
        loss.backward()
        optimizer.step()


def autotune_batch_size_for_vram(
    *,
    make_loader,
    make_model,
    make_optimizer,
    criterion: nn.Module,
    device: torch.device,
    use_amp: bool,
    scaler: GradScaler | None,
    non_blocking: bool,
    target_gb: float,
    min_bs: int,
    max_bs: int,
) -> int:
    """
    Probe GPU memory by running one real train step and picking the largest batch_size
    that does not OOM while staying close to target_gb (soft target).
    """
    if device.type != "cuda":
        return int(min_bs)
    if target_gb <= 0:
        return int(min_bs)
    min_bs = max(1, int(min_bs))
    max_bs = max(min_bs, int(max_bs))

    def try_bs(bs: int) -> Tuple[bool, float]:
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        model = make_model().to(device)
        optimizer = make_optimizer(model)
        loader = make_loader(bs)
        try:
            _one_train_step_for_oom_probe(
                model=model,
                loader=loader,
                criterion=criterion,
                optimizer=optimizer,
                device=device,
                use_amp=use_amp,
                scaler=scaler,
                non_blocking=non_blocking,
            )
            torch.cuda.synchronize()
            peak = float(torch.cuda.max_memory_allocated())
            return True, peak
        except RuntimeError as e:
            msg = str(e).lower()
            if "out of memory" in msg or "cuda out of memory" in msg:
                return False, 0.0
            raise
        finally:
            # Try to release as much as possible before next probe.
            del loader, optimizer, model
            torch.cuda.empty_cache()

    target_bytes = float(target_gb) * 1024**3
    # First find an upper bound that OOMs (or hits max_bs).
    last_ok = min_bs
    last_ok_peak = 0.0
    bs = min_bs
    while True:
        ok, peak = try_bs(bs)
        if not ok:
            break
        last_ok = bs
        last_ok_peak = peak
        if bs >= max_bs:
            break
        bs = min(max_bs, bs * 2)

    # If we OOM at min_bs, just return min_bs.
    if last_ok == min_bs and last_ok_peak == 0.0:
        print("WARN: even min batch_size probe OOM; keeping batch_size as-is.")
        return int(min_bs)

    # If we never OOM, keep the largest we tried.
    if bs == last_ok and last_ok >= max_bs:
        return int(last_ok)

    # Binary search between last_ok and first_fail (bs).
    lo = last_ok
    hi = max(lo + 1, bs)
    best = lo
    best_peak = last_ok_peak
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        ok, peak = try_bs(mid)
        if ok:
            lo = mid
            best = mid
            best_peak = peak
        else:
            hi = mid

    # Soft target: if we are far below target, keep best anyway.
    # If best is above target (rare), also keep best because it's still safe (no OOM).
    print(
        f"Auto batch_size selected: {best} | "
        f"peak_alloc={best_peak/1024**3:.2f}GB | target={target_gb:.2f}GB"
    )
    return int(best)


class FilenamePrefixDataset(Dataset):
    """Images under root (recursive). Class = first segment of filename stem before separator (default '_')."""

    def __init__(self, root: Path, transform, sep: str = "_") -> None:
        self.root = root
        self.transform = transform
        self.sep = sep
        self.paths: List[Path] = []
        for p in root.rglob("*"):
            if p.is_file() and p.suffix.lower() in _IMAGE_EXTS_LOWER:
                self.paths.append(p)
        self.paths.sort(key=lambda x: str(x))
        if not self.paths:
            raise RuntimeError(f"No images found under {root}")

        raw_labels: List[str] = []
        for p in self.paths:
            stem = p.stem
            if sep not in stem:
                raise RuntimeError(
                    f"文件名需包含分隔符 {sep!r}，类别为分隔符前一段，例如 手语词A_001.jpg。当前文件: {p}"
                )
            raw_labels.append(stem.split(sep, 1)[0].strip())
        if any(not x for x in raw_labels):
            raise RuntimeError("类别前缀不能为空（分隔符前必须有类别名）。")

        classes = sorted(set(raw_labels))
        self.class_to_idx = {c: i for i, c in enumerate(classes)}
        self.classes = classes
        self.targets = [self.class_to_idx[x] for x in raw_labels]

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int):
        path = self.paths[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.targets[idx]


class GlossCsvImageDataset(Dataset):
    """
    图片与 gloss.csv 对齐：从文件名解析 Gloss ID（见 glossary.parse_gloss_id_from_filename），
    仅保留词表中存在的 ID。类别索引按「数据集中出现的 ID」重新编号 0..C-1。
    """

    def __init__(self, root: Path, transform, gloss_csv: Path) -> None:
        from glossary import load_gloss_by_int, parse_gloss_id_from_filename

        self.root = root
        self.transform = transform
        valid = set(load_gloss_by_int(gloss_csv).keys())
        self.paths: List[Path] = []
        raw_ids: List[int] = []
        bad: List[str] = []
        for p in root.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in _IMAGE_EXTS_LOWER:
                continue
            gid = parse_gloss_id_from_filename(p.name, valid)
            if gid < 0 or gid not in valid:
                bad.append(str(p))
                continue
            self.paths.append(p)
            raw_ids.append(gid)
        if bad:
            preview = "\n".join(bad[:12])
            raise RuntimeError(
                "以下文件无法对应 gloss.csv 中的有效 Gloss ID（请用 0042_说明.jpg 等形式命名）：\n"
                f"{preview}"
                + (f"\n... 共 {len(bad)} 个" if len(bad) > 12 else "")
            )
        if not self.paths:
            raise RuntimeError(f"在 {root} 下未找到与 gloss.csv 对齐的图片。")
        present = sorted(set(raw_ids))
        if len(present) < 2:
            raise RuntimeError(
                f"gloss_csv 布局下至少需要 2 个不同 Gloss ID，当前仅有: {present}。"
            )
        self.classes = [str(k) for k in present]
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        self.targets = [self.class_to_idx[str(g)] for g in raw_ids]

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int):
        path = self.paths[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.targets[idx]


class GlossIdFolderImageDataset(Dataset):
    """
    Recursively scan images under root, and label each image by the nearest parent folder
    that looks like a 4-digit Gloss ID (e.g. .../front/0002/00017.jpg -> label "0002").

    This matches datasets organized as:
      Pics/Participant_XX/Participant_XX/<view>/<gloss_id>/<frame>.jpg

    It intentionally ignores Participant folder names, so classes become gloss IDs.
    """

    def __init__(self, root: Path, transform, restrict_gloss_ids: Optional[set[str]] = None) -> None:
        self.root = root
        self.transform = transform
        self.paths: List[Path] = []
        raw_labels: List[str] = []

        def pick_gid(p: Path) -> str | None:
            for seg in p.parent.parts[::-1]:
                s = str(seg).strip()
                if len(s) == 4 and s.isdigit():
                    return s
            return None

        for p in root.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in _IMAGE_EXTS_LOWER:
                continue
            gid = pick_gid(p)
            if gid is None:
                continue
            self.paths.append(p)
            raw_labels.append(gid)

        if restrict_gloss_ids:
            rid = {str(x).zfill(4) for x in restrict_gloss_ids}
            fp: List[Path] = []
            rl: List[str] = []
            for p, g in zip(self.paths, raw_labels):
                if g in rid:
                    fp.append(p)
                    rl.append(g)
            self.paths, raw_labels = fp, rl

        if not self.paths:
            raise RuntimeError(
                f"在 {root} 下未找到包含 4 位数字文件夹(0000-9999)的图片。"
                "期望结构示例：Pics/Participant_01/Participant_01/front/0002/00017.jpg"
            )

        present = sorted(set(raw_labels))
        if len(present) < 2:
            raise RuntimeError(
                f"gloss_id_folder 模式下至少需要 2 个不同的 Gloss ID 文件夹，当前仅有: {present}。"
                + (f"（已应用 restrict_gloss_ids，请检查过滤条件是否过严）" if restrict_gloss_ids else "")
            )

        self.classes = present
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        self.targets = [self.class_to_idx[x] for x in raw_labels]

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int):
        path = self.paths[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.targets[idx]


def load_classification_dataset(
    data_root: Path,
    transform,
    layout: str,
    label_sep: str,
    gloss_csv: Optional[Path] = None,
    restrict_gloss_ids: Optional[set[str]] = None,
) -> Tuple[Dataset, str]:
    """Returns (dataset, mode) where mode is 'imagefolder' | 'filename_prefix' | 'gloss_csv'."""
    if layout == "gloss_id_folder":
        ds = GlossIdFolderImageDataset(data_root, transform, restrict_gloss_ids=restrict_gloss_ids)
        return ds, "gloss_id_folder"

    if layout == "gloss_csv":
        if gloss_csv is None or not gloss_csv.is_file():
            raise RuntimeError("使用 --layout gloss_csv 时必须提供有效的 --gloss_csv 路径。")
        ds = GlossCsvImageDataset(data_root, transform, gloss_csv)
        return ds, "gloss_csv"

    if layout == "filename_prefix":
        ds = FilenamePrefixDataset(data_root, transform, sep=label_sep)
        if len(ds.classes) < 2:
            raise RuntimeError(
                f"按文件名解析后只有 {len(ds.classes)} 个类别，至少需要 2 个不同类别前缀。"
            )
        return ds, "filename_prefix"

    if layout == "imagefolder":
        ds = datasets.ImageFolder(root=str(data_root), transform=transform)
        if len(ds) == 0:
            raise RuntimeError(f"在 {data_root} 下未找到图片。请使用 类别名/图片 两级目录。")
        if len(ds.classes) < 2:
            raise RuntimeError(
                "ImageFolder 模式下至少需要 2 个类别子文件夹，例如 Pics/类A/、Pics/类B/。\n"
                "若所有图片在同一文件夹，请改用: --layout filename_prefix，"
                "并将文件命名为「类别_任意.jpg」（类别为下划线前一段）。"
            )
        return ds, "imagefolder"

    # layout == auto
    # IMPORTANT: In this project, Pics is often organized as:
    #   Pics/Participant_XX/Participant_XX/front/0002/00017.jpg
    # In that case, ImageFolder would incorrectly treat Participant_XX as class labels.
    # So for auto mode, we try gloss_id_folder FIRST, then fall back to ImageFolder.
    # Try gloss id folders if present (e.g. .../0002/00017.jpg).
    try:
        ds_gid = GlossIdFolderImageDataset(data_root, transform, restrict_gloss_ids=restrict_gloss_ids)
        return ds_gid, "gloss_id_folder"
    except RuntimeError:
        pass

    ds_if = datasets.ImageFolder(root=str(data_root), transform=transform)
    if len(ds_if) > 0 and len(ds_if.classes) >= 2:
        return ds_if, "imagefolder"

    if gloss_csv is not None and gloss_csv.is_file():
        try:
            ds_g = GlossCsvImageDataset(data_root, transform, gloss_csv)
            return ds_g, "gloss_csv"
        except RuntimeError:
            pass

    try:
        ds_fn = FilenamePrefixDataset(data_root, transform, sep=label_sep)
    except RuntimeError as e:
        raise RuntimeError(
            "无法加载数据集。\n"
            "方式一：在 Pics 下建多个子文件夹，每个文件夹一类，例如 Pics/类A/*.jpg、Pics/类B/*.jpg。\n"
            "方式二：图片可放在任意子目录，文件名用「类别_说明.jpg」，并加参数 --layout filename_prefix。\n"
            f"原始错误: {e}"
        ) from e

    if len(ds_fn.classes) < 2:
        raise RuntimeError(
            f"当前仅解析到 {len(ds_fn.classes)} 个类别，多分类至少需要 2 个不同类别前缀或子文件夹。\n"
            "请增加另一类样本，或检查文件名/目录结构。"
        )
    return ds_fn, "filename_prefix"


def run_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: AdamW | None,
    device: torch.device,
    grad_clip_norm: float = 0.0,
    scaler: GradScaler | None = None,
    use_amp: bool = False,
    non_blocking: bool = False,
    semantic_ctx: dict | None = None,
    metric_ctx: dict | None = None,
) -> Dict[str, float]:
    is_train = optimizer is not None
    model.train(is_train)
    amp_ok = bool(use_amp) and device.type == "cuda"
    amp_ctx = autocast if amp_ok else nullcontext

    all_preds: List[np.ndarray] = []
    all_labels: List[np.ndarray] = []
    total_loss = 0.0

    for x, y in tqdm(loader, leave=False):
        x = x.to(device, non_blocking=bool(non_blocking))
        y = y.to(device, non_blocking=bool(non_blocking))

        with torch.set_grad_enabled(is_train):
            with amp_ctx():
                if metric_ctx is not None:
                    logits, emb = model(x)
                    if bool(metric_ctx.get("normalize", True)):
                        emb = torch.nn.functional.normalize(emb, p=2.0, dim=1)
                else:
                    logits = model(x)
                if semantic_ctx is not None:
                    loss = semantic_soft_ce_loss(
                        logits,
                        y,
                        class_vecs=semantic_ctx["class_vecs"],
                        alpha=float(semantic_ctx["alpha"]),
                        tau=float(semantic_ctx["tau"]),
                        topk=int(semantic_ctx["topk"]),
                    )
                else:
                    loss = criterion(logits, y)
                if metric_ctx is not None:
                    t_loss = batch_hard_triplet_loss(emb, y, margin=float(metric_ctx["margin"]))
                    loss = loss + float(metric_ctx["lambda"]) * t_loss
            if is_train:
                optimizer.zero_grad()
                if amp_ok and scaler is not None:
                    scaler.scale(loss).backward()
                    if grad_clip_norm and grad_clip_norm > 0:
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(grad_clip_norm))
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    loss.backward()
                    if grad_clip_norm and grad_clip_norm > 0:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(grad_clip_norm))
                    optimizer.step()

        total_loss += loss.item() * x.size(0)
        all_preds.append(logits.argmax(dim=1).detach().cpu().numpy())
        all_labels.append(y.detach().cpu().numpy())

    preds = np.concatenate(all_preds)
    labels = np.concatenate(all_labels)
    acc = float((labels == preds).mean())
    avg_loss = total_loss / len(loader.dataset)
    return {"loss": avg_loss, "acc": acc}


def gather_predictions_eval(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    *,
    use_amp: bool = False,
    non_blocking: bool = False,
    metric_ctx: dict | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """测试集上收集 argmax 预测，用于混淆矩阵（与 run_epoch 前向一致，不计 loss）。"""
    model.eval()
    amp_ok = bool(use_amp) and device.type == "cuda"
    amp_ctx = autocast if amp_ok else nullcontext
    all_preds: List[np.ndarray] = []
    all_labels: List[np.ndarray] = []
    with torch.no_grad():
        for x, y in tqdm(loader, leave=False, desc="confusion_diag"):
            x = x.to(device, non_blocking=bool(non_blocking))
            y = y.to(device, non_blocking=bool(non_blocking))
            with amp_ctx():
                if metric_ctx is not None:
                    logits, _emb = model(x)
                else:
                    logits = model(x)
            all_preds.append(logits.argmax(dim=1).detach().cpu().numpy())
            all_labels.append(y.detach().cpu().numpy())
    return np.concatenate(all_labels), np.concatenate(all_preds)


def print_first_batch_diagnostic(
    model: nn.Module,
    test_loader: DataLoader,
    device: torch.device,
    num_classes: int,
    use_amp: bool,
) -> None:
    """打印测试集首个 batch：标签与未训练模型的预测（用于排查标签错位、形状错误）。"""
    model.eval()
    x, y = next(iter(test_loader))
    x = x.to(device, non_blocking=False)
    y = y.to(device, non_blocking=False)
    amp_ok = bool(use_amp) and device.type == "cuda"
    amp_ctx = autocast if amp_ok else nullcontext
    with torch.no_grad():
        with amp_ctx():
            logits = model(x)
    preds = logits.argmax(dim=1)
    probs = torch.softmax(logits.float(), dim=1)
    print("--- diagnostic_first_batch (test_loader, 未经训练模型) ---")
    print("batch 内真实标签前16个:", y[:16].detach().cpu().numpy().tolist())
    print("batch 内 argmax 预测前16个:", preds[:16].detach().cpu().numpy().tolist())
    print("标签 min/max（应落在 [0, num_classes-1]）:", int(y.min().item()), int(y.max().item()))
    print("softmax 最大概率均值:", float(probs.max(dim=1).values.mean().item()))
    bc = torch.bincount(preds.cpu(), minlength=int(num_classes))
    nz_items = [(int(i), int(bc[i])) for i in range(int(num_classes)) if int(bc[i]) > 0]
    if len(nz_items) <= 14:
        print("预测类别频次(非零):", dict(nz_items))
    else:
        print("预测类别频次(非零, 仅显示前14):", dict(nz_items[:14]), f"... 共 {len(nz_items)} 类有位")
    print("--- end diagnostic ---")


def _default_data_root() -> str:
    """
    Prefer env override so deployments don't rely on hardcoded paths.

    On Windows (local dev), default to a nearby ``Pics`` folder under/above this script.
    On Linux servers/containers, fall back to /data/ccc/... if env is not set.
    """
    env = os.environ.get("SIGN_LANGUAGE_DATA_ROOT")
    if env and str(env).strip():
        return str(env).strip()

    # Local Windows: try to find a sibling/parent Pics folder.
    try:
        if sys.platform.startswith("win"):
            base_dir = Path(__file__).resolve().parent
            for parent in [base_dir, *list(base_dir.parents)[:8]]:
                cand = parent / "Pics"
                if cand.is_dir():
                    return str(cand)
    except Exception:
        pass

    # Server default (Linux containers / remote training)
    return "/data/ccc/27261843/Pics"


def main() -> None:
    parser = argparse.ArgumentParser(description="Train image classifier from Pics folder")
    parser.add_argument(
        "--data_root",
        type=str,
        default=_default_data_root(),
        help="图片根目录（ImageFolder：类别名/图片）。默认 /data/ccc/27261843/Pics；"
        "也可用环境变量 SIGN_LANGUAGE_DATA_ROOT 或命令行 --data_root 覆盖。",
    )
    parser.add_argument("--epochs", type=int, default=5, help="训练轮数（默认 5；与 --resume 配合时从断点继续跑到该目标 epoch）")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--test_ratio", type=float, default=0.2)
    parser.add_argument(
        "--split",
        type=str,
        default="group",
        choices=["stratified", "group"],
        help="数据划分方式：stratified=随机分层；group=按参与者/视频目录分组划分（避免数据泄露，推荐）",
    )
    parser.add_argument(
        "--train_subset_ratio",
        type=float,
        default=1.0,
        help="仅使用训练集的一部分进行训练（0~1]，例如 0.1 表示用 10% 训练数据；分层采样保证各类尽量保留",
    )
    parser.add_argument(
        "--max_samples",
        type=int,
        default=0,
        help="训练前对全数据集做上限裁剪：最多使用 N 张图片（0=不限制；会尽量保持类别分布）。",
    )
    parser.add_argument(
        "--max_per_class",
        type=int,
        default=0,
        help="训练前对全数据集做每类上限裁剪：每个类别最多保留 N 张（0=不限制）。",
    )
    parser.add_argument("--image_size", type=int, default=224)
    parser.add_argument("--overlay_kp", action="store_true", help="训练/测试图片先叠加 MediaPipe 手部关键点（会显著变慢；用于训练“带骨架”的图像模型）")
    parser.add_argument("--overlay_pose", action="store_true", help="配合 --overlay_kp：额外叠加 pose 骨架")
    parser.add_argument("--overlay_face_box", action="store_true", help="配合 --overlay_kp：额外画 face bbox")
    parser.add_argument("--overlay_prob", type=float, default=1.0, help="叠加关键点的概率(0-1)，默认1=每张都叠加")
    parser.add_argument(
        "--augment",
        action="store_true",
        help="启用训练集数据增强（测试集不增强）。建议开启以提升泛化并抑制过拟合/泄露幻象。",
    )
    parser.add_argument(
        "--augment_level",
        type=str,
        default="light",
        choices=["none", "light", "strong"],
        help=(
            "数据增强强度：none=关闭；light=轻增强（默认，亦可用旧参数 --augment 开启）；"
            "strong=强增强（更贴近真实摄像头：RandomResizedCrop/Blur/Affine/Erasing）。"
        ),
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument(
        "--arch",
        type=str,
        default="resnet18",
        choices=["resnet18", "resnet50", "efficientnet_b0"],
        help="模型结构。更大模型更吃显存/更慢，但通常效果更好",
    )
    parser.add_argument("--label_smoothing", type=float, default=0.0, help="CrossEntropy label smoothing (0=off)")
    parser.add_argument("--semantic_soft_labels", action="store_true", help="启用语义知识软标签（缓解相似手势混淆）")
    parser.add_argument("--semantic_alpha", type=float, default=0.25, help="语义软标签强度 alpha (0=纯硬标签, 1=纯软标签)")
    parser.add_argument("--semantic_tau", type=float, default=0.25, help="语义相似度 softmax 温度 tau（越小越尖锐）")
    parser.add_argument("--semantic_topk", type=int, default=32, help="每个标签取 Top-K 语义邻居参与软标签")
    parser.add_argument(
        "--semantic_text_source",
        type=str,
        default="both",
        choices=["zh", "en", "both", "label"],
        help="语义向量文本来源：zh/en/both(默认)/label(仅用类别名)",
    )
    parser.add_argument("--semantic_dim", type=int, default=256, help="语义哈希向量维度（越大越精细，越耗显存）")
    # Scheme 2: metric learning (CE + Triplet)
    parser.add_argument("--metric_learning", action="store_true", help="启用方案二：CE + batch-hard TripletLoss（度量学习）")
    parser.add_argument("--embed_dim", type=int, default=256, help="度量学习 embedding 维度")
    parser.add_argument("--triplet_margin", type=float, default=0.20, help="Triplet margin")
    parser.add_argument("--triplet_lambda", type=float, default=0.20, help="Triplet loss 权重 lambda")
    parser.add_argument("--triplet_normalize", action="store_true", help="对 embedding 做 L2 normalize（推荐）")
    parser.add_argument(
        "--scheduler",
        type=str,
        default="cosine",
        choices=["none", "plateau", "cosine"],
        help="LR scheduler: plateau uses ReduceLROnPlateau on test loss; cosine uses CosineAnnealingLR",
    )
    parser.add_argument(
        "--class_weight",
        type=str,
        default="none",
        choices=["none", "balanced"],
        help=(
            "CrossEntropy 类别权重：none=不加权；balanced=按训练集类别频次的倒数加权。"
            "（适合类别不均衡时；会改变最优阈值/置信度分布）"
        ),
    )
    parser.add_argument("--min_lr", type=float, default=1e-6, help="plateau: min lr; cosine: eta_min")
    parser.add_argument("--plateau_factor", type=float, default=0.5, help="ReduceLROnPlateau factor")
    parser.add_argument("--plateau_patience", type=int, default=3, help="ReduceLROnPlateau patience (epochs)")
    parser.add_argument("--grad_clip_norm", type=float, default=0.0, help="Clip grad norm (0=off)")
    parser.add_argument("--early_stop_patience", type=int, default=10, help="Stop if no test acc improve for N epochs (0=off)")
    parser.add_argument("--early_stop_min_delta", type=float, default=0.0, help="Min test acc delta to count as improvement")
    parser.add_argument(
        "--layout",
        type=str,
        default="auto",
        choices=["auto", "imagefolder", "filename_prefix", "gloss_csv", "gloss_id_folder"],
        help=(
            "auto: 优先 ImageFolder；若检测到 4 位数字 GlossID 文件夹(0000-9999)则使用 gloss_id_folder；"
            "若提供 --gloss_csv 可尝试按 Gloss ID 文件名；否则按文件名前缀"
        ),
    )
    parser.add_argument(
        "--gloss_csv",
        type=str,
        default="../gloss.csv",
        help="layout 为 gloss_csv 或 auto 尝试 gloss 对齐时使用（默认上级目录 gloss.csv）",
    )
    parser.add_argument(
        "--label_sep",
        type=str,
        default="_",
        help="filename_prefix 模式下，类别为文件名中第一个分隔符前的部分",
    )
    parser.add_argument(
        "--restrict_gloss_ids",
        type=str,
        default="",
        help="仅保留这些 4 位 gloss id（逗号分隔，或 @ids.txt）；仅 gloss_id_folder / auto 走 gloss 目录时生效；用于只训练 extract 十句子集等",
    )
    parser.add_argument("--output_dir", type=str, default="outputs/image")
    parser.add_argument("--run_name", type=str, default=None, help="子目录名；默认 run_YYYY-mm-dd_HHMMSS")
    parser.add_argument("--flat_output", action="store_true", help="直接写入 output_dir，不建时间戳子目录")
    parser.add_argument("--resume", type=str, default=None, help="从 checkpoint_last.pt 续训")
    parser.add_argument("--epoch_ckpt_every", type=int, default=0, help="每 N epoch 保存 epoch_weights_epoch_NNN.pt")
    parser.add_argument("--auto_report", action="store_true", help="训练结束后自动生成 reports/ 图+表")
    parser.add_argument(
        "--reports_dir",
        type=str,
        default="reports",
        help="auto_report 输出目录（相对当前脚本目录；支持 Windows/Linux 路径分隔符）",
    )
    parser.add_argument("--report_limit", type=int, default=20, help="auto_report 仅汇总最近 N 个 runs（0=全部）")
    parser.add_argument(
        "--write_runs_index",
        action="store_true",
        help="在 output 根目录追加 training_runs_index.jsonl（默认关闭）",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="强制使用 CPU（默认在无 GPU 时报错退出，不进行 CPU 训练）",
    )
    parser.add_argument(
        "--amp",
        action="store_true",
        help="启用 CUDA 自动混合精度训练（AMP）；仅在有 CUDA 时生效",
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=0,
        help="DataLoader worker 数量（默认 0，主进程加载）",
    )
    parser.add_argument(
        "--diagnostic_first_batch",
        action="store_true",
        help="训练前打印测试集首个 batch：标签范围、随机初始权重的预测 argmax 分布（用于排查标签/形状问题）",
    )
    parser.add_argument(
        "--save_confusion_diag",
        action="store_true",
        help="训练结束后加载 best_image_model.pt，在测试划分上导出混淆矩阵 PNG/CSV 与 confusion_report.txt",
    )
    # Python < 3.9: argparse.BooleanOptionalAction doesn't exist.
    _bool_opt = getattr(argparse, "BooleanOptionalAction", None)
    if _bool_opt is not None:
        parser.add_argument(
            "--pin_memory",
            action=_bool_opt,
            default=True,
            help="CUDA 时 DataLoader 是否 pin_memory（默认开启；可用 --no-pin_memory 关闭）",
        )
    else:
        parser.add_argument(
            "--pin_memory",
            dest="pin_memory",
            action="store_true",
            default=True,
            help="CUDA 时 DataLoader 是否 pin_memory（默认开启；旧版 Python 兼容）",
        )
        parser.add_argument(
            "--no-pin_memory",
            dest="pin_memory",
            action="store_false",
            help="关闭 DataLoader pin_memory（旧版 Python 兼容）",
        )
    parser.add_argument(
        "--auto_batch_target_gb",
        type=float,
        default=0.0,
        help="CUDA 上自动试探 batch_size，使显存峰值接近该值（单位 GB；0=关闭）",
    )
    parser.add_argument(
        "--auto_batch_max",
        type=int,
        default=4096,
        help="auto_batch 的 batch_size 上限（防止试探过大）",
    )
    parser.add_argument(
        "--reserve_vram_gb",
        type=float,
        default=0.0,
        help="仅为占用显存：在 CUDA 上预留 N GB 显存（不会加速训练；0=关闭）",
    )
    args = parser.parse_args()

    set_seed(args.seed)
    base_dir = Path(__file__).resolve().parent
    restrict_ids = parse_restrict_gloss_ids(str(getattr(args, "restrict_gloss_ids", "") or ""), base_dir)
    data_root = resolve_cli_path(base_dir, args.data_root)
    output_base = resolve_cli_path(base_dir, args.output_dir)
    resume_p = resolve_resume_path(base_dir, args.resume) if args.resume else None
    run_dir, run_label = resolve_run_dir(output_base, args.run_name, args.flat_output, resume_p)
    gloss_csv = resolve_cli_path(base_dir, args.gloss_csv) if args.gloss_csv else None

    # Make sure the training log records the *resolved* real paths (Windows/Linux),
    # so users can verify we are training on the intended dataset.
    args.data_root = str(data_root)
    args.output_dir = str(output_base)
    if gloss_csv is not None:
        args.gloss_csv = str(gloss_csv)

    init_train_log(run_dir, args, "train_image.py", run_label)
    append_training_run_index(
        output_base,
        run_label,
        run_dir,
        append=should_append_run_index(resume_p, args.run_name, run_dir),
        enabled=bool(args.write_runs_index),
    )
    if not data_root.exists():
        # Cross-platform fallback search (Windows/Linux): try a few common locations.
        candidates: list[Path] = []
        # 1) Walk up from current script folder: <parent>/Pics
        try:
            for parent in [base_dir, *list(base_dir.parents)[:6]]:
                candidates.append(parent / "Pics")
        except Exception:
            pass
        # 2) Also try current working directory / Pics (common when launching from repo root)
        try:
            candidates.append(Path.cwd() / "Pics")
        except Exception:
            pass
        # 3) Linux container defaults (kept for compatibility)
        candidates.extend([Path("/data/ccc/27261843/Pics"), Path("/data/ccc/27262843/Pics")])
        # de-dup while preserving order
        seen = set()
        uniq: list[Path] = []
        for c in candidates:
            s = str(c)
            if s in seen:
                continue
            seen.add(s)
            uniq.append(c)
        candidates = uniq
        picked: Path | None = None
        for c in candidates:
            try:
                if c.exists() and _looks_like_image_root(c):
                    picked = c.resolve()
                    break
            except Exception:
                continue
        if picked is not None:
            print(f"WARN: 配置的 data_root 不存在：{data_root!s}")
            print(f"WARN: 改用自动探测到的 Pics: {picked!s}")
            data_root = picked
        else:
            tried = "\n".join([f"  - {p!s}" for p in [data_root, *candidates]])
            raise FileNotFoundError(
                f"Pics directory not found: {data_root}\n"
                f"已尝试以下候选路径：\n{tried}\n"
                f"请任选其一：\n"
                f"  1) 确认 Pics 目录存在且容器内可见；\n"
                f"  2) 运行时指定实际路径，例如: --data_root /path/to/your/Pics\n"
                f"  3) 设置环境变量 SIGN_LANGUAGE_DATA_ROOT=/path/to/your/Pics\n"
                f"当前脚本目录: {base_dir}"
            )

    overlay_tfm = None
    if bool(getattr(args, "overlay_kp", False)):
        overlay_tfm = MediaPipeOverlayTransform(
            draw_pose=bool(getattr(args, "overlay_pose", False)),
            draw_face_box=bool(getattr(args, "overlay_face_box", False)),
            prob=float(getattr(args, "overlay_prob", 1.0)),
        )
        print(
            "WARN: overlay_kp=ON（MediaPipe 叠加关键点）会显著减慢训练与数据加载；"
            "建议先用小数据/小 epoch 验证效果。"
        )

    train_transform, test_transform = get_transforms(
        image_size=int(args.image_size),
        augment=bool(args.augment),
        augment_level=str(getattr(args, "augment_level", "light")),
        overlay_tfm=overlay_tfm,
    )

    dataset, layout_used = load_classification_dataset(
        data_root,
        test_transform,
        layout=args.layout,
        label_sep=args.label_sep,
        gloss_csv=gloss_csv,
        restrict_gloss_ids=restrict_ids,
    )
    # High-signal sanity prints: confirm label mode is NOT participant folders.
    try:
        preview_classes = list(getattr(dataset, "classes", []))[:12]
        if preview_classes:
            print(f"Dataset mode: {layout_used} | class_preview={preview_classes}")
    except Exception:
        pass
    paths, targets = extract_paths_targets_from_dataset(dataset)
    labels = np.asarray(targets, dtype=np.int64)

    # Optional: cap full dataset size before split (useful when dataset is huge).
    all_idx = np.arange(len(labels), dtype=np.int64)
    if int(args.max_per_class) > 0:
        before = int(len(all_idx))
        all_idx = stratified_cap_per_class(all_idx, labels=labels, max_per_class=int(args.max_per_class), seed=int(args.seed))
        print(f"WARN: max_per_class={int(args.max_per_class)} -> samples {before} -> {int(len(all_idx))}")
        paths = [paths[i] for i in all_idx.tolist()]
        targets = [targets[i] for i in all_idx.tolist()]
        labels = np.asarray(targets, dtype=np.int64)
        all_idx = np.arange(len(labels), dtype=np.int64)
    if int(args.max_samples) > 0 and int(args.max_samples) < int(len(all_idx)):
        before = int(len(all_idx))
        ratio = float(int(args.max_samples)) / float(max(1, before))
        all_idx = stratified_subsample(all_idx, labels=labels, ratio=ratio, seed=int(args.seed))
        # Exact cap: trim if needed.
        if int(len(all_idx)) > int(args.max_samples):
            all_idx = all_idx[: int(args.max_samples)]
        print(f"WARN: max_samples={int(args.max_samples)} -> samples {before} -> {int(len(all_idx))}")
        paths = [paths[i] for i in all_idx.tolist()]
        targets = [targets[i] for i in all_idx.tolist()]
        labels = np.asarray(targets, dtype=np.int64)

    split_used = str(args.split)
    if args.split == "group":
        if group_split_is_class_disjoint(paths, labels):
            print(
                "WARN: --split group 在当前路径下等价于「按 Gloss 文件夹分组」，会导致训练/测试类别互不重叠 "
                "(常见于 extract_dataset/front/<四位数字>/ 且无 Participant_* 路径)。"
                "已自动改用 stratified 划分。"
            )
            train_idx, test_idx = stratified_split(labels=labels, test_ratio=args.test_ratio, seed=args.seed)
            split_used = "stratified(auto_fallback_from_group)"
        else:
            train_idx, test_idx = group_split_indices(paths=paths, labels=labels, test_ratio=args.test_ratio, seed=args.seed)
    else:
        train_idx, test_idx = stratified_split(labels=labels, test_ratio=args.test_ratio, seed=args.seed)
    if len(train_idx) == 0 or len(test_idx) == 0:
        raise RuntimeError("Invalid split: train/test set is empty. Please add more images.")

    num_classes_ds = len(dataset.classes)
    tr_cls = set(np.unique(labels[train_idx]).tolist())
    te_cls = set(np.unique(labels[test_idx]).tolist())
    print(
        f"划分方式: {split_used} | "
        f"train 样本={len(train_idx)}, test 样本={len(test_idx)} | "
        f"train 覆盖类别={len(tr_cls)}/{num_classes_ds}, test 覆盖类别={len(te_cls)}/{num_classes_ds}"
    )
    only_in_test = sorted(te_cls - tr_cls)
    if only_in_test:
        preview = only_in_test[:24]
        extra = f" （共 {len(only_in_test)} 类）" if len(only_in_test) > 24 else ""
        print(f"WARN: 测试集中存在训练集中未出现的类别索引: {preview}{extra}")

    if float(args.train_subset_ratio) < 1.0:
        before = len(train_idx)
        train_idx = stratified_subsample(train_idx, labels=labels, ratio=float(args.train_subset_ratio), seed=args.seed)
        print(f"WARN: train_subset_ratio={float(args.train_subset_ratio):.3f} -> train samples {before} -> {len(train_idx)}")

    train_paths = [paths[i] for i in train_idx.tolist()]
    train_targets = [targets[i] for i in train_idx.tolist()]
    test_paths = [paths[i] for i in test_idx.tolist()]
    test_targets = [targets[i] for i in test_idx.tolist()]
    train_set = PathLabelDataset(train_paths, train_targets, transform=train_transform)
    test_set = PathLabelDataset(test_paths, test_targets, transform=test_transform)
    device = resolve_training_device(force_cpu=bool(args.cpu))
    pin_memory = bool(args.pin_memory) and device.type == "cuda"
    non_blocking = bool(pin_memory) and device.type == "cuda"
    if device.type == "cuda":
        try:
            torch.backends.cudnn.benchmark = True
        except Exception:
            pass
        try:
            torch.set_float32_matmul_precision("high")
        except Exception:
            pass
        print(
            "CUDA 可用: True | "
            f"GPU={torch.cuda.get_device_name(0)} | "
            f"torch={torch.__version__} | "
            f"torch.cuda={getattr(torch.version, 'cuda', None)}"
        )
    else:
        print(
            "CUDA 可用: False | "
            f"torch={torch.__version__} | "
            f"torch.cuda={getattr(torch.version, 'cuda', None)}"
        )

    # Optional: reserve VRAM so nvidia-smi shows higher usage.
    # This does NOT improve training speed; prefer increasing batch_size/image_size instead.
    _vram_reservation: torch.Tensor | None = None
    if device.type == "cuda" and float(args.reserve_vram_gb) > 0:
        want_bytes = int(float(args.reserve_vram_gb) * 1024**3)
        if want_bytes > 0:
            try:
                free_b, total_b = torch.cuda.mem_get_info()
                # Leave a safety margin to avoid OOM during the first forward/backward.
                safety = int(2 * 1024**3)  # 2GB
                alloc_bytes = max(0, min(want_bytes, max(0, int(free_b) - safety)))
                if alloc_bytes > 0:
                    _vram_reservation = torch.empty((alloc_bytes,), device=device, dtype=torch.uint8)
                    torch.cuda.synchronize()
                    print(f"Reserved VRAM: {alloc_bytes / 1024**3:.2f} GB (requested {float(args.reserve_vram_gb):.2f} GB)")
                else:
                    print(
                        "WARN: reserve_vram_gb requested but not enough free VRAM to reserve safely. "
                        f"free={free_b/1024**3:.2f}GB total={total_b/1024**3:.2f}GB"
                    )
            except RuntimeError as e:
                print(f"WARN: Failed to reserve VRAM (ignored): {e}")
    def _make_train_loader(bs: int) -> DataLoader:
        return DataLoader(
            train_set,
            batch_size=int(bs),
            shuffle=True,
            num_workers=max(0, int(args.num_workers)),
            pin_memory=pin_memory,
            persistent_workers=(int(args.num_workers) > 0),
            prefetch_factor=2 if int(args.num_workers) > 0 else None,
        )

    def _make_test_loader(bs: int) -> DataLoader:
        return DataLoader(
            test_set,
            batch_size=int(bs),
            shuffle=False,
            num_workers=max(0, int(args.num_workers)),
            pin_memory=pin_memory,
            persistent_workers=(int(args.num_workers) > 0),
            prefetch_factor=2 if int(args.num_workers) > 0 else None,
        )

    train_loader = _make_train_loader(int(args.batch_size))
    test_loader = _make_test_loader(int(args.batch_size))

    num_classes = len(dataset.classes)
    use_amp = bool(args.amp) and device.type == "cuda"
    scaler: GradScaler | None = GradScaler() if use_amp else None
    if args.amp and device.type != "cuda":
        print("WARN: --amp 仅在 CUDA 上启用；当前设备非 CUDA，已忽略 AMP。")
    print(f"训练设备: {device} ({'GPU' if device.type != 'cpu' else 'CPU'})" + (", AMP" if use_amp else ""))
    metric_ctx = None
    if bool(getattr(args, "metric_learning", False)):
        model = EmbeddingClassifier(
            arch=str(args.arch),
            num_classes=int(num_classes),
            pretrained=bool(args.pretrained),
            embed_dim=int(getattr(args, "embed_dim", 256)),
        ).to(device)
        metric_ctx = {
            "margin": float(getattr(args, "triplet_margin", 0.20)),
            "lambda": float(getattr(args, "triplet_lambda", 0.20)),
            "normalize": bool(getattr(args, "triplet_normalize", True)),
        }
        print(
            f"WARN: metric_learning=ON | embed_dim={int(getattr(args,'embed_dim',256))} "
            f"margin={metric_ctx['margin']:.3f} lambda={metric_ctx['lambda']:.3f} normalize={metric_ctx['normalize']}"
        )
    else:
        model = build_model(num_classes=num_classes, pretrained=args.pretrained, arch=args.arch).to(device)

    # Optional: semantic soft labels (build class vectors once, keep on device).
    semantic_ctx = None
    if bool(getattr(args, "semantic_soft_labels", False)):
        # Try to use gloss.csv mapping when classes are numeric IDs.
        gloss_for_sem = gloss_csv if (gloss_csv is not None and gloss_csv.is_file()) else None
        vec_np = build_semantic_class_vectors(
            classes=[str(c) for c in list(getattr(dataset, "classes", []))],
            gloss_csv=gloss_for_sem,
            dim=int(getattr(args, "semantic_dim", 256)),
            text_source=str(getattr(args, "semantic_text_source", "both")),
        )
        class_vecs = torch.from_numpy(vec_np).to(device=device, dtype=torch.float32)
        semantic_ctx = {
            "class_vecs": class_vecs,
            "alpha": float(getattr(args, "semantic_alpha", 0.25)),
            "tau": float(getattr(args, "semantic_tau", 0.25)),
            "topk": int(getattr(args, "semantic_topk", 32)),
        }
        print(
            f"WARN: semantic_soft_labels=ON | alpha={semantic_ctx['alpha']:.3f} "
            f"tau={semantic_ctx['tau']:.3f} topk={int(semantic_ctx['topk'])} dim={int(getattr(args,'semantic_dim',256))} "
            f"text={str(getattr(args,'semantic_text_source','both'))}"
        )

    # Optional: class-balanced weights from TRAIN split only (avoid peeking test).
    weight_t: torch.Tensor | None = None
    if str(getattr(args, "class_weight", "none")).strip().lower() == "balanced":
        y_tr = np.asarray(train_targets, dtype=np.int64)
        bc = np.bincount(y_tr, minlength=int(num_classes)).astype(np.float64)
        bc = np.maximum(bc, 1.0)
        w = (1.0 / bc)
        w = w / float(np.mean(w))  # normalize around 1.0 for stable loss scale
        weight_t = torch.tensor(w, dtype=torch.float32, device=device)
        # High-signal print (preview first 10 weights only)
        preview = [float(x) for x in w[: min(10, len(w))].tolist()]
        print(f"class_weight=balanced | weights_preview={preview}" + (" ..." if len(w) > 10 else ""))

    # If semantic soft labels enabled, criterion is still created for logging compatibility,
    # but the real loss is computed in run_epoch via semantic_ctx.
    try:
        criterion = nn.CrossEntropyLoss(weight=weight_t, label_smoothing=float(args.label_smoothing))
    except TypeError:
        criterion = nn.CrossEntropyLoss(weight=weight_t)

    if device.type == "cuda" and float(args.auto_batch_target_gb) > 0:
        # Pick the largest safe batch size close to target VRAM, then rebuild loaders.
        tuned_bs = autotune_batch_size_for_vram(
            make_loader=lambda bs: _make_train_loader(bs),
            make_model=lambda: build_model(num_classes=num_classes, pretrained=args.pretrained, arch=args.arch),
            make_optimizer=lambda m: AdamW(m.parameters(), lr=args.lr, weight_decay=args.weight_decay),
            criterion=criterion,
            device=device,
            use_amp=use_amp,
            scaler=scaler,
            non_blocking=non_blocking,
            target_gb=float(args.auto_batch_target_gb),
            min_bs=int(args.batch_size),
            max_bs=int(args.auto_batch_max),
        )
        if tuned_bs != int(args.batch_size):
            print(f"Batch size adjusted: {int(args.batch_size)} -> {tuned_bs}")
            args.batch_size = int(tuned_bs)
            train_loader = _make_train_loader(int(args.batch_size))
            test_loader = _make_test_loader(int(args.batch_size))

    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = None
    if args.scheduler == "cosine":
        scheduler = CosineAnnealingLR(optimizer, T_max=int(args.epochs), eta_min=float(args.min_lr))
    elif args.scheduler == "plateau":
        # Keep args compatible across torch versions: do not pass 'verbose'.
        scheduler = ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(args.plateau_factor),
            patience=int(args.plateau_patience),
            min_lr=float(args.min_lr),
        )

    history = {"train_loss": [], "train_acc": [], "test_loss": [], "test_acc": []}
    best_acc = 0.0
    best_epoch = 0
    no_improve = 0
    best_path = run_dir / "best_image_model.pt"
    start_epoch = 1
    if args.resume:
        if not resume_p.is_file():
            raise FileNotFoundError(f"Resume checkpoint not found: {resume_p}")
        rs = resume_from_checkpoint(resume_p, model, optimizer, scheduler, device, default_history=history)
        start_epoch = rs.start_epoch
        history = rs.history
        best_acc = rs.best_metric
        best_epoch = int(np.argmax(np.asarray(history.get("test_acc", [0.0]), dtype=np.float64))) + 1 if history.get("test_acc") else 0
        print(f"Resumed from epoch {start_epoch - 1}, best_test_acc={best_acc:.6f}, run_dir={run_dir}")

    print(f"Data layout: {layout_used}, num_classes={num_classes}, samples={len(dataset)}")

    if bool(getattr(args, "diagnostic_first_batch", False)):
        print_first_batch_diagnostic(
            model, test_loader, device, int(num_classes), use_amp=use_amp
        )

    epochs_target = int(args.epochs)
    if start_epoch > epochs_target:
        print(
            f"WARN: 续训起始 epoch={start_epoch} 已超过目标 --epochs={epochs_target}，本轮不会训练。"
            "若要继续训练请把 --epochs 调大。"
        )

    for epoch in range(start_epoch, epochs_target + 1):
        train_metrics = run_epoch(
            model,
            train_loader,
            criterion,
            optimizer,
            device,
            grad_clip_norm=float(args.grad_clip_norm),
            scaler=scaler,
            use_amp=use_amp,
            non_blocking=non_blocking,
            semantic_ctx=semantic_ctx,
            metric_ctx=metric_ctx,
        )
        test_metrics = run_epoch(
            model,
            test_loader,
            criterion,
            None,
            device,
            grad_clip_norm=0.0,
            scaler=None,
            use_amp=use_amp,
            non_blocking=non_blocking,
            semantic_ctx=semantic_ctx,
            metric_ctx=metric_ctx,
        )

        history["train_loss"].append(train_metrics["loss"])
        history["train_acc"].append(train_metrics["acc"])
        history["test_loss"].append(test_metrics["loss"])
        history["test_acc"].append(test_metrics["acc"])

        improved = (test_metrics["acc"] - best_acc) > float(args.early_stop_min_delta)
        if improved:
            best_acc = test_metrics["acc"]
            best_epoch = epoch
            no_improve = 0
            torch.save(model.state_dict(), best_path)
        else:
            no_improve += 1

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(float(test_metrics["loss"]))
            else:
                scheduler.step()
        cur_lr = float(optimizer.param_groups[0]["lr"])

        write_history_atomic(run_dir, history)
        save_training_checkpoint(
            run_dir / CHECKPOINT_LAST,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            epoch=epoch,
            history=history,
            best_metric=best_acc,
            metric_name="test_acc",
            extra={"epochs_target": epochs_target, "best_epoch": best_epoch, "scheduler": args.scheduler, "lr": cur_lr},
        )
        maybe_save_epoch_weights(run_dir, model, epoch, args.epoch_ckpt_every, prefix="epoch_weights")

        print(
            f"Epoch [{epoch}/{epochs_target}] "
            f"Train Loss={train_metrics['loss']:.4f}, Train Acc={train_metrics['acc']:.4f} | "
            f"Test Loss={test_metrics['loss']:.4f}, Test Acc={test_metrics['acc']:.4f} lr={cur_lr:.2e}"
        )

        if args.early_stop_patience > 0 and no_improve >= int(args.early_stop_patience):
            print(
                f"Early stopping: no test_acc improvement for {no_improve} epochs "
                f"(best={best_acc:.4f} at epoch {best_epoch})."
            )
            break

    if bool(getattr(args, "save_confusion_diag", False)) and best_path.is_file():
        try:
            payload = torch.load(best_path, map_location=device)
            if isinstance(payload, dict) and "model_state_dict" in payload:
                model.load_state_dict(payload["model_state_dict"])
            elif isinstance(payload, dict) and "state_dict" in payload:
                model.load_state_dict(payload["state_dict"])
            else:
                model.load_state_dict(payload)
            yt, yp = gather_predictions_eval(
                model,
                test_loader,
                device,
                use_amp=use_amp,
                non_blocking=non_blocking,
                metric_ctx=metric_ctx,
            )
            from train_image_diagnostics import save_confusion_bundle

            save_confusion_bundle(yt, yp, list(dataset.classes), run_dir)
            print(f"[train_image] 混淆矩阵与报告已写入: {run_dir}")
        except Exception as e:
            print(f"WARN: --save_confusion_diag 失败: {e}")

    result = {
        "best_test_accuracy": best_acc,
        "best_epoch": best_epoch,
        "epochs_ran": len(history.get("test_acc", [])),
        "num_classes": num_classes,
        "layout": layout_used,
        "class_to_idx": {k: int(v) for k, v in dataset.class_to_idx.items()},
        "num_train_samples": len(train_set),
        "num_test_samples": len(test_set),
        "pretrained": args.pretrained,
        "scheduler": args.scheduler,
        "label_smoothing": float(args.label_smoothing),
        "early_stop_patience": int(args.early_stop_patience),
        "early_stop_min_delta": float(args.early_stop_min_delta),
        "run_dir": str(run_dir),
        "run_label": run_label,
        "resume_from": str(resolve_resume_path(base_dir, args.resume)) if args.resume else None,
    }
    finalize_train_log(
        run_dir,
        script="train_image.py",
        run_label=run_label,
        args=args,
        history=history,
        metrics=result,
    )

    print(f"Best test accuracy: {best_acc:.4f}")
    print(f"Saved model to: {best_path}")
    print(f"Run directory: {run_dir}")
    print(f"可读训练日志: {run_dir / '训练记录.json'} ；说明: {run_dir / TRAIN_README_TXT}")
    print("提示: *.pt 为二进制权重，勿用文本方式打开（会显示乱码）；看指标请打开上述 JSON/说明文件。")
    if args.auto_report:
        reports_dir = resolve_cli_path(base_dir, args.reports_dir)
        try_run_reports(base_dir, outputs_dir=output_base, reports_dir=reports_dir, limit=int(args.report_limit))


if __name__ == "__main__":
    main()
