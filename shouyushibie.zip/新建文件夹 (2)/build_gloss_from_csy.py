from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path


def _norm_zh(s: str) -> str:
    s = str(s or "").strip()
    s = re.sub(r"\s+", "", s)
    return s


def _stem_to_zh(name: str) -> str:
    """
    CSY/front files look like: 中文词.MP4.npy / 中文词.MTS.npy
    We want the Chinese token before the first media extension.
    """
    n = Path(name).name
    if n.lower().endswith(".npy"):
        n = n[: -len(".npy")]
    # remove one media extension suffix if present
    for ext in (".mp4", ".mts", ".m2ts", ".avi", ".mov", ".mkv", ".webm"):
        if n.lower().endswith(ext):
            n = n[: -len(ext)]
            break
    return str(n).strip()


def read_gloss_csv(path: Path) -> list[tuple[str, str, str]]:
    rows: list[tuple[str, str, str]] = []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.reader(f)
        for row in r:
            if not row:
                continue
            if str(row[0]).strip().startswith("#"):
                continue
            if len(row) < 2:
                continue
            gid = str(row[0]).strip()
            zh = str(row[1]).strip() if len(row) >= 2 else ""
            en = ",".join(str(x).strip() for x in row[2:]) if len(row) >= 3 else ""
            rows.append((gid, zh, en))
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(description="Build a gloss.csv using CSY/front npy Chinese labels")
    ap.add_argument("--gloss_in", type=str, required=True, help="Existing gloss.csv with full ID list")
    ap.add_argument("--csy_front_dir", type=str, required=True, help="Directory containing CSY/front *.npy files")
    ap.add_argument("--gloss_out", type=str, required=True, help="Output gloss.csv path")
    ap.add_argument(
        "--mode",
        type=str,
        default="match_zh",
        choices=["match_zh", "by_order"],
        help=(
            "match_zh: 用中文文本去 gloss_in 里匹配 ID（要求两边中文一致）；"
            "by_order: 按 CSY/front 文件名排序顺序覆盖 gloss_in 的 0000..（保证一一对应，推荐当两边中文不一致时）"
        ),
    )
    ap.add_argument("--report_out", type=str, default="", help="Optional report json path")
    args = ap.parse_args()

    gloss_in = Path(args.gloss_in).resolve()
    csy_dir = Path(args.csy_front_dir).resolve()
    gloss_out = Path(args.gloss_out).resolve()
    report_out = Path(args.report_out).resolve() if args.report_out else None

    if not gloss_in.is_file():
        raise FileNotFoundError(f"gloss_in not found: {gloss_in}")
    if not csy_dir.is_dir():
        raise FileNotFoundError(f"csy_front_dir not found: {csy_dir}")

    gloss_rows = read_gloss_csv(gloss_in)

    # zh -> ids (for matching)
    zh_to_ids: dict[str, list[str]] = {}
    for gid, zh, _en in gloss_rows:
        k = _norm_zh(zh)
        if not k:
            continue
        zh_to_ids.setdefault(k, []).append(gid)

    csy_files = sorted([p for p in csy_dir.glob("*.npy") if p.is_file()], key=lambda p: p.name)
    csy_words = [_stem_to_zh(p.name) for p in csy_files]
    csy_norm = [_norm_zh(w) for w in csy_words]

    matched: dict[str, str] = {}  # gloss_id -> zh (from CSY)
    missing_words: list[str] = []
    ambiguous: dict[str, list[str]] = {}

    if args.mode == "by_order":
        # Overwrite gloss IDs in ascending order with CSY names in sorted order.
        # This guarantees correspondence even if gloss_in Chinese differs.
        ids_sorted = sorted((gid for gid, _zh, _en in gloss_rows), key=lambda s: int(s))
        n = min(len(ids_sorted), len(csy_words))
        for i in range(n):
            matched[ids_sorted[i]] = csy_words[i]
    else:
        # match_zh (old behavior)
        for w_raw, w_norm in zip(csy_words, csy_norm):
            if not w_norm:
                continue
            ids = zh_to_ids.get(w_norm)
            if not ids:
                missing_words.append(w_raw)
                continue
            if len(ids) > 1:
                ambiguous[w_raw] = ids
            # pick the first id deterministically
            matched[ids[0]] = w_raw

    # Write merged gloss: replace zh with CSY zh when matched; keep en as original
    gloss_out.parent.mkdir(parents=True, exist_ok=True)
    with open(gloss_out, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["#ID", "Chinese Sign Language Word", "Translation"])
        for gid, zh, en in gloss_rows:
            zh2 = matched.get(gid, zh)
            w.writerow([gid, zh2, en])

    report = {
        "gloss_in": str(gloss_in),
        "csy_front_dir": str(csy_dir),
        "gloss_out": str(gloss_out),
        "mode": str(args.mode),
        "csy_files": len(csy_files),
        "matched_ids": len(matched),
        "missing_words": missing_words[:50],
        "missing_words_count": len(missing_words),
        "ambiguous_words": {k: v for k, v in list(ambiguous.items())[:50]},
        "ambiguous_words_count": len(ambiguous),
    }
    if report_out is not None:
        report_out.parent.mkdir(parents=True, exist_ok=True)
        report_out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print(
        f"OK: wrote {gloss_out} | CSY files={len(csy_files)} | matched_ids={len(matched)} "
        f"| missing_words={len(missing_words)} | ambiguous_words={len(ambiguous)}"
    )


if __name__ == "__main__":
    main()

