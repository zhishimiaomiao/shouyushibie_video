# 手语识别系统（核心算法版）

本项目基于 `27261843` 数据目录，构建了一个可运行的手语识别核心系统，覆盖：

- 特征提取：`3D-CNN`（视频）与 `MediaPipe Pose`（关键点）
- 时序建模：`BiLSTM / Transformer / TCN` 可切换
- 分类识别：多类别手语词汇识别（当前默认使用 `LSNU-SCL_feature_768`）
- 性能评估：训练/测试准确率与损失可视化

### 数据目录与 `gloss.csv`

| 路径 | 说明 |
|------|------|
| `gloss.csv` | 词表：Gloss ID ↔ 中文/英文释义。解析与文件名中的 ID 提取集中在 `glossary.py`。解析时合并可能被误拆的英文列；文件名解析优先独立四位数、再取「开头到 `_` 的整段数字」（如 `0001234_clip`→1234），并可传入词表 ID 集合消歧（如去掉文件名里的年份）。 |
| `Videos/` | 原始视频；支持 `.mp4` 及摄像机常见的 `.MTS` / `.M2TS`，供 `extract_3dcnn_features.py`、`extract_pose_mediapipe.py`、`generate_cslr_manifest.py` 扫描。 |
| `Pics/` | 可从视频中抽帧得到；训练时可用子文件夹分类、文件名前缀分类，或使用 **`--layout gloss_csv`**，按文件名中的 Gloss ID 与 `gloss.csv` 对齐（见下文「图片训练」）。 |
| `Code/` | 官方技术验证脚本与 `LSNU-SCL_feature_768` 等特征示例，见 `Code/tech code/README.md`。 |

快速查看词表与目录是否对齐：

```bash
python preview_dataset.py --root ..
```

> 若 `Videos` / `Pics` 为空，默认训练仍可使用 `Code/tech code/LSNU-SCL_feature_768/*.csv` 特征。

## 1. 环境安装

```bash
cd sign_language_system
pip install -r requirements.txt
```

## 2. 训练（孤立词识别）

### 输出目录、检查点与续训（滚动训练）

`train.py`、`train_fusion.py`、`train_image.py`、`train_ctc.py` 默认在 `--output_dir` 下创建带时间戳的子目录 `run_YYYY-mm-dd_HHMMSS/`，避免覆盖历史结果。每个 run 目录**只保留少量、含义清晰的文件**：

- **`训练记录.json`**（核心）：**时间**（开始/结束）、**命令与配置**（完整超参）、**训练结果**（最佳指标 + 完整 `history` 曲线）、**问题分析**（默认占位说明；你可手写记录现象与结论，续训会保留该字段）  
- `checkpoint_last.pt`：每 epoch 更新，用于 `--resume`  
- `best_*.pt`：验证集最优权重（如 `best_fusion_model.pt`）  

训练过程中仍会临时写入 `history.json`（防中断丢曲线）；**正常训练结束会自动删除** `history.json` / `metrics.json` / `run_meta.json`，避免与 `训练记录.json` 重复。  

需要旧版「根目录 `training_runs_index.jsonl`」时，训练命令加 **`--write_runs_index`**（默认关闭）。  

若你本地还有旧的三件套目录，可一次性合并为 `训练记录.json`：

```bash
python consolidate_runs.py
```

续训（总 epoch 数仍为 `--epochs`，从未完成的下一个 epoch 接着跑；**不写 `--run_name` 时，输出仍写入该检查点所在目录**，避免产生第二个 `run_*`）：

```bash
python train_fusion.py --epochs 40 --resume outputs/fusion/run_2026-04-16_143052/checkpoint_last.pt
```

与旧版相同、直接写入 `output_dir`（会覆盖文件）：加 `--flat_output`。  
仅保存权重快照、便于对比：`--epoch_ckpt_every 5` 会生成 `epoch_weights_epoch_005.pt` 等。  
摄像头推理时把 `--checkpoint` 指到某次 run 下的 `best_fusion_model.pt`，或复制到原默认路径。

### 训练结果“归类输出”（你要的 图 + 表）

训练过程文件会分散在 `outputs/**/run_*` 里用于续训与回滚，但**分析只看两类文件**，统一由脚本生成到 `reports/`：

```bash
python report_runs.py --outputs_dir outputs --reports_dir reports
```

输出示例：

- `reports/report_YYYY-mm-dd_HHMMSS/runs_summary.csv`：**汇总表格**（Excel 打开即可筛选：时间、模型名、准确率/WER、参数等）
- `reports/report_YYYY-mm-dd_HHMMSS/run_plots/*.svg`：每次训练 1 张**曲线图**（文件名含时间 + 模型名）

也可以在训练命令里直接加 `--auto_report`，训练结束会自动生成一份 `reports/` 报告（默认汇总最近 20 个 runs，可用 `--report_limit` 调整）：

```bash
python train_fusion.py --epochs 120 --auto_report --report_limit 20
```

### 过拟合时的推荐起步参数（更稳）

当你出现「训练集很高、测试集卡住」时，优先尝试：增大 `dropout`、降低 `hidden_dim`、加 `label_smoothing`、适当增大 `weight_decay`，并让 plateau scheduler 自动降学习率：

```bash
python train.py --epochs 120 --hidden_dim 256 --dropout 0.5 --label_smoothing 0.1 --weight_decay 5e-4 ^
  --scheduler plateau --plateau_patience 3 --min_lr 1e-6 ^
  --grad_clip_norm 1.0 --early_stop_patience 12 --early_stop_min_delta 0.001 ^
  --auto_report
```

### 使用 BiLSTM（推荐起步）

```bash
python train.py --temporal bilstm --epochs 15
```

### 使用 Transformer

```bash
python train.py --temporal transformer --epochs 15
```

### 使用 TCN

```bash
python train.py --temporal tcn --epochs 15
```

训练输出（在 `outputs/run_*/` 下）：

- `训练记录.json`：时间 + 结果 + 问题分析 + history
- `best_model.pt`：最佳权重

## 3. 图片训练（直接使用 `Pics/`）

使用 `train_image.py` 训练 ResNet18。**多分类至少需要 2 个类别**（两类样本都要有足够图片）。

### 方式 A：按文件夹分类（推荐，`ImageFolder`）

每个类别一个子文件夹：

```text
Pics/
  class_a/
    a1.jpg
    a2.jpg
  class_b/
    b1.jpg
    b2.jpg
```

```bash
python train_image.py --data_root ..\\Pics --layout imagefolder --epochs 15 --batch_size 32
```

### 方式 B：图片可混在同一目录，用文件名区分类别

文件名规则：**下划线前为类别名**，例如 `你好_001.jpg`、`谢谢_002.jpg`（可用 `--label_sep` 改分隔符）。

```bash
python train_image.py --data_root ..\\Pics --layout filename_prefix --epochs 15 --batch_size 32
```

### 方式 C：文件名含 Gloss ID，与 `gloss.csv` 对齐（推荐与数据集编号一致）

文件名需能被 `glossary.parse_gloss_id_from_filename` 解析（例如 `0042_sample1.jpg`、`前缀_0042.jpg`），且 ID 必须出现在 `gloss.csv` 中。

```bash
python train_image.py --data_root ..\\Pics --layout gloss_csv --gloss_csv ..\\gloss.csv --epochs 15 --batch_size 32
```

### 自动选择（默认）

不加 `--layout` 时等价于 `--layout auto`：若 `Pics` 下已有**至少两个类别子文件夹**且能读图，则用方式 A；否则若存在默认路径下的 `gloss.csv`，会尝试 **gloss 对齐**（方式 C）；再否则按**文件名前缀**解析（方式 B）。

若仍报错「至少需要 2 个类别」，请检查：是否只有 1 个文件夹、或所有文件名里类别前缀都相同。

### 预训练权重（可选）

```bash
python train_image.py --data_root ..\\Pics --epochs 15 --pretrained
```

输出：

- `outputs/image/best_image_model.pt`
- `outputs/image/run_*/训练记录.json`

## 4. 准确率可视化

```bash
python visualize_metrics.py --history outputs/run_2026-04-16_200016/训练记录.json --save_path outputs/accuracy_loss_curve.png
```

结果图保存在 `outputs/accuracy_loss_curve.png`。

## 5. 视频特征提取（可选）

当 `../Videos` 中放入视频后，可运行：

### 4.1 3D-CNN 特征

```bash
python extract_3dcnn_features.py --video_dir ..\\Videos --output outputs/video_3dcnn_features.json
```

### 4.2 MediaPipe 关键点序列

```bash
python extract_pose_mediapipe.py --video_dir ..\\Videos --output outputs/pose_features.json
```

## 6. 双流融合训练（3D-CNN + MediaPipe）

先提取两个流的特征：

```bash
python extract_3dcnn_features.py --video_dir ..\\Videos --output outputs/video_3dcnn_features.json
python extract_pose_mediapipe.py --video_dir ..\\Videos --output outputs/pose_features.json
```

再执行双流训练：

```bash
python train_fusion.py --rgb_json outputs/video_3dcnn_features.json --pose_json outputs/pose_features.json --epochs 20
```

输出：

- `outputs/fusion/best_fusion_model.pt`
- `outputs/fusion/run_*/训练记录.json`

## 7. CTC 连续手语识别（CSLR）

### 6.1 准备清单文件

可直接自动生成（推荐）：

```bash
python generate_cslr_manifest.py --video_dir ..\\Videos --gloss_csv ..\\gloss.csv --output_csv outputs\\cslr_manifest.csv
```

模式说明（`--mode`）：

- **`videos`**（默认）：扫描 `Videos/`，从文件名解析词 id；**同一文件名在多个子目录出现时只保留一条**，避免重复行。
- **`gloss`**：按 `gloss.csv` **每个词目一行**（`sample_id` 为 `0007.mp4` 这种与词表 id 对齐；孤立词 `target_ids` 为单个 id）。`train_ctc` 只会加载 **在 `pose_features.json` 里也存在同名的 key** 的样本，故若要训练「全词表」，需先用 CSV/视频生成带齐全部 `sample_id` 的特征文件。
- **`sequence_json`**：与 `outputs/pose_features.json`（或 `.npz`）里的 **key 一一对应** 写 manifest，最不容易和特征对不齐：

```bash
python generate_cslr_manifest.py --mode sequence_json --sequence_json outputs/pose_features.json --output_csv outputs\\cslr_manifest.csv
```

旧版命令等价于：

```bash
python generate_cslr_manifest.py --mode videos --video_dir ..\\Videos --gloss_csv ..\\gloss.csv --output_csv outputs\\cslr_manifest.csv
```

脚本会同时输出失败样本报告：`outputs/cslr_manifest_failed.csv`。

也可以手工创建 `outputs/cslr_manifest.csv`，格式如下：

```csv
sample_id,target_ids
0001_demo.mp4,12 45 90
0002_demo.mp4,18 76
```

- `sample_id` 需与 `outputs/pose_features.json` 中的 key 一致。
- `target_ids` 是词表 token id 序列（空格分隔）。

### 6.2 训练 CTC 模型

```bash
python train_ctc.py --sequence_json outputs/pose_features.json --manifest_csv outputs/cslr_manifest.csv --vocab_size 7008 --blank_id 0 --epochs 20 --dump_eval_csv --eval_csv_path outputs/wer_eval.csv
```

输出：

- `outputs/ctc/best_ctc_model.pt`
- `outputs/ctc/run_*/训练记录.json`（含 train/test WER 曲线）
- `outputs/wer_eval.csv`（自动导出，给 `evaluate_wer.py` 直接用）

## 8. WER 评估脚本

创建预测文件 `outputs/wer_eval.csv`：

```csv
ref_ids,pred_ids
12 45 90,12 45 90
18 76,18 60 76
```

运行：

```bash
python evaluate_wer.py --input_csv outputs/wer_eval.csv
```

## 9. 说明

- 本实现对齐你提出的核心技术路线：`3D-CNN + Pose + 时序模型 + 分类评估`。
- `train.py` 是单流分类基线（768维特征）。
- `train_image.py` 支持 `Pics/` 图像目录的直接训练（`ImageFolder + ResNet18`）。
- `train_fusion.py` 是双流融合分类主干。
- `train_ctc.py` + `evaluate_wer.py` 覆盖连续手语识别和 WER 评估。
