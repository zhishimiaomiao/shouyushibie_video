"""
把 `outputs/**/run_*` 的训练记录归类成两类分析产物：

- 每次训练 1 张曲线图（文件名带时间 + 模型名）
- 1 份汇总表格（CSV，可用 Excel 直接筛选）

读取优先使用各 run 目录下的 ``训练记录.json``（时间 + 训练结果含 history + 问题分析）；
若无则回退旧版 ``run_meta.json`` + ``metrics.json`` + ``history.json``。

输出统一放到 `reports/report_YYYY-mm-dd_HHMMSS/`，减少 outputs 杂乱。
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np


def read_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def parse_iso(dt: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(dt)
    except Exception:
        return None


def slug(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"[^0-9A-Za-z_.-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "unknown"


def is_ctc_history(h: Dict[str, Any]) -> bool:
    return "train_wer" in h and "test_wer" in h


def best_epoch_from_history(h: Dict[str, Any]) -> Optional[int]:
    if not h:
        return None
    if is_ctc_history(h):
        arr = np.asarray(h.get("test_wer", []), dtype=np.float64)
        if arr.size == 0:
            return None
        return int(np.argmin(arr)) + 1
    arr = np.asarray(h.get("test_acc", []), dtype=np.float64)
    if arr.size == 0:
        return None
    return int(np.argmax(arr)) + 1


def build_model_name(meta: Dict[str, Any], metrics: Dict[str, Any]) -> str:
    a = meta.get("args") or {}
    script = str(meta.get("script") or "")

    if script.endswith("train.py"):
        temporal = a.get("temporal", "unknown")
        hidden = a.get("hidden_dim")
        return f"sign_{temporal}_h{hidden}" if hidden is not None else f"sign_{temporal}"
    if script.endswith("train_fusion.py"):
        hidden = a.get("hidden_dim")
        return f"fusion_h{hidden}" if hidden is not None else "fusion"
    if script.endswith("train_image.py"):
        layout = a.get("layout", "auto")
        pre = "pre" if bool(a.get("pretrained")) else "scratch"
        return f"image_{layout}_{pre}"
    if script.endswith("train_ctc.py"):
        hidden = a.get("hidden_dim")
        vocab = a.get("vocab_size", metrics.get("vocab_size", ""))
        return f"ctc_v{vocab}_h{hidden}" if hidden is not None else f"ctc_v{vocab}"
    if script.endswith("interpretive_scheme.py"):
        return "interpretive_scheme"

    return slug(Path(script).stem) if script else "unknown_model"


def _polyline(points: List[tuple[float, float]], color: str, width: int = 2) -> str:
    s = " ".join([f"{x:.2f},{y:.2f}" for x, y in points])
    return f'<polyline points="{s}" fill="none" stroke="{color}" stroke-width="{width}"/>'


def _scale_series(values: List[float], x0: float, y0: float, w: float, h: float, y_min: float, y_max: float) -> List[tuple[float, float]]:
    n = len(values)
    if n == 0:
        return []
    x_step = w / max(1, n - 1)
    rng = max(1e-9, y_max - y_min)
    pts = []
    for i, v in enumerate(values):
        x = x0 + i * x_step
        y = y0 + (1.0 - (float(v) - y_min) / rng) * h
        pts.append((x, y))
    return pts


def plot_run(history: Dict[str, Any], title: str, save_path: Path) -> None:
    """
    不依赖 matplotlib：输出 SVG 曲线图（Windows 上双击即可在浏览器打开）。
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)

    width, height = 1200, 420
    pad = 52
    gap = 36
    panel_w = (width - 2 * pad - gap) / 2
    panel_h = height - 2 * pad
    x1 = pad
    x2 = pad + panel_w + gap
    y0 = pad

    def axis_box(x: float, title_text: str) -> str:
        return "\n".join(
            [
                f'<rect x="{x}" y="{y0}" width="{panel_w}" height="{panel_h}" fill="white" stroke="#333" stroke-width="1"/>',
                f'<text x="{x}" y="{y0 - 16}" font-size="14" fill="#111">{title_text}</text>',
            ]
        )

    svg: List[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{pad}" y="26" font-size="16" fill="#111">{title}</text>',
    ]

    if is_ctc_history(history):
        loss_tr = [float(x) for x in history.get("train_loss", [])]
        loss_te = [float(x) for x in history.get("test_loss", [])]
        wer_tr = [float(x) for x in history.get("train_wer", [])]
        wer_te = [float(x) for x in history.get("test_wer", [])]

        svg.append(axis_box(x1, "Loss"))
        y_min = min(loss_tr + loss_te) if (loss_tr or loss_te) else 0.0
        y_max = max(loss_tr + loss_te) if (loss_tr or loss_te) else 1.0
        svg.append(_polyline(_scale_series(loss_tr, x1, y0, panel_w, panel_h, y_min, y_max), "#1f77b4"))
        svg.append(_polyline(_scale_series(loss_te, x1, y0, panel_w, panel_h, y_min, y_max), "#ff7f0e"))
        svg.append(f'<text x="{x1+10}" y="{y0+18}" font-size="12" fill="#1f77b4">train_loss</text>')
        svg.append(f'<text x="{x1+110}" y="{y0+18}" font-size="12" fill="#ff7f0e">test_loss</text>')

        svg.append(axis_box(x2, "WER (lower is better)"))
        y_min = min(wer_tr + wer_te) if (wer_tr or wer_te) else 0.0
        y_max = max(wer_tr + wer_te) if (wer_tr or wer_te) else 1.0
        svg.append(_polyline(_scale_series(wer_tr, x2, y0, panel_w, panel_h, y_min, y_max), "#2ca02c"))
        svg.append(_polyline(_scale_series(wer_te, x2, y0, panel_w, panel_h, y_min, y_max), "#d62728"))
        svg.append(f'<text x="{x2+10}" y="{y0+18}" font-size="12" fill="#2ca02c">train_wer</text>')
        svg.append(f'<text x="{x2+110}" y="{y0+18}" font-size="12" fill="#d62728">test_wer</text>')
    else:
        acc_tr = [float(x) for x in history.get("train_acc", [])]
        acc_te = [float(x) for x in history.get("test_acc", [])]
        loss_tr = [float(x) for x in history.get("train_loss", [])]
        loss_te = [float(x) for x in history.get("test_loss", [])]

        svg.append(axis_box(x1, "Accuracy"))
        y_min, y_max = 0.0, 1.0
        svg.append(_polyline(_scale_series(acc_tr, x1, y0, panel_w, panel_h, y_min, y_max), "#1f77b4"))
        svg.append(_polyline(_scale_series(acc_te, x1, y0, panel_w, panel_h, y_min, y_max), "#ff7f0e"))
        svg.append(f'<text x="{x1+10}" y="{y0+18}" font-size="12" fill="#1f77b4">train_acc</text>')
        svg.append(f'<text x="{x1+110}" y="{y0+18}" font-size="12" fill="#ff7f0e">test_acc</text>')

        svg.append(axis_box(x2, "Loss"))
        y_min = min(loss_tr + loss_te) if (loss_tr or loss_te) else 0.0
        y_max = max(loss_tr + loss_te) if (loss_tr or loss_te) else 1.0
        svg.append(_polyline(_scale_series(loss_tr, x2, y0, panel_w, panel_h, y_min, y_max), "#2ca02c"))
        svg.append(_polyline(_scale_series(loss_te, x2, y0, panel_w, panel_h, y_min, y_max), "#d62728"))
        svg.append(f'<text x="{x2+10}" y="{y0+18}" font-size="12" fill="#2ca02c">train_loss</text>')
        svg.append(f'<text x="{x2+110}" y="{y0+18}" font-size="12" fill="#d62728">test_loss</text>')

    svg.append("</svg>")
    save_path.write_text("\n".join(svg), encoding="utf-8")


TRAIN_LOG = "训练记录.json"


def iter_training_run_dirs(outputs_dir: Path) -> List[Path]:
    """Each run directory: prefer ``训练记录.json``; else legacy ``run_meta.json``."""
    seen: set[str] = set()
    ordered: List[Path] = []
    for p in sorted(outputs_dir.glob(f"**/run_*/{TRAIN_LOG}"), key=lambda x: str(x)):
        d = p.parent.resolve()
        key = str(d)
        if key not in seen:
            seen.add(key)
            ordered.append(d)
    for meta in sorted(outputs_dir.glob("**/run_*/run_meta.json"), key=lambda x: str(x)):
        d = meta.parent.resolve()
        key = str(d)
        if key in seen:
            continue
        if (d / TRAIN_LOG).is_file():
            continue
        seen.add(key)
        ordered.append(d)
    return ordered


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate clean reports (plots + CSV) from outputs runs")
    parser.add_argument("--outputs_dir", type=str, default="outputs")
    parser.add_argument("--reports_dir", type=str, default="reports")
    parser.add_argument("--limit", type=int, default=0, help="Only process latest N runs (0=all)")
    parser.add_argument("--no_plots", action="store_true", help="CSV only")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    outputs_dir = (base / args.outputs_dir).resolve()
    reports_base = (base / args.reports_dir).resolve()

    run_dirs = iter_training_run_dirs(outputs_dir)
    if not run_dirs:
        raise FileNotFoundError(
            f"No runs found under: {outputs_dir} (expect outputs/**/run_*/{TRAIN_LOG} or run_meta.json)"
        )

    def created_ts(run_dir: Path) -> float:
        log_p = run_dir / TRAIN_LOG
        try:
            if log_p.is_file():
                m = read_json(log_p)
                t = m.get("时间") or {}
                dt = parse_iso(str(t.get("started_at", "")))
                if dt:
                    return dt.timestamp()
            meta_p = run_dir / "run_meta.json"
            if meta_p.is_file():
                m = read_json(meta_p)
                dt = parse_iso(str(m.get("created_at", "")))
                if dt:
                    return dt.timestamp()
        except Exception:
            pass
        return run_dir.stat().st_mtime

    run_dirs.sort(key=created_ts)
    if args.limit and args.limit > 0:
        run_dirs = run_dirs[-args.limit :]

    report_label = datetime.now().strftime("report_%Y-%m-%d_%H%M%S")
    report_dir = reports_base / report_label
    plots_dir = report_dir / "run_plots"
    report_dir.mkdir(parents=True, exist_ok=True)
    plots_dir.mkdir(parents=True, exist_ok=True)

    rows: List[Dict[str, Any]] = []

    for run_dir in run_dirs:
        log_p = run_dir / TRAIN_LOG
        if log_p.is_file():
            doc = read_json(log_p)
            meta = {
                "script": doc.get("脚本", ""),
                "args": doc.get("命令与配置") or {},
                "created_at": (doc.get("时间") or {}).get("started_at", ""),
            }
            tr = doc.get("训练结果") or {}
            history = tr.get("history") or {}
            metrics = {k: v for k, v in tr.items() if k not in ("history", "状态")}
        else:
            meta_path = run_dir / "run_meta.json"
            metrics_path = run_dir / "metrics.json"
            history_path = run_dir / "history.json"
            if not (meta_path.is_file() and metrics_path.is_file() and history_path.is_file()):
                continue
            meta = read_json(meta_path)
            metrics = read_json(metrics_path)
            history = read_json(history_path)

        if not history:
            continue

        created_at = str(meta.get("created_at", "")) or ""
        dt = parse_iso(created_at)
        ts = dt.strftime("%Y-%m-%d_%H%M%S") if dt else run_dir.name.replace("run_", "")

        model_name = build_model_name(meta, metrics)
        best_epoch = best_epoch_from_history(history)
        ctc = is_ctc_history(history)
        best_metric = metrics.get("best_test_wer") if ctc else metrics.get("best_test_accuracy")

        plot_rel = ""
        if not args.no_plots:
            plot_name = f"{ts}__{slug(model_name)}__{slug(run_dir.parent.name)}__{slug(run_dir.name)}.svg"
            plot_path = plots_dir / plot_name
            plot_run(history, title=f"{ts} | {model_name}", save_path=plot_path)
            plot_rel = str(plot_path.relative_to(report_dir))

        a = meta.get("args") or {}
        row: Dict[str, Any] = {
            "time": created_at or ts,
            "model": model_name,
            "script": meta.get("script", ""),
            "run_dir": str(run_dir),
            "plot": plot_rel,
            "epochs": a.get("epochs", ""),
            "batch_size": a.get("batch_size", ""),
            "lr": a.get("lr", ""),
            "weight_decay": a.get("weight_decay", ""),
            "seed": a.get("seed", ""),
            "best_epoch": best_epoch or "",
            "best_metric_name": "test_wer" if ctc else "test_acc",
            "best_metric": best_metric,
            "num_classes": metrics.get("num_classes", ""),
            "vocab_size": metrics.get("vocab_size", ""),
        }

        for k in (
            "hidden_dim",
            "temporal",
            "layout",
            "pretrained",
            "rgb_json",
            "pose_json",
            "sequence_json",
            "manifest_csv",
        ):
            if k in a:
                row[k] = a.get(k)

        rows.append(row)

    if not rows:
        raise RuntimeError(f"No complete runs found (need {TRAIN_LOG} with history, or legacy triple).")

    keys = sorted({k for r in rows for k in r.keys()})
    preferred = [
        "time",
        "model",
        "script",
        "run_dir",
        "plot",
        "epochs",
        "batch_size",
        "lr",
        "weight_decay",
        "seed",
        "hidden_dim",
        "temporal",
        "layout",
        "pretrained",
        "best_epoch",
        "best_metric_name",
        "best_metric",
        "num_classes",
        "vocab_size",
        "rgb_json",
        "pose_json",
        "sequence_json",
        "manifest_csv",
    ]
    cols = [c for c in preferred if c in keys] + [c for c in keys if c not in preferred]

    csv_path = report_dir / "runs_summary.csv"
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in cols})

    (report_dir / "README.txt").write_text(
        "\n".join(
            [
                f"Report: {report_label}",
                f"Generated at: {datetime.now().isoformat(timespec='seconds')}",
                f"Scanned outputs: {outputs_dir}",
                f"Runs summarized: {len(rows)}",
                "",
                "Files:",
                "- runs_summary.csv : table for Excel",
                "- run_plots/       : per-run training curves",
            ]
        ),
        encoding="utf-8",
    )

    print(f"Saved report to: {report_dir}")
    print(f"- CSV: {csv_path}")
    if not args.no_plots:
        print(f"- Plots: {plots_dir}")


if __name__ == "__main__":
    main()

