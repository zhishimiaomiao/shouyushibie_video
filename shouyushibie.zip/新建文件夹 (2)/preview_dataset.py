"""
快速查看 27261843 数据：gloss 行数、Videos 中可识别视频数、Pics 中与词表对齐的图片数。
"""

from __future__ import annotations

import argparse
from pathlib import Path

from glossary import (
    iter_gloss_rows,
    iter_video_paths,
    load_gloss_by_int,
    parse_gloss_id_from_filename,
)

_IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def main() -> None:
    parser = argparse.ArgumentParser(description="Preview gloss.csv + Videos/ + Pics/ alignment")
    parser.add_argument("--root", type=str, default="..", help="27261843 根目录（默认上级）")
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    root = (base / args.root).resolve()
    gloss_path = root / "gloss.csv"
    videos_dir = root / "Videos"
    pics_dir = root / "Pics"

    if not gloss_path.is_file():
        print(f"未找到 gloss.csv: {gloss_path}")
        return

    n_gloss = sum(1 for _ in iter_gloss_rows(gloss_path))
    by_id = load_gloss_by_int(gloss_path)
    print(f"gloss.csv: {n_gloss} 条词条（解析后 id 数: {len(by_id)}）")

    if videos_dir.is_dir():
        vids = iter_video_paths(videos_dir)
        print(f"Videos/: {len(vids)} 个视频文件（含 .mts/.m2ts 等）")
        if vids[:3]:
            print(f"  示例: {', '.join(p.name for p in vids[:3])}")
    else:
        print("Videos/: 目录不存在")

    if pics_dir.is_dir():
        valid = set(by_id.keys())
        ok = 0
        bad = 0
        for p in pics_dir.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in _IMAGE_EXT:
                continue
            gid = parse_gloss_id_from_filename(p.name, valid)
            if gid >= 0 and gid in valid:
                ok += 1
            else:
                bad += 1
        print(f"Pics/: 可解析且 id ∈ gloss 的图片 {ok} 张，无法对齐 {bad} 张")
    else:
        print("Pics/: 目录不存在")


if __name__ == "__main__":
    main()
