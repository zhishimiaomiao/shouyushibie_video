from __future__ import annotations

import argparse
import csv
from pathlib import Path

from metrics_utils import wer


def parse_seq(text: str):
    text = text.strip()
    if not text:
        return []
    return [int(x) for x in text.split()]


def write_template_csv(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ref_ids", "pred_ids"])
        writer.writerow(["12 45 90", "12 45 90"])
        writer.writerow(["18 76", "18 60 76"])


def main():
    parser = argparse.ArgumentParser(description="Evaluate WER from prediction csv")
    parser.add_argument("--input_csv", type=str, default="outputs/wer_eval.csv")
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    input_csv = (base_dir / args.input_csv).resolve()
    if not input_csv.exists():
        write_template_csv(input_csv)
        print(f"Input csv not found, template created at: {input_csv}")
        print("Please fill ref_ids and pred_ids, then rerun this script.")
        return

    refs = []
    hyps = []
    with open(input_csv, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or "ref_ids" not in reader.fieldnames or "pred_ids" not in reader.fieldnames:
            raise ValueError("CSV must contain headers: ref_ids,pred_ids")
        for row in reader:
            refs.append(parse_seq(row["ref_ids"]))
            hyps.append(parse_seq(row["pred_ids"]))
    value = wer(refs, hyps)
    print(f"WER: {value:.6f}")


if __name__ == "__main__":
    main()
