from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import warnings
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

# Workaround for Windows conda OpenMP duplication crash:
# "OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll already initialized."
# Prefer fixing the environment (single OpenMP runtime), but this keeps scripts runnable.
if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm


PAD = "<pad>"
BOS = "<bos>"
EOS = "<eos>"
UNK = "<unk>"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def tokenize_src(gloss_ids: str) -> List[str]:
    # Input format example: "72 158 810"
    toks = [x.strip() for x in gloss_ids.strip().split() if x.strip()]
    return toks if toks else [UNK]


def tokenize_tgt_zh(text: str) -> List[str]:
    # Character-level Chinese tokenization for small-data robustness.
    text = text.strip().replace(" ", "")
    toks = [ch for ch in text if ch.strip()]
    return toks if toks else [UNK]


def canonicalize_gloss_id_tokens(tokens: List[str]) -> List[str]:
    """Normalize gloss id tokens so 0072 / 72 share one key."""
    out: List[str] = []
    for t in tokens:
        t = t.strip()
        if not t:
            continue
        out.append(str(int(t)) if t.isdigit() else t)
    return out


def canonicalize_src_key(gloss_ids: str) -> str:
    """Space-separated gloss ids in canonical int string form."""
    return " ".join(canonicalize_gloss_id_tokens(tokenize_src(gloss_ids)))


@dataclass
class Pair:
    src_tokens: List[str]
    tgt_tokens: List[str]


class Vocab:
    def __init__(self, specials: List[str] | None = None):
        self.itos: List[str] = []
        self.stoi: dict[str, int] = {}
        for s in (specials or []):
            self.add(s)

    def add(self, token: str) -> int:
        if token not in self.stoi:
            self.stoi[token] = len(self.itos)
            self.itos.append(token)
        return self.stoi[token]

    def encode(self, tokens: List[str], add_bos_eos: bool = False) -> List[int]:
        out = []
        if add_bos_eos:
            out.append(self.stoi[BOS])
        for t in tokens:
            out.append(self.stoi.get(t, self.stoi[UNK]))
        if add_bos_eos:
            out.append(self.stoi[EOS])
        return out

    def decode(self, ids: List[int], stop_at_eos: bool = True) -> List[str]:
        out: List[str] = []
        for i in ids:
            if i < 0 or i >= len(self.itos):
                continue
            tok = self.itos[i]
            if stop_at_eos and tok == EOS:
                break
            if tok in {PAD, BOS}:
                continue
            out.append(tok)
        return out

    @property
    def size(self) -> int:
        return len(self.itos)


def load_manifest_pairs(manifest_csv: Path) -> List[Pair]:
    pairs: List[Pair] = []
    with open(manifest_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            src = tokenize_src(row["target_ids"])
            tgt = tokenize_tgt_zh(row["target_words_zh"])
            pairs.append(Pair(src_tokens=src, tgt_tokens=tgt))
    if not pairs:
        raise ValueError(f"No rows loaded from {manifest_csv}")
    return pairs


def build_translation_library(
    manifest_csv: Path,
    output_csv: Path,
    min_len: int = 1,
    max_len: int = 4,
    augment_random: int = 200,
    seed: int = 42,
    gloss_csv: Path | None = None,
) -> int:
    """
    Build a sentence-level parallel library from current sign dataset.
    Output CSV columns: src_ids,tgt_zh,source

    When gloss_csv is set (recommended: 27261843/gloss.csv), every gloss id that does not
    already appear as its own row in the manifest gets a gloss_csv single-token entry, so
    the library scales with the full ~6k vocabulary instead of only manifest rows.

    augment_random < 0 selects an automatic count from vocabulary size (capped).
    """
    rng = np.random.default_rng(seed)
    rows = []
    with open(manifest_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            src_ids = [x for x in r.get("target_ids", "").split() if x.strip()]
            tgt = normalize_zh_gloss((r.get("target_words_zh", "") or "").strip())
            if not src_ids or not tgt:
                continue
            rows.append((src_ids, tgt))
    if not rows:
        raise ValueError(f"No valid rows for translation library from {manifest_csv}")

    manifest_src_keys = {canonicalize_src_key(" ".join(src_ids)) for src_ids, _ in rows}

    # Single-token map: manifest first, then fill missing ids from gloss.csv.
    base_unique: dict[str, str] = {}
    for src_ids, tgt in rows:
        if len(src_ids) == 1:
            k = canonicalize_gloss_id_tokens(src_ids)[0]
            base_unique[k] = tgt
    if gloss_csv is not None and gloss_csv.exists():
        from glossary import iter_gloss_rows

        for e in iter_gloss_rows(gloss_csv):
            sid = str(e.id_int)
            zh = normalize_zh_gloss(e.zh)
            if zh and sid not in base_unique:
                base_unique[sid] = zh

    if augment_random < 0:
        augment_random = max(500, min(80000, 12 * max(len(base_unique), 1)))

    pairs: List[Tuple[str, str, str]] = []
    # 1) keep all original manifest rows (canonical src_ids)
    for src_ids, tgt in rows:
        ck = canonicalize_src_key(" ".join(src_ids))
        pairs.append((ck, tgt, "manifest_row"))
    # 1b) gloss vocabulary singles not covered by any manifest row key (including multi-id rows)
    if gloss_csv is not None and gloss_csv.exists():
        from glossary import iter_gloss_rows

        for e in iter_gloss_rows(gloss_csv):
            sid = str(e.id_int)
            if sid in manifest_src_keys:
                continue
            zh = normalize_zh_gloss(e.zh)
            if zh:
                pairs.append((sid, zh, "gloss_csv"))

    # 2) sequential n-gram windows (simulate short sentences in real-time stream)
    seq_ids = [canonicalize_gloss_id_tokens(x[0])[0] for x in rows if len(x[0]) == 1]
    seq_zh = [x[1] for x in rows if len(x[0]) == 1]
    n = len(seq_ids)
    for L in range(max(2, min_len), max_len + 1):
        if n < L:
            continue
        for i in range(0, n - L + 1):
            s_ids = seq_ids[i : i + L]
            s_zh = compose_natural_sentence(seq_zh[i : i + L])
            if s_zh:
                pairs.append((" ".join(s_ids), s_zh, f"sequential_{L}"))

    # 3) random combinations from available vocabulary (augment)
    uniq_ids = sorted(base_unique.keys(), key=lambda x: int(x) if x.isdigit() else x)
    if uniq_ids:
        for _ in range(max(0, augment_random)):
            L = int(rng.integers(max(2, min_len), max_len + 1))
            if len(uniq_ids) < L:
                continue
            pick = rng.choice(uniq_ids, size=L, replace=False).tolist()
            zh = compose_natural_sentence([base_unique[p] for p in pick if p in base_unique])
            if zh:
                pairs.append((" ".join(pick), zh, "random_aug"))

    # De-duplicate by src_ids, keep first.
    seen = set()
    deduped = []
    for src, tgt, src_type in pairs:
        if src in seen:
            continue
        seen.add(src)
        deduped.append((src, tgt, src_type))

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["src_ids", "tgt_zh", "source"])
        for src, tgt, src_type in deduped:
            writer.writerow([src, tgt, src_type])
    return len(deduped)


def load_library_pairs(library_csv: Path) -> List[Pair]:
    pairs: List[Pair] = []
    with open(library_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            src = canonicalize_gloss_id_tokens(tokenize_src(row["src_ids"]))
            tgt = tokenize_tgt_zh(row["tgt_zh"])
            pairs.append(Pair(src_tokens=src, tgt_tokens=tgt))
    if not pairs:
        raise ValueError(f"No rows loaded from {library_csv}")
    return pairs


def load_exact_library_map(library_csv: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not library_csv.exists():
        return out
    with open(library_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            k = canonicalize_src_key(row.get("src_ids", "") or "")
            v = (row.get("tgt_zh", "") or "").strip()
            if k and v and k not in out:
                out[k] = v
    return out


def load_id_to_zh_from_manifest(manifest_csv: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not manifest_csv.exists():
        return out
    with open(manifest_csv, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ids = [x for x in row.get("target_ids", "").split() if x.strip()]
            zh = (row.get("target_words_zh", "") or "").strip()
            if len(ids) == 1 and zh:
                out[str(int(ids[0]))] = zh
    return out


def load_id_to_zh_from_gloss(gloss_csv: Path) -> dict[str, str]:
    if not gloss_csv.exists():
        return {}
    from glossary import load_id_to_zh_variants

    return load_id_to_zh_variants(gloss_csv)


def normalize_zh_gloss(word: str) -> str:
    """
    Convert glossary item to more natural Chinese:
    - remove sign variant suffix like 1-2 / 2-1
    - strip surrounding spaces
    """
    w = (word or "").strip()
    w = re.sub(r"\d+-\d+$", "", w).strip()
    return w


def compose_natural_sentence(words: List[str]) -> str:
    clean = [normalize_zh_gloss(w) for w in words if normalize_zh_gloss(w)]
    if not clean:
        return ""
    if len(clean) == 1:
        return clean[0]
    return "，".join(clean)


def _collapse_repeats(words: List[str]) -> List[str]:
    out: List[str] = []
    for w in words:
        if not out or out[-1] != w:
            out.append(w)
    return out


def dedupe_consecutive_id_tokens(seq: List[str]) -> List[str]:
    """
    折叠连续重复的 gloss id 字符串（如 ['17','17','42','17'] -> ['17','42','17']）。

    用于摄像头/视频实时草稿：若每帧追加同一预测 id，句子模型会得到「同一词反复出现」的译文。
    """
    out: List[str] = []
    for t in seq:
        s = str(t).strip()
        if not s:
            continue
        try:
            tid = int(s)
        except ValueError:
            if not out or out[-1] != s:
                out.append(s)
            continue
        if not out or int(out[-1]) != tid:
            out.append(str(tid))
    return out


def _strip_for_compare(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def _finalize_zh_punct(s: str) -> str:
    t = (s or "").strip()
    if not t:
        return t
    if t.endswith(("。", "！", "？", "…")):
        return t
    return f"{t}。"


def to_colloquial_sentence(raw_sentence: str, tokens_zh: List[str]) -> str:
    """
    口语化拼句：少量手搓句式 + 其余优先采用句子模型/上游 raw_sentence，
    避免多词时永远只显示「我想表达：词1，词2」而盖住真实译文。
    """
    words = [normalize_zh_gloss(w) for w in tokens_zh if normalize_zh_gloss(w)]
    words = _collapse_repeats(words)
    if not words:
        return raw_sentence

    wset = set(words)
    if "下班" in wset and "出事" in wset:
        return "我在下班的时候出事了。"
    if "停止" in wset:
        if len(words) > 1:
            return f"请先停一下，然后{compose_natural_sentence([w for w in words if w != '停止'])}。"
        return "请先停一下。"
    if "借" in wset:
        rest = [w for w in words if w != "借"]
        return f"我想借{compose_natural_sentence(rest)}。".replace("借。", "借一下。")

    composed = compose_natural_sentence(words)
    raw = (raw_sentence or "").strip()
    if raw and _strip_for_compare(raw) != _strip_for_compare(composed):
        return _finalize_zh_punct(raw)

    if len(words) == 1:
        return f"我想表达“{words[0]}”。"
    return f"我想表达：{composed}。"


def build_vocabs(pairs: List[Pair], min_freq: int = 1) -> Tuple[Vocab, Vocab]:
    src_vocab = Vocab([PAD, BOS, EOS, UNK])
    tgt_vocab = Vocab([PAD, BOS, EOS, UNK])
    src_freq: dict[str, int] = {}
    tgt_freq: dict[str, int] = {}
    for p in pairs:
        for t in p.src_tokens:
            src_freq[t] = src_freq.get(t, 0) + 1
        for t in p.tgt_tokens:
            tgt_freq[t] = tgt_freq.get(t, 0) + 1
    for t, c in sorted(src_freq.items()):
        if c >= min_freq:
            src_vocab.add(t)
    for t, c in sorted(tgt_freq.items()):
        if c >= min_freq:
            tgt_vocab.add(t)
    return src_vocab, tgt_vocab


class TranslationDataset(Dataset):
    def __init__(self, pairs: List[Pair], src_vocab: Vocab, tgt_vocab: Vocab, indices: np.ndarray):
        self.pairs = pairs
        self.src_vocab = src_vocab
        self.tgt_vocab = tgt_vocab
        self.indices = indices.astype(np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        p = self.pairs[self.indices[idx]]
        src = self.src_vocab.encode(p.src_tokens, add_bos_eos=True)
        tgt = self.tgt_vocab.encode(p.tgt_tokens, add_bos_eos=True)
        return torch.tensor(src, dtype=torch.long), torch.tensor(tgt, dtype=torch.long)


def collate_batch(batch, pad_id: int):
    srcs, tgts = zip(*batch)
    src_lens = [x.shape[0] for x in srcs]
    tgt_lens = [x.shape[0] for x in tgts]
    max_src = max(src_lens)
    max_tgt = max(tgt_lens)
    src_pad = torch.full((len(batch), max_src), pad_id, dtype=torch.long)
    tgt_pad = torch.full((len(batch), max_tgt), pad_id, dtype=torch.long)
    for i, (s, t) in enumerate(zip(srcs, tgts)):
        src_pad[i, : s.shape[0]] = s
        tgt_pad[i, : t.shape[0]] = t
    return src_pad, tgt_pad


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 512):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))  # [1, L, D]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, : x.shape[1]]


class Seq2SeqTransformer(nn.Module):
    def __init__(
        self,
        src_vocab_size: int,
        tgt_vocab_size: int,
        d_model: int = 256,
        nhead: int = 8,
        num_layers: int = 3,
        dim_ff: int = 512,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.src_emb = nn.Embedding(src_vocab_size, d_model)
        self.tgt_emb = nn.Embedding(tgt_vocab_size, d_model)
        self.pos = PositionalEncoding(d_model)
        self.tf = nn.Transformer(
            d_model=d_model,
            nhead=nhead,
            num_encoder_layers=num_layers,
            num_decoder_layers=num_layers,
            dim_feedforward=dim_ff,
            dropout=dropout,
            batch_first=True,
        )
        self.out = nn.Linear(d_model, tgt_vocab_size)
        self.d_model = d_model

    def forward(self, src: torch.Tensor, tgt_in: torch.Tensor, src_pad_mask: torch.Tensor, tgt_pad_mask: torch.Tensor):
        # src/tgt: [B, L]
        src_x = self.pos(self.src_emb(src) * np.sqrt(self.d_model))
        tgt_x = self.pos(self.tgt_emb(tgt_in) * np.sqrt(self.d_model))
        # Bool causal mask to match bool key_padding_mask and avoid warning.
        tgt_len = tgt_in.shape[1]
        tgt_mask = torch.triu(
            torch.ones((tgt_len, tgt_len), device=tgt_in.device, dtype=torch.bool),
            diagonal=1,
        )
        h = self.tf(
            src_x,
            tgt_x,
            tgt_mask=tgt_mask,
            src_key_padding_mask=src_pad_mask,
            tgt_key_padding_mask=tgt_pad_mask,
            memory_key_padding_mask=src_pad_mask,
        )
        return self.out(h)


def split_indices(n: int, test_ratio: float, seed: int):
    rng = np.random.default_rng(seed)
    idx = np.arange(n, dtype=np.int64)
    rng.shuffle(idx)
    n_test = max(1, int(n * test_ratio))
    return idx[n_test:], idx[:n_test]


def token_accuracy(logits: torch.Tensor, target: torch.Tensor, pad_id: int) -> float:
    pred = logits.argmax(dim=-1)
    mask = target != pad_id
    if mask.sum().item() == 0:
        return 0.0
    return float((pred[mask] == target[mask]).float().mean().item())


def run_epoch(model, loader, criterion, optimizer, device, pad_id: int):
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total_acc = 0.0
    steps = 0
    for src, tgt in tqdm(loader, leave=False):
        src = src.to(device)
        tgt = tgt.to(device)
        tgt_in = tgt[:, :-1]
        tgt_out = tgt[:, 1:]

        src_pad = src.eq(pad_id)
        tgt_pad = tgt_in.eq(pad_id)
        with torch.set_grad_enabled(is_train):
            logits = model(src, tgt_in, src_pad, tgt_pad)
            loss = criterion(logits.reshape(-1, logits.shape[-1]), tgt_out.reshape(-1))
            if is_train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        total_loss += float(loss.item())
        total_acc += token_accuracy(logits, tgt_out, pad_id)
        steps += 1
    return {"loss": total_loss / max(1, steps), "token_acc": total_acc / max(1, steps)}


def greedy_translate(
    model: Seq2SeqTransformer,
    src_ids: List[int],
    src_vocab: Vocab,
    tgt_vocab: Vocab,
    device: torch.device,
    max_len: int = 32,
) -> str:
    model.eval()
    src = torch.tensor([src_ids], dtype=torch.long, device=device)
    src_pad = src.eq(src_vocab.stoi[PAD])
    ys = torch.tensor([[tgt_vocab.stoi[BOS]]], dtype=torch.long, device=device)
    for _ in range(max_len):
        tgt_pad = ys.eq(tgt_vocab.stoi[PAD])
        with torch.no_grad():
            logits = model(src, ys, src_pad, tgt_pad)
            next_id = int(logits[:, -1, :].argmax(dim=-1).item())
        ys = torch.cat([ys, torch.tensor([[next_id]], device=device)], dim=1)
        if next_id == tgt_vocab.stoi[EOS]:
            break
    toks = tgt_vocab.decode(ys.squeeze(0).tolist(), stop_at_eos=True)
    return "".join(toks)


def save_artifacts(
    output_dir: Path,
    model: Seq2SeqTransformer,
    src_vocab: Vocab,
    tgt_vocab: Vocab,
    history: dict,
    cfg: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), output_dir / "best_interpretive_scheme.pt")
    with open(output_dir / "src_vocab.json", "w", encoding="utf-8") as f:
        json.dump(src_vocab.itos, f, ensure_ascii=False, indent=2)
    with open(output_dir / "tgt_vocab.json", "w", encoding="utf-8") as f:
        json.dump(tgt_vocab.itos, f, ensure_ascii=False, indent=2)
    with open(output_dir / "history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
    with open(output_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def train(args):
    set_seed(args.seed)
    base = Path(__file__).resolve().parent
    manifest = (base / args.manifest_csv).resolve()
    library_csv = (base / args.library_csv).resolve()
    output_dir = (base / args.output_dir).resolve()

    if args.auto_build_library:
        gloss_csv = resolve_library_gloss_csv(base, getattr(args, "library_gloss_csv", ""))
        num_rows = build_translation_library(
            manifest_csv=manifest,
            output_csv=library_csv,
            min_len=args.library_min_len,
            max_len=args.library_max_len,
            augment_random=args.library_augment_random,
            seed=args.seed,
            gloss_csv=gloss_csv,
        )
        print(f"Built translation library: {library_csv} (rows={num_rows})")

    if library_csv.exists():
        pairs = load_library_pairs(library_csv)
        print(f"Training from translation library: {library_csv} (pairs={len(pairs)})")
    else:
        pairs = load_manifest_pairs(manifest)
        print(f"Library not found, fallback to manifest pairs: {manifest} (pairs={len(pairs)})")
    train_idx, test_idx = split_indices(len(pairs), test_ratio=0.2, seed=args.seed)
    src_vocab, tgt_vocab = build_vocabs(pairs, min_freq=1)

    train_ds = TranslationDataset(pairs, src_vocab, tgt_vocab, train_idx)
    test_ds = TranslationDataset(pairs, src_vocab, tgt_vocab, test_idx)
    pad_id = src_vocab.stoi[PAD]
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        collate_fn=lambda b: collate_batch(b, pad_id),
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        collate_fn=lambda b: collate_batch(b, pad_id),
    )

    # Training default: require GPU unless explicitly --cpu.
    try:
        from training_io import resolve_training_device

        device = resolve_training_device(force_cpu=bool(getattr(args, "cpu", False)))
    except Exception:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Seq2SeqTransformer(
        src_vocab_size=src_vocab.size,
        tgt_vocab_size=tgt_vocab.size,
        d_model=args.d_model,
        nhead=args.nhead,
        num_layers=args.num_layers,
        dim_ff=args.dim_ff,
        dropout=args.dropout,
    ).to(device)
    criterion = nn.CrossEntropyLoss(ignore_index=tgt_vocab.stoi[PAD])
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    history = {"train_loss": [], "train_token_acc": [], "test_loss": [], "test_token_acc": []}
    best = -1.0
    for ep in range(1, args.epochs + 1):
        tr = run_epoch(model, train_loader, criterion, optimizer, device, pad_id=tgt_vocab.stoi[PAD])
        te = run_epoch(model, test_loader, criterion, None, device, pad_id=tgt_vocab.stoi[PAD])
        history["train_loss"].append(tr["loss"])
        history["train_token_acc"].append(tr["token_acc"])
        history["test_loss"].append(te["loss"])
        history["test_token_acc"].append(te["token_acc"])
        if te["token_acc"] > best:
            best = te["token_acc"]
            save_artifacts(
                output_dir,
                model,
                src_vocab,
                tgt_vocab,
                history,
                {
                    "manifest_csv": str(manifest),
                    "library_csv": str(library_csv),
                    "d_model": args.d_model,
                    "nhead": args.nhead,
                    "num_layers": args.num_layers,
                    "dim_ff": args.dim_ff,
                },
            )
        print(
            f"Epoch [{ep}/{args.epochs}] "
            f"train_loss={tr['loss']:.4f} train_token_acc={tr['token_acc']:.4f} "
            f"test_loss={te['loss']:.4f} test_token_acc={te['token_acc']:.4f}"
        )
    print(f"Best test token accuracy: {best:.4f}")
    print(f"Saved model and vocab to: {output_dir}")


def load_vocab(path: Path) -> Vocab:
    with open(path, "r", encoding="utf-8") as f:
        itos = json.load(f)
    vocab = Vocab([])
    vocab.itos = itos
    vocab.stoi = {t: i for i, t in enumerate(itos)}
    return vocab


def translate(args):
    base = Path(__file__).resolve().parent
    model_dir = (base / args.model_dir).resolve()
    src_vocab = load_vocab(model_dir / "src_vocab.json")
    tgt_vocab = load_vocab(model_dir / "tgt_vocab.json")
    with open(model_dir / "config.json", "r", encoding="utf-8") as f:
        cfg = json.load(f)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Seq2SeqTransformer(
        src_vocab_size=src_vocab.size,
        tgt_vocab_size=tgt_vocab.size,
        d_model=cfg["d_model"],
        nhead=cfg["nhead"],
        num_layers=cfg["num_layers"],
        dim_ff=cfg["dim_ff"],
        dropout=0.0,
    ).to(device)
    # Future-proof safe loading.
    try:
        state = torch.load(model_dir / "best_interpretive_scheme.pt", map_location=device, weights_only=True)
    except TypeError:
        state = torch.load(model_dir / "best_interpretive_scheme.pt", map_location=device)
    model.load_state_dict(state)
    model.eval()

    src_tokens = canonicalize_gloss_id_tokens(tokenize_src(args.gloss_ids))
    exact_map = load_exact_library_map(Path(__file__).resolve().parent / "outputs" / "translation_library.csv")
    exact_key = " ".join(src_tokens)
    if exact_key in exact_map:
        zh = normalize_zh_gloss(exact_map[exact_key])
    else:
        src_ids = src_vocab.encode(src_tokens, add_bos_eos=True)
        # Reduce noisy framework warnings in user-facing CLI output.
        warnings.filterwarnings("ignore", category=UserWarning, module="torch.nn.modules.transformer")
        warnings.filterwarnings("ignore", category=UserWarning, module="torch.nn.functional")
        zh = greedy_translate(model, src_ids, src_vocab, tgt_vocab, device=device, max_len=args.max_len)
        zh = normalize_zh_gloss(zh)

    # Always build word tokens for user-visible debugging + colloquial postprocess.
    manifest_map = load_id_to_zh_from_manifest(model_dir.parent / "cslr_manifest.csv")
    gloss_map = load_id_to_zh_from_gloss(Path(__file__).resolve().parent.parent / "gloss.csv")
    tokens_zh: List[str] = []
    for t in src_tokens:
        key = str(int(t)) if t.isdigit() else t
        word = manifest_map.get(key) or gloss_map.get(key)
        if word:
            tokens_zh.append(word)

    if not zh.strip():
        # Fallback: deterministic gloss-id dictionary translation to avoid empty output.
        zh = compose_natural_sentence(tokens_zh or [f"[{t}]" for t in src_tokens])

    final_zh = to_colloquial_sentence(zh, tokens_zh)

    print("Input gloss ids:", " ".join(src_tokens))
    print("Gloss words:", compose_natural_sentence(tokens_zh) if tokens_zh else "（未在 gloss.csv / manifest 中找到对应中文词）")
    print("Chinese translation:", final_zh)


def resolve_library_gloss_csv(base: Path, library_gloss_csv_arg: str) -> Path | None:
    if library_gloss_csv_arg.strip():
        gp = Path(library_gloss_csv_arg.strip())
        p = gp.resolve() if gp.is_absolute() else (base / gp).resolve()
        return p if p.exists() else None
    cand = (base.parent / "gloss.csv").resolve()
    return cand if cand.exists() else None


def build_library_cli(args: argparse.Namespace) -> None:
    """Write outputs/translation_library.csv from manifest + optional gloss.csv (no training)."""
    base = Path(__file__).resolve().parent
    manifest = (base / args.manifest_csv).resolve()
    library_csv = (base / args.library_csv).resolve()
    gloss_csv = resolve_library_gloss_csv(base, getattr(args, "library_gloss_csv", ""))
    n = build_translation_library(
        manifest_csv=manifest,
        output_csv=library_csv,
        min_len=args.library_min_len,
        max_len=args.library_max_len,
        augment_random=args.library_augment_random,
        seed=args.seed,
        gloss_csv=gloss_csv,
    )
    print(f"Wrote {library_csv} (rows={n})")


def main():
    parser = argparse.ArgumentParser(description="interpretive_scheme: end-to-end gloss->Chinese translation")
    sub = parser.add_subparsers(dest="cmd", required=False)

    p_train = sub.add_parser("train", help="Train translation model from cslr_manifest.csv")
    p_train.add_argument("--manifest_csv", type=str, default="outputs/cslr_manifest.csv")
    p_train.add_argument("--library_csv", type=str, default="outputs/translation_library.csv")
    p_train.add_argument("--auto_build_library", action="store_true", default=True)
    p_train.add_argument("--library_min_len", type=int, default=1)
    p_train.add_argument("--library_max_len", type=int, default=4)
    p_train.add_argument(
        "--library_augment_random",
        type=int,
        default=-1,
        help="随机组合增强条数；<0 时按词表规模自动取（上限 80000）。",
    )
    p_train.add_argument(
        "--library_gloss_csv",
        type=str,
        default="",
        help="gloss.csv 路径；默认空则使用上级目录 gloss.csv（若存在），把约 6k 单字词条并入 translation_library。",
    )
    p_train.add_argument("--output_dir", type=str, default="outputs/interpretive_scheme")
    p_train.add_argument("--epochs", type=int, default=80)
    p_train.add_argument("--batch_size", type=int, default=16)
    p_train.add_argument("--lr", type=float, default=1e-3)
    p_train.add_argument("--weight_decay", type=float, default=1e-4)
    p_train.add_argument("--d_model", type=int, default=128)
    p_train.add_argument("--nhead", type=int, default=4)
    p_train.add_argument("--num_layers", type=int, default=2)
    p_train.add_argument("--dim_ff", type=int, default=256)
    p_train.add_argument("--dropout", type=float, default=0.1)
    p_train.add_argument("--seed", type=int, default=42)
    p_train.add_argument(
        "--cpu",
        action="store_true",
        help="强制使用 CPU（默认无 GPU 时会报错退出，不进行 CPU 训练）",
    )

    p_lib = sub.add_parser("build-library", help="仅根据 manifest + gloss 生成 translation_library.csv（不训练）")
    p_lib.add_argument("--manifest_csv", type=str, default="outputs/cslr_manifest.csv")
    p_lib.add_argument("--library_csv", type=str, default="outputs/translation_library.csv")
    p_lib.add_argument("--library_min_len", type=int, default=1)
    p_lib.add_argument("--library_max_len", type=int, default=4)
    p_lib.add_argument(
        "--library_augment_random",
        type=int,
        default=-1,
        help="随机组合增强条数；<0 时按词表规模自动取（上限 80000）。",
    )
    p_lib.add_argument(
        "--library_gloss_csv",
        type=str,
        default="",
        help="gloss.csv 路径；默认空则使用上级目录 gloss.csv（若存在）。",
    )
    p_lib.add_argument("--seed", type=int, default=42)

    p_trans = sub.add_parser("translate", help="Translate a gloss id sequence to Chinese")
    p_trans.add_argument("--model_dir", type=str, default="outputs/interpretive_scheme")
    p_trans.add_argument("--gloss_ids", type=str, required=True, help='Example: "72 158 810"')
    p_trans.add_argument("--max_len", type=int, default=32)

    args = parser.parse_args()
    if args.cmd is None:
        print("interpretive_scheme 交互模式")
        print("1) 训练模型 (train)")
        print("2) 翻译句子 (translate)")
        print("3) 查看帮助")
        choice = input("请选择 [1/2/3] (默认 2): ").strip() or "2"

        if choice == "1":
            train_args = argparse.Namespace(
                manifest_csv="outputs/cslr_manifest.csv",
                library_csv="outputs/translation_library.csv",
                auto_build_library=True,
                library_min_len=1,
                library_max_len=4,
                library_augment_random=-1,
                library_gloss_csv="",
                output_dir="outputs/interpretive_scheme",
                epochs=80,
                batch_size=16,
                lr=1e-3,
                weight_decay=1e-4,
                d_model=128,
                nhead=4,
                num_layers=2,
                dim_ff=256,
                dropout=0.1,
                seed=42,
            )
            print("使用默认参数开始训练，可用命令行参数自定义。")
            train(train_args)
            return
        if choice == "2":
            gloss_ids = input('请输入 gloss ids（例如 "72 158 810"）: ').strip()
            if not gloss_ids:
                print("未输入 gloss ids，退出。")
                return
            trans_args = argparse.Namespace(
                model_dir="outputs/interpretive_scheme",
                gloss_ids=gloss_ids,
                max_len=32,
            )
            translate(trans_args)
            return

        parser.print_help()
        print("\nExamples:")
        print("  Train:")
        print("    python interpretive_scheme.py train --manifest_csv outputs/cslr_manifest.csv --epochs 80")
        print('  Translate:')
        print('    python interpretive_scheme.py translate --model_dir outputs/interpretive_scheme --gloss_ids "72 158 810"')
        print("  Build library only:")
        print("    python interpretive_scheme.py build-library")
        return

    if args.cmd == "train":
        train(args)
    elif args.cmd == "build-library":
        build_library_cli(args)
    else:
        translate(args)


if __name__ == "__main__":
    main()
