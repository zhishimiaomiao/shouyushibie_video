from __future__ import annotations

import argparse
import random
from pathlib import Path
from typing import Dict

import numpy as np
import torch
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import SignFeatureDataset, load_lsnu_feature_samples
from models import SignRecognizer
from training_io import (
    CHECKPOINT_LAST,
    append_training_run_index,
    finalize_train_log,
    init_train_log,
    resolve_training_device,
    maybe_save_epoch_weights,
    resolve_resume_path,
    resolve_run_dir,
    resume_from_checkpoint,
    save_training_checkpoint,
    should_append_run_index,
    try_run_reports,
    write_history_atomic,
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def run_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: AdamW | None,
    device: torch.device,
    grad_clip_norm: float = 0.0,
) -> Dict[str, float]:
    is_train = optimizer is not None
    model.train(is_train)

    all_preds = []
    all_labels = []
    total_loss = 0.0

    for x, y in tqdm(loader, leave=False):
        x = x.to(device)
        y = y.to(device)

        with torch.set_grad_enabled(is_train):
            logits = model(x)
            loss = criterion(logits, y)
            if is_train:
                optimizer.zero_grad()
                loss.backward()
                if grad_clip_norm and grad_clip_norm > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(grad_clip_norm))
                optimizer.step()

        total_loss += loss.item() * x.size(0)
        all_preds.append(logits.argmax(dim=1).detach().cpu().numpy())
        all_labels.append(y.detach().cpu().numpy())

    preds = np.concatenate(all_preds)
    labels = np.concatenate(all_labels)
    acc = float((labels == preds).mean())
    avg_loss = total_loss / len(loader.dataset)
    return {"loss": avg_loss, "acc": float(acc)}


def stratified_split(indices: np.ndarray, labels: np.ndarray, test_ratio: float, seed: int):
    rng = np.random.default_rng(seed)
    train_idx = []
    test_idx = []
    for class_id in np.unique(labels):
        cls_indices = indices[labels == class_id]
        rng.shuffle(cls_indices)
        n_test = max(1, int(len(cls_indices) * test_ratio))
        test_idx.extend(cls_indices[:n_test].tolist())
        train_idx.extend(cls_indices[n_test:].tolist())
    rng.shuffle(train_idx)
    rng.shuffle(test_idx)
    return np.array(train_idx, dtype=np.int64), np.array(test_idx, dtype=np.int64)


def main() -> None:
    parser = argparse.ArgumentParser(description="Sign language recognition trainer")
    parser.add_argument("--data_root", type=str, default=r"..\Code\tech code\LSNU-SCL_feature_768")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--hidden_dim", type=int, default=512)
    parser.add_argument("--temporal", type=str, default="bilstm", choices=["bilstm", "transformer", "tcn"])
    parser.add_argument("--dropout", type=float, default=0.2, help="Model dropout (default matches models.py)")
    parser.add_argument("--label_smoothing", type=float, default=0.0, help="CrossEntropy label smoothing (0=off)")
    parser.add_argument(
        "--scheduler",
        type=str,
        default="plateau",
        choices=["none", "plateau", "cosine"],
        help="LR scheduler: plateau uses ReduceLROnPlateau on test loss; cosine uses CosineAnnealingLR",
    )
    parser.add_argument("--min_lr", type=float, default=1e-6, help="plateau: min lr; cosine: eta_min")
    parser.add_argument("--plateau_factor", type=float, default=0.5, help="ReduceLROnPlateau factor")
    parser.add_argument("--plateau_patience", type=int, default=3, help="ReduceLROnPlateau patience (epochs)")
    parser.add_argument("--grad_clip_norm", type=float, default=0.0, help="Clip grad norm (0=off)")
    parser.add_argument("--early_stop_patience", type=int, default=10, help="Stop if no test acc improve for N epochs (0=off)")
    parser.add_argument("--early_stop_min_delta", type=float, default=0.0, help="Min test acc delta to count as improvement")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", type=str, default="outputs")
    parser.add_argument(
        "--run_name",
        type=str,
        default=None,
        help="本次运行子目录名；默认自动生成带时间的 run_YYYY-mm-dd_HHMMSS",
    )
    parser.add_argument(
        "--flat_output",
        action="store_true",
        help="不使用时间戳子目录，直接写入 output_dir（会覆盖同名文件）",
    )
    parser.add_argument(
        "--resume",
        type=str,
        default=None,
        help="从 checkpoint_last.pt 继续训练（需与当前模型结构一致）",
    )
    parser.add_argument(
        "--epoch_ckpt_every",
        type=int,
        default=0,
        help="每 N 个 epoch 额外保存仅权重的快照 epoch_weights_epoch_NNN.pt；0 表示关闭",
    )
    parser.add_argument("--auto_report", action="store_true", help="训练结束后自动生成 reports/ 图+表")
    parser.add_argument("--reports_dir", type=str, default="reports", help="auto_report 输出目录（相对当前脚本目录）")
    parser.add_argument("--report_limit", type=int, default=20, help="auto_report 仅汇总最近 N 个 runs（0=全部）")
    parser.add_argument(
        "--write_runs_index",
        action="store_true",
        help="在 output 根目录追加 training_runs_index.jsonl（默认关闭）",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="强制使用 CPU（默认无 GPU 时会报错退出，不进行 CPU 训练）",
    )
    args = parser.parse_args()

    set_seed(args.seed)
    base_dir = Path(__file__).resolve().parent
    data_root = (base_dir / args.data_root).resolve()
    output_base = (base_dir / args.output_dir).resolve()
    resume_p = resolve_resume_path(base_dir, args.resume) if args.resume else None
    run_dir, run_label = resolve_run_dir(output_base, args.run_name, args.flat_output, resume_p)
    init_train_log(run_dir, args, "train.py", run_label)
    append_training_run_index(
        output_base,
        run_label,
        run_dir,
        append=should_append_run_index(resume_p, args.run_name, run_dir),
        enabled=bool(args.write_runs_index),
    )

    samples = load_lsnu_feature_samples(data_root)
    labels = np.array([s.label for s in samples], dtype=np.int64)
    indices = np.arange(len(samples))

    train_idx, test_idx = stratified_split(indices, labels, test_ratio=0.2, seed=args.seed)
    train_set = SignFeatureDataset(samples, train_idx)
    test_set = SignFeatureDataset(samples, test_idx)

    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0)
    test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=0)

    device = resolve_training_device(force_cpu=bool(args.cpu))
    model = SignRecognizer(
        input_dim=768,
        hidden_dim=args.hidden_dim,
        num_classes=int(labels.max()) + 1,
        temporal_type=args.temporal,
        dropout=float(args.dropout),
    ).to(device)

    try:
        criterion = nn.CrossEntropyLoss(label_smoothing=float(args.label_smoothing))
    except TypeError:
        criterion = nn.CrossEntropyLoss()
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = None
    if args.scheduler == "cosine":
        scheduler = CosineAnnealingLR(optimizer, T_max=int(args.epochs), eta_min=float(args.min_lr))
    elif args.scheduler == "plateau":
        scheduler = ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(args.plateau_factor),
            patience=int(args.plateau_patience),
            min_lr=float(args.min_lr),
            verbose=False,
        )

    history = {"train_loss": [], "train_acc": [], "test_loss": [], "test_acc": []}
    best_acc = 0.0
    best_epoch = 0
    no_improve = 0
    best_path = run_dir / "best_model.pt"
    start_epoch = 1
    if args.resume:
        if not resume_p.is_file():
            raise FileNotFoundError(f"Resume checkpoint not found: {resume_p}")
        rs = resume_from_checkpoint(resume_p, model, optimizer, scheduler, device, default_history=history)
        start_epoch = rs.start_epoch
        history = rs.history
        best_acc = rs.best_metric
        best_epoch = int(np.argmax(np.asarray(history.get("test_acc", [0.0]), dtype=np.float64))) + 1 if history.get("test_acc") else 0
        print(f"Resumed from epoch {start_epoch - 1}, best_test_acc={best_acc:.6f}, run_dir={run_dir}")

    for epoch in range(start_epoch, args.epochs + 1):
        train_metrics = run_epoch(model, train_loader, criterion, optimizer, device, grad_clip_norm=float(args.grad_clip_norm))
        test_metrics = run_epoch(model, test_loader, criterion, None, device, grad_clip_norm=0.0)

        history["train_loss"].append(train_metrics["loss"])
        history["train_acc"].append(train_metrics["acc"])
        history["test_loss"].append(test_metrics["loss"])
        history["test_acc"].append(test_metrics["acc"])

        improved = (test_metrics["acc"] - best_acc) > float(args.early_stop_min_delta)
        if improved:
            best_acc = test_metrics["acc"]
            best_epoch = epoch
            no_improve = 0
            torch.save(model.state_dict(), best_path)
        else:
            no_improve += 1

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(float(test_metrics["loss"]))
            else:
                scheduler.step()
        cur_lr = float(optimizer.param_groups[0]["lr"])

        write_history_atomic(run_dir, history)
        save_training_checkpoint(
            run_dir / CHECKPOINT_LAST,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            epoch=epoch,
            history=history,
            best_metric=best_acc,
            metric_name="test_acc",
            extra={"epochs_target": args.epochs, "best_epoch": best_epoch, "scheduler": args.scheduler, "lr": cur_lr},
        )
        maybe_save_epoch_weights(run_dir, model, epoch, args.epoch_ckpt_every, prefix="epoch_weights")

        print(
            f"Epoch [{epoch}/{args.epochs}] "
            f"Train Loss={train_metrics['loss']:.4f}, Train Acc={train_metrics['acc']:.4f} | "
            f"Test Loss={test_metrics['loss']:.4f}, Test Acc={test_metrics['acc']:.4f} lr={cur_lr:.2e}"
        )

        if args.early_stop_patience > 0 and no_improve >= int(args.early_stop_patience):
            print(
                f"Early stopping: no test_acc improvement for {no_improve} epochs "
                f"(best={best_acc:.4f} at epoch {best_epoch})."
            )
            break

    metrics = {
        "best_test_accuracy": best_acc,
        "best_epoch": best_epoch,
        "epochs_ran": len(history.get("test_acc", [])),
        "num_classes": int(labels.max()) + 1,
        "num_train_samples": len(train_set),
        "num_test_samples": len(test_set),
        "temporal_model": args.temporal,
        "dropout": float(args.dropout),
        "scheduler": args.scheduler,
        "label_smoothing": float(args.label_smoothing),
        "early_stop_patience": int(args.early_stop_patience),
        "early_stop_min_delta": float(args.early_stop_min_delta),
        "run_dir": str(run_dir),
        "run_label": run_label,
        "resume_from": str(resolve_resume_path(base_dir, args.resume)) if args.resume else None,
    }
    finalize_train_log(
        run_dir,
        script="train.py",
        run_label=run_label,
        args=args,
        history=history,
        metrics=metrics,
    )
    print(f"Best test accuracy: {best_acc:.4f}")
    print(f"Run directory: {run_dir}")
    print(f"Saved {CHECKPOINT_LAST}, best_model.pt, 训练记录.json under run directory.")
    if args.auto_report:
        try_run_reports(base_dir, outputs_dir=output_base, reports_dir=(base_dir / args.reports_dir).resolve(), limit=int(args.report_limit))


if __name__ == "__main__":
    main()
