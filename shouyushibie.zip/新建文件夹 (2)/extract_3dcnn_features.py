from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
import torch
from torch import nn

from glossary import (
    dedupe_video_paths_by_basename,
    gloss_video_coverage_report,
    iter_video_paths_many,
    resolve_script_path,
    video_feature_key,
)

try:
    from torchvision.models.video import r3d_18
    HAS_TORCHVISION = True
except Exception:
    HAS_TORCHVISION = False
    r3d_18 = None


class Lightweight3DCNN(nn.Module):
    """
    Fallback 3D-CNN when torchvision is unavailable.
    """

    def __init__(self, out_dim: int = 256):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv3d(3, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2)),
            nn.Conv3d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=2, stride=2),
            nn.Conv3d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm3d(128),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool3d((1, 1, 1)),
        )
        self.head = nn.Linear(128, out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x).flatten(1)
        return self.head(x)


def build_3d_model(device: torch.device):
    if HAS_TORCHVISION:
        model = r3d_18(weights="DEFAULT")
        model.fc = nn.Identity()
        model.eval().to(device)
        print("Using torchvision r3d_18 pretrained backbone.")
        return model

    model = Lightweight3DCNN(out_dim=256).eval().to(device)
    print("torchvision not found, using fallback Lightweight3DCNN.")
    return model


def load_video_clip(video_path: Path, num_frames: int = 16, size: int = 112) -> torch.Tensor:
    cap = cv2.VideoCapture(str(video_path))
    frames = []
    while len(frames) < num_frames:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = cv2.resize(frame, (size, size))
        frames.append(frame)
    cap.release()

    if not frames:
        arr = np.zeros((num_frames, size, size, 3), dtype=np.float32)
    else:
        arr = np.array(frames, dtype=np.float32)
        if arr.shape[0] < num_frames:
            pad = np.zeros((num_frames - arr.shape[0], size, size, 3), dtype=np.float32)
            arr = np.concatenate([arr, pad], axis=0)
        arr = arr[:num_frames]

    arr = arr / 255.0
    # [T, H, W, C] -> [C, T, H, W]
    tensor = torch.from_numpy(arr).permute(3, 0, 1, 2).float()
    return tensor


def build_fallback_arrays_from_csv(feature_dir: Path):
    """Stack CSV rows into NPZ-friendly arrays (avoids multi‑GB JSON)."""
    csv_files = sorted(feature_dir.glob("*.csv"))
    if not csv_files:
        return None, None

    keys_list = []
    rows = []
    for csv_file in csv_files:
        person = csv_file.stem
        values = np.loadtxt(csv_file, delimiter=",", dtype=np.float32)
        if values.ndim == 1:
            values = values.reshape(1, -1)
        for class_id in range(values.shape[0]):
            keys_list.append(f"{class_id:04d}_{person}.mp4")
            rows.append(values[class_id, :768])
    return np.asarray(keys_list, dtype=object), np.stack(rows, axis=0).astype(np.float32)


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract 3D-CNN features from videos")
    parser.add_argument(
        "--video_dir",
        action="append",
        default=None,
        metavar="DIR",
        help=(
            "Video root to scan recursively. Pass multiple times to merge several folders "
            "(e.g. different drives or dataset splits). Relative paths are under sign_language_system. "
            "Default: ../Videos if omitted."
        ),
    )
    parser.add_argument(
        "--gloss_csv",
        type=str,
        default=r"..\gloss.csv",
        help="If this file exists, print coverage vs scanned videos (how many gloss IDs have a file).",
    )
    parser.add_argument(
        "--no_gloss_report",
        action="store_true",
        help="Do not print gloss vs video coverage (default: print when gloss_csv exists).",
    )
    parser.add_argument("--image_dir", type=str, default=r"..\Pics")
    parser.add_argument(
        "--output",
        type=str,
        default="outputs/video_3dcnn_features.npz",
        help="Default .npz for CSV fallback (small on disk); real 3D-CNN export is written as .json (same stem).",
    )
    parser.add_argument("--num_frames", type=int, default=16)
    parser.add_argument("--size", type=int, default=112)
    parser.add_argument("--fallback_feature_dir", type=str, default=r"..\Code\tech code\LSNU-SCL_feature_768")
    parser.add_argument(
        "--strict_input",
        action="store_true",
        help="Raise error when no media found (default: auto-create empty json and continue).",
    )
    parser.add_argument(
        "--dedupe_same_basename",
        action="store_true",
        help=(
            "Keep only the first path when the same filename appears under different folders. "
            "Default off: each file is kept and JSON keys use paths like Participant_01/0072.mp4."
        ),
    )
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    rel_dirs = args.video_dir if args.video_dir else [r"..\Videos"]
    video_roots = [resolve_script_path(base_dir, d) for d in rel_dirs]
    image_dir = (base_dir / args.image_dir).resolve()
    gloss_csv = resolve_script_path(base_dir, args.gloss_csv)
    fallback_feature_dir = (base_dir / args.fallback_feature_dir).resolve()
    output_path = (base_dir / args.output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    print("Video roots (merged):")
    for root in video_roots:
        tag = "ok" if root.is_dir() else "MISSING - skipped"
        print(f"  {root}  ({tag})")
    video_files = iter_video_paths_many(video_roots)
    if args.dedupe_same_basename:
        video_files, nd_dup = dedupe_video_paths_by_basename(video_files)
        if nd_dup:
            print(
                f"Note: skipped {nd_dup} path(s) (--dedupe_same_basename: one path per filename)."
            )
    else:
        print(
            "Feature keys = path relative to each --video_dir root (e.g. Participant_01/0072.mp4); "
            "same basename under different folders stays distinct."
        )
    if not args.no_gloss_report:
        print("--- gloss vs videos ---")
        print(gloss_video_coverage_report(gloss_csv, video_files))
        print("--- end report ---")
    if not video_files:
        roots_hint = ", ".join(str(r) for r in video_roots)
        image_files = sorted(
            list(image_dir.rglob("*.jpg"))
            + list(image_dir.rglob("*.jpeg"))
            + list(image_dir.rglob("*.png"))
            + list(image_dir.rglob("*.bmp"))
            + list(image_dir.rglob("*.JPG"))
            + list(image_dir.rglob("*.JPEG"))
            + list(image_dir.rglob("*.PNG"))
            + list(image_dir.rglob("*.BMP"))
        )
        if image_files:
            print(f"No videos found under: {roots_hint}. Found {len(image_files)} images in {image_dir}.")
            print("Tip: this script extracts 3D video features; for image-only data, please provide videos or use pose/image pipeline.")
        else:
            msg = (
                f"No videos found under merged roots ({roots_hint}), and no images in {image_dir}. "
                "Add the full dataset or pass more --video_dir paths (absolute paths allowed)."
            )
            keys_arr, rgb_arr = build_fallback_arrays_from_csv(fallback_feature_dir)
            if keys_arr is not None and len(keys_arr) > 0:
                npz_path = output_path if output_path.suffix.lower() == ".npz" else output_path.with_suffix(".npz")
                np.savez_compressed(npz_path, keys=keys_arr, rgb=rgb_arr)
                try:
                    rel = npz_path.relative_to(base_dir)
                except ValueError:
                    rel = npz_path
                print(msg)
                print(
                    f"Fallback: {len(keys_arr)} samples from CSV -> {rel} "
                    f"(768-dim vectors, compressed; use with train_fusion --rgb_json {rel.as_posix()})"
                )
                return
            if args.strict_input:
                raise FileNotFoundError(msg)
            empty_path = output_path if output_path.suffix.lower() == ".json" else output_path.with_suffix(".json")
            with open(empty_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            print(msg)
            print(f"Created empty feature file: {empty_path}")
            return

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_3d_model(device)

    output = {}
    with torch.no_grad():
        for vp in video_files:
            key = video_feature_key(vp, video_roots)
            clip = load_video_clip(vp, num_frames=args.num_frames, size=args.size).unsqueeze(0).to(device)
            feat = model(clip).squeeze(0).cpu().numpy().astype(np.float32)
            output[key] = feat.tolist()
            print(f"Processed: {key}, feature_dim={feat.shape[0]}")

    json_path = output_path if output_path.suffix.lower() == ".json" else output_path.with_suffix(".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(output, f)
    print(f"Saved 3D-CNN features (JSON) to: {json_path}")


if __name__ == "__main__":
    main()
