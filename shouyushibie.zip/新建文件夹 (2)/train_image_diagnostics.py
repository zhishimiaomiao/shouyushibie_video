"""
train_image 训练结束后的可选诊断：混淆矩阵 PNG + CSV + 简要文本报告。
无界面环境使用 matplotlib Agg；不依赖 seaborn（可选）。
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np


def _confusion_matrix_np(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int) -> np.ndarray:
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true.astype(np.int64).ravel(), y_pred.astype(np.int64).ravel()):
        if 0 <= int(t) < num_classes and 0 <= int(p) < num_classes:
            cm[int(t), int(p)] += 1
    return cm


def save_confusion_bundle(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
    run_dir: Path,
    *,
    max_label_chars: int = 12,
) -> None:
    """
    写入 run_dir:
      - confusion_matrix.csv
      - confusion_matrix.png（类别过多时仅显示数值矩阵，标签缩写）
      - confusion_report.txt（每类召回率、最易混 pred）
    """
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    num_classes = len(class_names)
    if num_classes <= 0:
        return

    try:
        from sklearn.metrics import confusion_matrix as sk_cm

        cm = sk_cm(y_true, y_pred, labels=list(range(num_classes)))
    except Exception:
        cm = _confusion_matrix_np(y_true, y_pred, num_classes)

    np.savetxt(run_dir / "confusion_matrix.csv", cm.astype(np.int64), delimiter=",", fmt="%d")

    # text report
    lines = ["混淆矩阵对角线为正确分类计数。", "行为真实类索引，列为预测类索引。", ""]
    row_sums = cm.sum(axis=1).astype(np.float64)
    for i in range(num_classes):
        rs = row_sums[i]
        hit = float(cm[i, i])
        rec = (hit / rs) if rs > 0 else 0.0
        wrong = int(rs - hit)
        # best wrong column
        row = cm[i].copy()
        row[i] = 0
        worst_j = int(np.argmax(row)) if num_classes > 1 else 0
        name_i = str(class_names[i])[:max_label_chars]
        lines.append(f"class[{i:03d}] {name_i!s}: recall={rec:.4f} n={int(rs)} wrong_to_other={wrong}")
        if wrong > 0 and num_classes > 1:
            lines.append(f"    most_confused_with -> [{worst_j:03d}] {str(class_names[worst_j])[:max_label_chars]!s} count={int(row[worst_j])}")
    (run_dir / "confusion_report.txt").write_text("\n".join(lines), encoding="utf-8")

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig_w = min(22, 6 + num_classes * 0.35)
        fig_h = min(18, 5 + num_classes * 0.35)
        fig, ax = plt.subplots(figsize=(fig_w, fig_h))
        im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
        ax.figure.colorbar(im, ax=ax)
        tick_labels = [str(n)[:max_label_chars] for n in class_names]
        ax.set(
            xticks=np.arange(num_classes),
            yticks=np.arange(num_classes),
            xticklabels=tick_labels,
            yticklabels=tick_labels,
            ylabel="True",
            xlabel="Predicted",
            title="Confusion matrix (test split)",
        )
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
        thresh = cm.max() / 2.0 if cm.size else 0
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, format(int(cm[i, j]), "d"), ha="center", va="center", color="white" if cm[i, j] > thresh else "black", fontsize=7)
        fig.tight_layout()
        fig.savefig(run_dir / "confusion_matrix.png", dpi=140)
        plt.close(fig)
    except Exception as e:
        (run_dir / "confusion_matrix_plot_warn.txt").write_text(f"PNG skipped: {e!s}", encoding="utf-8")
